<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\controllers;

use dektrium\user\controllers\SecurityController as DektriumSecurityController;
use common\models\Account;
use dektrium\user\models\User;
use Yii;
use yii\authclient\ClientInterface;
use yii\helpers\Url;

/**
 * Description of SecurityController
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class SecurityController extends DektriumSecurityController {

      public function authenticate(ClientInterface $client) {
            $account = $this->finder->findAccount()->byClient($client)->one();
            if ($account === null)
            {
                  if ($account = Account::create($client))
                  {

                        $this->action->successUrl = $account->getConnectUrl();
                  }
                  else
                  {
                        $this->action->successUrl = Url::to(['/user/security/login/']);
                  }
            }
            else
            {
                  if ($account->user instanceof User)
                  {
                        if ($account->user->isBlocked)
                        {
                              Yii::$app->session->setFlash('danger', Yii::t('user', 'Your account has been blocked.'));
                              $this->action->successUrl = Url::to(['/user/security/login/']);
                        }
                        else
                        {
                              Yii::$app->user->login($account->user, $this->module->rememberFor);
                              $this->action->successUrl = Yii::$app->getUser()->getReturnUrl();
                        }
                  }
                  else
                  {
                        $this->action->successUrl = $account->getConnectUrl();
                  }
            }
      }

}
