<?php

namespace common\controllers;

use Yii;
use yii\web\Controller;
use molotokk\components\AssumedPageException;

/**
 * Description of AuktaController
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
abstract class AuktaController extends Controller {

    /**
     * @inheritdoc
     */
    public $layout = 'main';

    /**
     * @var string название класса базовой модели контроллера, для стандартных действий (CRUD)
     */
    public $modelClass = 'Model';

    protected function canAccess($user_id) {
        if (empty($user_id) || $user_id != Yii::$app->user->id)
        {
            throw new AssumedPageException('У Вас нет доступа к этой странице');
        }
        else
        {
            return true;
        }
    }

    public function renderIsPjax($view, $options, $isPartial = false) {
        if (Yii::$app->request->isPjax)
        {
            return $this->renderAjax($view, $options);
        }
        if ($isPartial)
        {
            return $this->renderPartial($view, $options);
        }
        return $this->render($view, $options);
    }

}
