<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\controllers;

use Yii;
use yii\helpers\Json;
use common\models\auktaModels\Categories;

/**
 * Description of CategoryController
 *
 * @author Vladimir
 */
class CategoriesController extends AuktaController
{

    public function actionSubcat($id)
    {
        $out  = [];
        $post = Yii::$app->request->post();
        //var_dump($post);
        if (isset($post['depdrop_parents'])) {
            $parents = $post['depdrop_parents'];
            if ($parents != null) {
                $cat_id = $parents[$id];
                foreach (Categories::findAll(['parent_id' => $cat_id]) as $category) {
                    $out[] = ['id' => $category->id, 'name' => $category->name];
                }

                return Json::encode(['output' => $out, 'selected' => '']);
            }
        }
        echo Json::encode(['output' => '', 'selected' => '']);
    }
}
