<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\controllers;

use Yii;
use yii\helpers\Json;
use common\models\auktaModels\Region;
use common\models\auktaModels\City;

/**
 * Description of CityController
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class CityController extends AuktaController
{

      public function actionGetRegions()
      {
            $out  = [];
            $post = Yii::$app->request->post();
            // var_dump($post);
            if (isset($post['depdrop_parents']))
            {
                  $id       = end($post['depdrop_parents']);
                  $list     = Region::find()->andWhere(['country_id' => $id])->asArray()->all();
                  $selected = null;
                  if ($id != null && count($list) > 0)
                  {
                        $selected = '';
                        foreach ($list as $i => $region)
                        {
                              $out[] = ['id' => $region['id'], 'name' => $region['name']];
                        }
                        // Shows how you can preselect a value
                        echo Json::encode(['output' => $out, 'selected' => $selected]);
                        return;
                  }
            }
            echo Json::encode(['output' => '', 'selected' => '']);
      }

      public function actionGetCity()
      {

            $post   = Yii::$app->request->post();
            $out    = [];
            $selected = '';
            if ($params = $post['depdrop_all_params'])
            {
                  $id   = $params['city_region_id'];
                  $list = City::find()->andWhere(['region_id' => $id])->asArray()->all();

                  if ($id != null && count($list) > 0)
                  {
                        foreach ($list as $i => $city)
                        {
                              $out[] = ['id' => $city['name'], 'name' => $city['name']];
                        }
                  }
                  if ($params['cityname'])
                  {
                        $selected = $params['cityname'];
                        $out      = array_merge([
                            ['id' => $params['cityname'], 'name' => $params['cityname']]
                            ], $out);
                  }   
            }
            echo Json::encode(['output' => $out, 'selected' => $selected]);
            return;
      }
}