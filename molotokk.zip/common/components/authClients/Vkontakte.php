<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\components\authClients;

use dektrium\user\clients\VKontakte as dektriumVkontakte;
use common\models\User;

/**
 * Description of Vkontakte
 *
 * @author Vladimir
 */
class Vkontakte extends dektriumVkontakte
{

    public function getEmail()
    {
        return $this->getUserAttributes()['email'];
    }

    public function getUsername()
    {
        $email    = $this->getEmail();
        $username = 'Vk-'.substr($email, 0, strpos($email, '@'));
        $i        = 1;
        while (User::findOne(['username' => $username])) {
            $username .=$i++;
        }
        return $username;
    }
}
