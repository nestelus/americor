<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\components\authClients;

use yii\authclient\clients\Google as BaseGoogle;
use dektrium\user\clients\ClientInterface;
use common\models\User;

/**
 * Description of Google
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class Google extends BaseGoogle implements ClientInterface
{

    /** @inheritdoc */
    public function getEmail()
    {
        $emails = $this->getUserAttributes()['emails'];
        foreach ($emails as $email) {
            if ($email['type'] == 'account') {
                $value = $email['value'];
                break;
            }
        }
        return isset($value) ? $value : null;
    }

    /** @inheritdoc */
    public function getUsername()
    {
        $email    = $this->getEmail();
        $username = 'googl-'.substr($email, 0, strpos($email, '@'));
        $i        = 1;
        while (User::findOne(['username' => $username])) {
            $username .=$i++;
        }
        return $username;
    }
}
