<?php
/*
 * This file is part of the Dektrium project
 *
 * (c) Dektrium project <http://github.com/dektrium>
 *
 * For the full copyright and license information, please view the LICENSE.md
 * file that was distributed with this source code.
 */

namespace common\components\authClients;

use Yii;
use yii\authclient\clients\Yandex as BaseYandex;
use dektrium\user\clients\ClientInterface;
use common\models\User;

/**
 * @author Dmitry Erofeev <dmeroff@gmail.com>
 */
class Yandex extends BaseYandex implements ClientInterface
{

    /** @inheritdoc */
    public function getEmail()
    {
        $emails = isset($this->getUserAttributes()['emails']) ? $this->getUserAttributes()['emails']
                : null;

        if ($emails !== null && isset($emails[0])) {
            return $emails[0];
        } else {
            return null;
        }
    }

    /** @inheritdoc */
    public function getUsername()
    {
        $email    = $this->getEmail();
        $username = 'Yandex-'.substr($email, 0, strpos($email, '@'));
        $i        = 1;
        while (User::findOne(['username' => $username])) {
            $username .=$i++;
        }
        return $username;
    }

    /** @inheritdoc */
    protected function defaultTitle()
    {
        return Yii::t('user', 'Yandex');
    }
}
