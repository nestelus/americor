<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\components\countTimer;

use yii\web\AssetBundle;

/**
 * Description of CountdownAsset
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class CountTimerAsset extends AssetBundle {

      public $sourcePath = '@common/components/countTimer/assets';
      public $basePath   = '@common/components/countTimer/assets';
      public $css        = [
      ];
      public $js         = [

          'js/jquery.runner.js',
              //'js/jquery.runner-min.js',
      ];
      public $depends    = [
          'common\assets\CommonAssets',
      ];

}
