<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\components\countTimer;

use yii\base\Widget;
use common\components\countTimer\CountTimerAsset;

/**
 * Description of CountTimer
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class CountTimer extends Widget
{
    public $id;
    public $pluginOptions = [];
    public $pluginEvents  = [];
    protected $_jsonOptions;

    public function init()
    {

        $view               = $this->getView();
        CountTimerAsset::register($view);
        $this->_jsonOptions = '{';

        foreach ($this->pluginOptions as $key => $value) {
            $this->_jsonOptions .= "$key:$value,";
        }
        $this->_jsonOptions .='format:'
            .' function(value) {'
            .'var period = "", ending = "";'
            .'days = Math.floor(value / 86400000);'
            .'value = value - days * 86400000;'
            .'hours = Math.floor((value) / 3600000);'
            .'value = value - hours * 3600000;'
            .'minuts = Math.floor((value) / 60000);'
            .'value = value - minuts * 60000;'
            .'seconds =  Math.floor((value) / 1000);'
            .'if(minuts.toString().length == 1) {minuts = "0"+minuts;}'
            .'if(seconds.toString().length == 1) {seconds = "0"+seconds;}'
            .'if (days > 0) {
                        if (days==11 || days==12 || days==13 || days==14) {
                            ending = "дней";
                        } else {
                            str_n=days.toString();
                            len_n=str_n.length;
                            num=str_n.substr(len_n-1,1);
                            if (num=="0"|| num=="5"|| num=="6"|| num=="7"|| num=="8"|| num=="9") {
                              ending="дней";
                            } else if (num=="1") {
                              ending="день";
                            } else if (num=="2"||num=="3" || num=="4") {
                              ending="дня";
                            }
                        }
                        period = "До завершения " + days + " " + ending;
                      } else if (hours > 0) {
                        if (hours==11 || hours==12 || hours==13 || hours==14) {
                            ending = "часов";
                        } else {
                            str_n=hours.toString();
                            len_n=str_n.length;
                            num=str_n.substr(len_n-1,1);
                            if (num=="0"|| num=="5"|| num=="6"|| num=="7"|| num=="8"|| num=="9") {
                              ending="часов";
                            } else if (num=="1") {
                              ending="час";
                            } else if (num=="2"||num=="3" || num=="4") {
                              ending="часа";
                            }
                        }
                        period = "До завершения " + hours + " " + ending;
                      } else if (minuts > 0) {
                        if (minuts==11 || minuts==12 || minuts==13 || minuts==14) {
                            ending = "минут";
                        } else {
                            str_n=minuts.toString();
                            len_n=str_n.length;
                            num=str_n.substr(len_n-1,1);
                            if (num=="0"|| num=="5"|| num=="6"|| num=="7"|| num=="8"|| num=="9") {
                              ending="минут";
                            } else if (num=="1") {
                              ending="минута";
                            } else if (num=="2"||num=="3" || num=="4") {
                              ending="минуты";
                            }
                        }
                        period = "До завершения " + minuts + " " + ending;
                      } else {
                        if (value > 0) {
                            period = "До завершения менее 1 минуты";
                        } else {
                            period = "Торги завершены"
                        }


                      }'
            .'return period;}'
            .'}';

        $view->registerJs($this->renderScript());
    }

    public function run()
    {
        return '<span id="'.$this->id.'"></span>';
    }

    protected function renderScript()
    {
        $options = json_encode($this->pluginOptions);
        $options .=

            $script = 'jQuery("#'.$this->id.'").runner('.$this->_jsonOptions.')';

        foreach ($this->pluginEvents as $event => $callback) {
            $script .= '.on("'.$event.'", '.$callback.')';
        }

        return $script;
    }
}
