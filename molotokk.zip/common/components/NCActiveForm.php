<?php
namespace common\components;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of NCActiveForm
 *
 * @author Vladimir
 */
use Yii;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;

class NCActiveForm extends ActiveForm {
    public function init() {
        parent::init();
        $this->fieldConfig['template'] ="<div class='nc_labelInput'>{label}</div>"
                . "<div class ='nc_input'>{input}</div>\n{hint}\n{error}";
    }

  /**
   * Метод возвращает класс наш унаследованный от ActiveField
   * @return string
   */
  private function getActiveFieldClassName() {
    return 'common\components\NCActiveField';
  }

  /**
   * Generates a form field.
   * A form field is associated with a model and an attribute. It contains a label, an input and an error message
   * and use them to interact with end users to collect their inputs for the attribute.
   * @param Model $model the data model
   * @param string $attribute the attribute name or expression. See [[Html::getAttributeName()]] for the format
   * about attribute expression.
   * @param array $options the additional configurations for the field object
   * @return ActiveField the created ActiveField object
   * @see fieldConfig
   */
  public function field($model, $attribute, $options = []) {
    $config = $this->fieldConfig;

    if ($config instanceof \Closure) {
      $config = call_user_func($config, $model, $attribute);
    }
    if (!isset($config['class'])) {
      $config['class'] = $this->fieldClass;
    }

    // Наш класс для ActiveField
    $config['class'] = $this->getActiveFieldClassName();


    return Yii::createObject(ArrayHelper::merge($config, $options, [
                        'model' => $model,
                        'attribute' => $attribute,
                        'form' => $this,
    ]));
  }

}
