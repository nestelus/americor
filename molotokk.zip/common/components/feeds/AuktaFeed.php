<?php
/** @property common\models\Feeds $feed  */

namespace common\components\feeds;

use Yii;
use yii\base\Component;
use common\models\auktaModels\Products;
use common\models\FeedAssign;
use common\models\auktaModels\enumModels\StateProduct;
use yii\imagine\Image;
use common\models\auktaModels\ProductPhotos;
use common\models\auktaModels\DeliveryProduct;
use common\models\auktaModels\PaymentProduct;
use common\models\auktaModels\PropertyReferrence;
use common\models\auktaModels\ProductProperties;
use common\models\auktaModels\enumModels\PropertyType;
use Imagine\Image\Box;

/**
 * Description of Feed
 *
 * @author Vladimir
 */
class AuktaFeed extends Component
{
    public $feed;
    private $_items;

    public function run()
    {
        $this->feedXml();
        $this->assignProducts();
    }

    public function reset()
    {
        unset($this->feed);
        unset($this->_items);
    }

    /**
     * Вытаскивание фида и заполнение таблицы feed_assign
     */
    private function feedXml()
    {
        $result = simplexml_load_file($this->feed->url);

        foreach ($result as $item) {
            $id                = $item['id']->__toString();
            $this->_items[$id] = json_decode(json_encode($item), true);
            $feed_assign       = FeedAssign::findOne([
                    'feed_id' => $this->feed->id,
                    'key_feed' => $id,
            ]);
            //если нет такого элемента - создаём
            if (!$feed_assign) {
                $feed_assign = new FeedAssign([
                    'feed_id' => $this->feed->id,
                    'key_feed' => $id,
                ]);
                $feed_assign->save(false);
            }
        }
    }

    /**
     * Пробегаем таблицу соответствий и решаем, что делать с каждой строкой
     */
    private function assignProducts()
    {
        $feed_assigns = FeedAssign::findAll(['feed_id' => $this->feed->id]);
        if (!empty($feed_assigns)) {
//            var_dump($feed_assigns);
//            die();

            foreach ($feed_assigns as $feed_assign) {
                $feed_assign->action = 'Действий не было';
                if (!isset($this->_items[$feed_assign->key_feed])) {
                    // если с фидом не пришел элемент
                    $this->closeProducts($feed_assign);
                } elseif (!$feed_assign->key_aukta) {
                    // если с фидом пришел элемент первый раз
                    $product                = new Products();
                    $feed                   = $this->_items[$feed_assign['key_feed']];
                    $this->populateProducts($product, $feed);
                    $product->publicProduct();
                    $feed_assign->key_aukta = $product->id;
                    $feed_assign->action    = 'Создан новый лот';
                    $feed_assign->save();
                } else {

                    //Если есть и фид и лот
                    $product = $feed_assign->keyAukta;

                    $this->updateProduct($product, $feed_assign);
                }
            }
        }
    }

    /**
     *
     * @param FeedAssign $feed_assign
     * @return boolean
     * Закрываем лот и удаляем строку соответствия
     */
    private function closeProducts(FeedAssign $feed_assign)
    {
        $product = $feed_assign->keyAukta;
        $product->endAuction(true);
        $feed_assign->delete();
        return true;
    }

    private function updateProduct($product, $feed_assign)
    {
        switch ($product->state_id) {
            case StateProduct::STATE_ON_HIDE:
            case StateProduct::STATE_ON_SOLD:
                $product->updateAttributes([
                    'state_id' => StateProduct::STATE_ON_CREATE,
                ]);
                $product->publicProduct();
//                $feed   = $this->_items[$feed_assign['key_feed']];
//                $clone  = new Products();
//                $action = $this->populateProducts($clone, $feed);
//                if (!$action) {
//                    $clone->publicProduct();
//                    $feed_assign->key_aukta = $clone->id;
//                    $feed_assign->action    = 'Лот выставлен заново';
//                } else {
//                    $feed_assign->action = $action.' '.implode($clone->firstErrors);
//                }
//                break;
            case StateProduct::STATE_ON_AUCTION:
            case StateProduct::STATE_ON_SALE:
                $feed                = $this->_items[$feed_assign['key_feed']];
                $action              = $this->populateProducts($product, $feed);
                $feed_assign->action = $action? : 'Лот обновлен';
                break;
            default :
                $feed_assign->action = 'Действий не было';
        }
        $feed_assign->save();
    }
    /*
     * Заполняем лот данными из фида
     *
     */

    private function populateProducts(Products $product, $feed)
    {
        $action        = false;
        //из фида
        $product->name = mb_substr($feed['title'], 0, 64);
        /* @@Костыль */
        if (!empty($feed['descr'])) {
            $product->description = $feed['descr'];
        }
        $product->price = $feed['price'];

        // из настроек
        $product->user_id        = $this->feed->user_id;
        $product->category_id    = $this->feed->category_id;
        $product->region_id      = $this->feed->region_id;
        $product->city           = $this->feed->city;
        $product->is_auction     = $this->feed->is_auction;
        $product->is_prepay      = $this->feed->is_prepay;
        $product->is_deliverypay = $this->feed->is_deliverypay;
        $product->time_stop      = $this->feed->time_stop;
        $product->is_multilot    = $this->feed->is_multilot; //????
        $product->num_public     = $this->feed->num_public; //???

        if (!$product->save(false)) {
            return 'Лот записать не удалось';
        }
        $action = $this->populateProperty($product, $feed);
        if ($action) {
            return $action;
        }
        $action = $this->populatePhoto($product, $feed);
        if ($action) {
            return $action;
        }
        if (!empty($feed['tags'])) {
            $this->populateTags($product, $feed);
        }

        $this->populatePayment($product);
        $this->populateDelivery($product);

        return $action;
    }

    private function populatePhoto($product, $feed)
    {
        $old_photos = [];
        foreach ($product->getProductPhotos()->select('file_name')->asArray()->all() as $old_photo) {
            $old_photos[] = $old_photo['file_name'];
        }
        $photos = $feed['photos']['photo'];
        if (!is_array($photos)) {
            $photos = [$photos];
        }
        foreach ($photos as $image) {
            $filename = end((explode("/", $image)));

            if (!in_array($filename, $old_photos)) {
                $img    = Image::getImagine()->open($image);
                $size   = $img->getSize();
                $width  = $size->getWidth();
                $height = $size->getHeight();
                if ($width > 1200) {
                    $ratio  = $width / $height;
                    $width  = 1200;
                    $height = round($width / $ratio);
                    $box    = new Box($width, $height);
                    $img->resize($box);
                }
                if ($height > 900) {
                    $ratio  = $width / $height;
                    $height = 900;
                    $width  = round($height * $ratio);
                    $box    = new Box($width, $height);
                    $img->resize($box);
                }

                $modelPhoto = new ProductPhotos();

                $modelPhoto->file_name  = $filename;
                $modelPhoto->product_id = $product->id;

                $modelPhoto->created_at = time();

                $path = $modelPhoto->getPathPhoto();

                //mkdir(dirname($path), 0777, TRUE) or die(dirname($path));
                is_dir(dirname($path)) or mkdir(dirname($path), 0777, TRUE);

                if ($img->save($path)) {
                    $modelPhoto->save(false);
                    $modelPhoto->nextOrder();
                } else {
                    return 'Не удалось загрузить фото';
                }
            } else {
                unset($old_photos[array_search($filename, $old_photos)]);
            }
        }
        if (!empty($old_photos)) {
            foreach ($old_photos as $file_name) {
                $productPhoto = ProductPhotos::findOne([
                        'product_id' => $product->id,
                        'file_name' => $file_name,
                ]);
                if ($productPhoto) {
                    $productPhoto->delete();
                }
            }
        }
        return false;
    }

    private function populateProperty($product, $feed)
    {
        foreach ($product->productProperties as $old_property) {
            $old_property->delete();
        }
        $properties      = $feed['properties'];
        $feed_properties = $this->feed->feedProperties;
        $action          = false;
        foreach ($feed_properties as $feed_property) {
            if ($feed_property->feed_key) {
                $category_property = $feed_property->categoryProperty;
                $product_property  = new ProductProperties([
                    'category_properties_id' => $feed_property->category_property_id,
                    'product_id' => $product->id,
                ]);
                if ($category_property->type_id == PropertyType::TYPE_LIST) {

                    $reference = PropertyReferrence::findOne([
                            'reference_type_id' => $category_property->referrence_type_id,
                            'value' => $properties[$feed_property->feed_key],
                    ]);
                    if (!$reference) {
                        $reference = new PropertyReferrence([
                            'reference_type_id' => $category_property->referrence_type_id,
                            'value' => $properties[$feed_property->feed_key],
                        ]);
                        if (!$reference->save()) {
                            return 'Не удалось добавить свойство '.$category_property->name.': '.$properties[$feed_property->feed_key];
                        }
                    }
                    $product_property->property_referrence_id = $reference->id;
                } else {
                    $product_property->data = $properties[$feed_property->feed_key];
                }
                if (!$product_property->save()) {
                    return 'Не удалось заполнить свойство '.$category_property->name.': '.$properties[$feed_property->feed_key];
                }
            }
        }
        return $action;
    }

    private function populateTags($product, $feed)
    {

        $tags = $feed['tags']['tag'];
        if (!is_array($tags)) {
            $tags = [$tags];
        }
        $product->tagNames = $tags;
        $product->save();
    }

    private function populatePayment($product)
    {
        foreach ($product->paymentProduct as $old_payment) {
            $old_payment->delete();
        }

        foreach ($this->feed->feedPaymentTypes as $pay) {
            $payment                = new PaymentProduct();
            $payment->product_id    = $product->id;
            $payment->pay_method_id = $pay->payment_method_id;
            $payment->save();
        }
    }

    private function populateDelivery($product)
    {
        foreach ($product->deliveryProduct as $old_delivery) {
            $old_delivery->delete();
        }
        foreach ($this->feed->feedDeliveryTypes as $deliv) {
            $delivery                   = new DeliveryProduct();
            $delivery->product_id       = $product->id;
            $delivery->delivery_type_id = $deliv->delivery_type_id;
            $delivery->save();
        }
    }
}
