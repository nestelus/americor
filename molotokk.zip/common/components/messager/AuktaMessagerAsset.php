<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\components\messager;

use yii\web\AssetBundle;

/**
 * Description of AuktaMessagerAsset
 *
 * @author Vladimir
 */
class AuktaMessagerAsset extends AssetBundle
{
    public $sourcePath = '@common/components/messager';
    public $js         = [
        'js/aukta-messager.js',
    ];
    public $depends    = [
        'common\assets\CommonAssets',
    ];

}
