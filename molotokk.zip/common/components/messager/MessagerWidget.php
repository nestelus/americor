<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\components\messager;

use yii\bootstrap\Widget;

/**
 * Description of UserListWidget
 *
 * @author Vladimir
 */
class MessagerWidget extends Widget
{
    public $messager;
    public $mode;
    protected $_messages_array;

    public function init()
    {
        AuktaMessagerAsset::register($this->getView());
    }

    public function run()
    {
        return $this->render($this->mode,
                [
                'messager' => $this->messager,
        ]);
    }
}
