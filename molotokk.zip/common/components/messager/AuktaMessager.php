<?php
/**
 * 
 */

namespace common\components\messager;

use Yii;
use yii\base\Component;
use common\models\auktaModels\Messages;

/**
 * Description of AuktaMessager
 *
 * @author Vladimir
 */
class AuktaMessager extends Component
{
    const STATUS_NEW         = '1';
    const STATUS_READ        = '0';
    const DIRECTION_ALL      = 0;
    const DIRECTION_FROM_OWN = 1;
    const DIRECTION_TO_OWN   = 2;
    const DIRECTION_SYSTEM   = -1;

    public $direction          = 0;
    public $status             = null;
    public $user_id            = null; //чьи сообщение
    public $visavi_id          = null; //с кем диалог
    public $lot_id             = null;
    public $offset             = 0;
    public $long               = 608200;
    public $query;
    public $limit              = 10;
    public $messages           = [];
    protected $_count_messages = [];

    public function init()
    {
        $get = Yii::$app->request->get();
        if (isset($get['direction'])) {
            $this->direction = $get['direction'];
        }
        if (isset($get['status'])) {
            $this->status = $get['status'];
        }
        if (isset($get['visavi_id'])) {
            $this->visavi_id = $get['visavi_id'];
        }
        if (isset($get['lot_id'])) {
            $this->lot_id = $get['lot_id'];
        }
        $this->user_id or $this->user_id = Yii::$app->user->id;
        $this->query   = Messages::find()->orderBy(['created_at' => SORT_ASC]);



        $this->setCountMessages();

        //$this->query->andFilterWhere(['status' => $this->status]);
//        var_dump($this->query->createCommand()->rawSql);
        // die();
    }

    private function thisWhere(&$query, $lot = false, $visavi = false)
    {
        if ($this->direction != self::DIRECTION_SYSTEM) {

            switch ($this->direction) {

                case self::DIRECTION_TO_OWN:
                    // от покупателей
                    $query->andFilterWhere(['or',
                        [
                            'whom_id' => $this->user_id,
                            'is_delete_whom' => 0,
                            'direction' => self::DIRECTION_TO_OWN,
                            'from_id' => $visavi ? $this->visavi_id : null,
                        ],
                        [
                            'from_id' => $this->user_id,
                            'is_delete_from' => 0,
                            'direction' => self::DIRECTION_FROM_OWN,
                            'whom_id' => $visavi ? $this->visavi_id : null,
                        ]
                    ]);

                    break;
                case self::DIRECTION_FROM_OWN:
                    // от продавцов
                    $query->andFilterWhere(['or',
                        [
                            'whom_id' => $this->user_id,
                            'is_delete_whom' => 0,
                            'direction' => self::DIRECTION_FROM_OWN,
                            'from_id' => $visavi ? $this->visavi_id : null,
                        ],
                        [
                            'from_id' => $this->user_id,
                            'is_delete_from' => 0,
                            'direction' => self::DIRECTION_TO_OWN,
                            'whom_id' => $visavi ? $this->visavi_id : null,
                        ]
                    ]);
                    break;
                case self::DIRECTION_ALL:
                    $query->orFilterWhere([
                            'whom_id' => $this->user_id,
                            'is_delete_whom' => 0,
                            'from_id' => $visavi ? $this->visavi_id : null,
                        ])
                        ->orFilterWhere([
                            'from_id' => $this->user_id,
                            'is_delete_from' => 0,
                            'whom_id' => $visavi ? $this->visavi_id : null,
                    ]);
                    break;
            }
        } else {

            $query->andWhere(['whom_id' => $this->user_id, 'is_delete_whom' => 0,
                'direction' => self::DIRECTION_SYSTEM]);
        }
        $query->andFilterWhere(['product_id' => $lot ? $this->lot_id : null]);
        $query->andFilterWhere(['status' => $this->status]);
    }

    public function getUrlParam($params)
    {
        $current_params = [
            'direction' => $this->direction,
            'status' => $this->status,
            'lot_id' => $this->lot_id,
            'visavi_id' => $this->visavi_id
        ];
        return array_merge($current_params, $params);
    }

    public function setCountMessages()
    {
        $count_query = Messages::find()
            ->andWhere([
            'whom_id' => $this->user_id,
            'is_delete_whom' => 0,
        ]);
        $count_query->select(['product_id', 'from_id', 'direction', 'status', 'count' => 'COUNT(id)']);
        $count_query->groupBy(['product_id', 'from_id', 'direction', 'status']);

        $count_messages = $count_query->asArray()->all();
        foreach ($count_messages as $count_message) {
            $this->_count_messages[$count_message['direction']][$count_message['product_id']][$count_message['from_id']?
                        : -1][$count_message['status']] = $count_message['count'];
        }
    }

    public function getCountMessages()
    {
        return $this->_count_messages;
    }

    public function getLotList()
    {
        $lot_query = clone $this->query;
        $this->thisWhere($lot_query);
        $lot_query->andFilterWhere(['status' => $this->status]);
        $messages  = $lot_query->asArray()->all();

        $user_list = [];
        foreach ($messages as $message) {
            if ($this->direction == self::DIRECTION_TO_OWN || $this->direction == self::DIRECTION_ALL) {
                // диалоги с покупателями
                if ($message['from_id'] == $this->user_id && $message['direction']
                    == self::DIRECTION_FROM_OWN && $message['is_delete_from'] == 0) {

                    $user_list[self::DIRECTION_FROM_OWN][$message['product_id']]
                        = [$message['whom_id']];
                }
                if ($message['whom_id'] == $this->user_id && $message['direction']
                    == self::DIRECTION_TO_OWN && $message['is_delete_whom'] == 0) {

                    $user_list[self::DIRECTION_FROM_OWN][$message['product_id']]
                        = [$message['from_id']];
                }
            }
            if ($this->direction == self::DIRECTION_FROM_OWN || $this->direction
                == self::DIRECTION_ALL) {
                //диалоги с продавцами
                if ($message['from_id'] == $this->user_id && $message['direction']
                    == self::DIRECTION_TO_OWN && $message['is_delete_from'] == 0) {

                    $user_list[self::DIRECTION_TO_OWN][$message['product_id']] = [$message['whom_id']];
                }
                if ($message['whom_id'] == $this->user_id && $message['direction']
                    == self::DIRECTION_FROM_OWN && $message['is_delete_whom'] == 0) {

                    $user_list[self::DIRECTION_TO_OWN][$message['product_id']] = [$message['from_id']];
                }
            }
            if ($this->direction == self::DIRECTION_SYSTEM) {
                if ($message['direction']) {
                    $user_list[self::DIRECTION_SYSTEM][$message['product_id']] = [$message['product_id']];
                }
            }
        }

        return $user_list;
    }

    public function renderMenu()
    {
        return MessagerWidget::widget([
                'messager' => $this,
                'mode' => 'lots_list',
        ]);
    }

    public function renderDialog()
    {
//        var_dump($this->query->where);
//        die();
//
        $dialog_query = clone $this->query;
        $this->thisWhere($dialog_query, $this->lot_id, $this->visavi_id);
        $dialog_query->andFilterWhere(['status' => $this->status]);
        $dialog_query->offset($this->offset);
        //$dialog_query->limit($this->limit);
        //var_dump($dialog_query->createCommand()->rawSql);

        $this->messages = $dialog_query->all();

        //var_dump($dialog_query->createCommand()->rawSql);

        return MessagerWidget::widget([
                'messager' => $this,
                'mode' => 'dialogs',
        ]);
    }

    public function renderFilter()
    {
        return MessagerWidget::widget([
                'messager' => $this,
                'mode' => 'filter_status',
        ]);
    }

    public function renderSendForm()
    {
        return MessagerWidget::widget([
                'messager' => $this,
                'mode' => 'send_form',
        ]);
    }
}
