<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use common\models\auktaModels\Products;
use yii\helpers\Url;
use yii\helpers\Html;
use common\models\User;
use yii\widgets\Pjax;

$user_list = $messager->getLotList();
?>
<div class="col-md-3 col-lg-3 col-sm-4 message-user-list">
    <ul  class="list-group category_facet_ul">
        <?php foreach ($user_list as $direction => $dialogs): ?>
            <?php
            foreach ($dialogs as $lot_id => $users):
                $lot = Products::findOne($lot_id);
                ?>
                <li class="list-group-item <?=
                $messager->lot_id == $lot_id ? 'active' : ''
                ?> ">
                        <?php if ($direction >= 0) : ?>
                        <div class="dialog-list-lot" id="list-lot-<?= $lot_id ?>">
                            <?php
                            $url_params = $messager->getUrlParam(['lot_id' => $lot_id]);
//
                            array_unshift($url_params, '/messages/dialog');
                            ?>
                            <a data-toggle="collapse" data-parent="#accordion"
                               class="pj-message-user" href="<?=
                               Url::to($url_params)
                               ?>#collapse<?= $lot_id ?>">
                                Лот № <?= $lot->id ?>
                            </a>
                            <span class = "js_count-messages" lot ="<?= $lot_id ?>" direction ="0" from ="0"></span>

                        </div>
                        <div id="collapse<?= $lot_id ?>" class="panel-collapse collapse <?=
                        $messager->lot_id == $lot_id ? 'in' : ''
                        ?>">
                            <ul class="list-group category_facet_ul">

                                <?php
                                foreach ($users as $usr_id):

                                    $usr        = User::findOne($usr_id);
                                    $url_params = $messager->getUrlParam(['visavi_id' => $usr_id,
                                        'lot_id' => $lot_id]);
// 
                                    array_unshift($url_params,
                                        '/messages/dialog');
                                    ?>
                                    <li class="contact <?=
                                    ($messager->visavi_id && $messager->lot_id == $lot_id)
                                    == $usr_id ? 'active' : ''
                                    ?>" >
                                        <span class="glyphicon glyphicon-user"></span>
                                        <?=
                                        Html::a($usr->username,
                                            Url::to(['messages/user-list',
                                                'visavi_id' => $usr_id,
                                                'lot_id' => $lot_id,
                                            ]),
                                            [
                                            'class' => 'pj-message-user-list',])
                                        ?>
                                        <span class = "js_count-messages" lot ="<?= $lot_id ?>" direction ="0" from ="<?= $usr_id ?>"></span>
                                        </span>

                                    </li>
                                <?php endforeach; ?>

                            </ul>
                        </div>
                    </li>
                    <?php
                else:

                    $url_params = $messager->getUrlParam(['lot_id' => $lot_id]); //
                    array_unshift($url_params, '/messages/dialog');
                    ?>
                    <div class="dialog-list-lot">
                        <a href="<?=
                        Url::to($url_params)
                        ?>" class="pj-message-user">
                            Лот № <?= $lot_id ?>
                        </a>

                        <span> </span>

                    </div>
                <?php endif; ?>
            <?php endforeach; ?>
        <?php endforeach; ?>
    </ul>
</div>
<?php
Pjax::begin(
    [
        'enablePushState' => false,
        'id' => 'pj_message-dialog',
        'linkSelector' => '.pj-message-user',
        'formSelector' => '.pj_form-render-dialog',
        'scrollTo' => true,
        'timeout' => null,
    ]
);
?>
<?= $messager->renderDialog(); ?>
<?php Pjax::end() ?>


