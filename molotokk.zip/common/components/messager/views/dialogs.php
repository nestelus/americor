<?php
$messages = $messager->messages;
?>
<div class="col-md-9 col-lg-9 col-sm-8 ">
    <div class="row ">
        <div class="message-dialog" id="js_message-dialog">

            <?php if (!empty($messages)) : ?>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" id="js_messages-block">
                    <?php foreach ($messages as $key => $message) : ?>
                        <?=
                        $this->render('message',
                            [
                            'message' => $message,
                            'messager' => $messager,
                        ])
                        ?>
                    <?php endforeach; ?>
                </div>
            <?php else : ?>
                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"> Сообщений пока нет </div>
            <?php endif; ?>

        </div>
    </div>
    <div class="row">
        <?php if ($messager->lot_id && $messager->visavi_id): ?>
            <?= $messager->renderSendForm() ?>
        <?php endif; ?>
    </div>
</div>

