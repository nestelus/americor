<?php

use yii\bootstrap\ActiveForm;
use yii\helpers\Html;
use common\components\messager\AuktaMessager;

$message_directions = [
    AuktaMessager::DIRECTION_ALL => 'Все',
    AuktaMessager::DIRECTION_FROM_OWN => 'От продавцов',
    AuktaMessager::DIRECTION_TO_OWN => 'От покупателей',
    AuktaMessager::DIRECTION_SYSTEM => 'Системные сообщения',
];
$messages_filter    = [
    null => 'Все ',
    1 => 'Не прочитанные',
];
?>
<div class="visual-form recall-block">
    <div class="recall-bookmarks-block fb clearfix">
        <?php
        $form               = ActiveForm::begin(
                [
                    'action' => '/messages/filter/',
                    'id' => 'message-filtr-form',
                    'method' => 'get',
                    'options' => [
                        'data-pjax' => 1,
                    ],
                ]
        );
        ?>
        <?=
        Html::radioList(
            'direction', null, $message_directions,
            [
            'id' => 'change-state_id',
            'class' => 'feedbacks-button pull-left',
            'data-toggle' => 'buttons',
            'item' => function ($index, $label, $name, $checked, $value) {
                unset($index);

                return '<label class = "btn btn-default'.($checked ? ' active' : '').'">'.
                    Html::radio(
                        $name, $checked,
                        ['value' => $value, 'class' => 'project-status-btn']
                    ).$label.'<span class = "js_count-messages" lot ="0" direction ="'.$value.'" from ="0" style="display:none"></span></label>';
            },
                ]
            );
            ?>
            <div class="pull-right" style="width:155px;margin-right:20px;">

                <?=
                Html::dropDownList('status',
                    isset($selection['rating_type']) ? $selection['messages_filter']
                            : null, $messages_filter,
                    [
                    'class' => 'form-control',
                    'id' => 'feedback-type',
                    ]
                );
                ?>

            </div>
            <div id="feedback" class="pull-right" style="padding-top:7px;margin-right:10px;">
                <label for="feedback-type">Показать</label>
            </div>
            <?php ActiveForm::end(); ?>
    </div>


</div>
