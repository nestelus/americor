<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use yii\helpers\Url;
use yii\helpers\Html;

//сообщения от меня
if ($message->from_id == $messager->user_id):
    $to            = 'Кому: ';
    $author        = $message->whom->username;
    $author_id     = $message->whom_id;
    $message_class = 'message-from';
//системные
elseif ($message->direction == -1):
    $to            = 'От АУКТЫ';
    $author        = '';
    $author_id     = 0;
    $message_class = 'col-lg-offset-5 message-to';
// сообщения мне
else:
    $to            = 'От: ';
    $author        = $message->from->username;
    $author_id     = $message->from_id;
    $message_class = 'col-lg-offset-5 message-to';
    ?>


<?php endif; ?>
<div class="row user-message">
    <div class="col-lg-7  <?= $message_class ?>">
        <?php if ($message->whom_id == $messager->user_id && $message->status) : ?>
            <span class="js_message-new" message_id='<?= $message->id ?>'>
                <span class="glyphicon glyphicon-bell"></span>
            </span>
        <?php endif; ?>
        <span class="date-time"><?= $to ?></span>
        <span class="uname">

            <?=
            Html::a($author,
                Url::to(['messages/user-list',
                    'visavi_id' => $author_id,
                    'lot_id' => $message->product_id,
                ]), [
                'class' => 'pj-message-user-list',])
            ?>

        </span>
        <span class="date-time"><?=
            Yii::t('user', '{0, date, dd.MM.YYYY HH:mm}', [$message->created_at])
            ?>
        </span>

        <span class="js_message-del" message_id='<?= $message->id ?>'>
            <span class="glyphicon glyphicon-remove"> </span>
        </span>
        <div>
            <?= $message->message ?>
        </div>

    </div>
</div>
