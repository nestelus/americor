<?php

use yii\widgets\ActiveForm;
use yii\helpers\Html;
use common\models\auktaModels\Messages;
use common\models\User;
?>
<?php $message = new Messages() ?>
<div class="message-form">
    <?php
    $form    = ActiveForm::begin([
            'options' => [
                'class' => 'pj_form-render-dialog',
            ],
            'action' => '/messages/send-message/',
    ]);
    ?>
    <?= $form->field($message, 'from_id')->hiddenInput(['value' => Yii::$app->user->id])->label(FALSE); ?>
    <?= $form->field($message, 'whom_id')->hiddenInput(['value' => $messager->visavi_id])->label(FALSE); ?>
    <?= $form->field($message, 'product_id')->hiddenInput(['value' => $messager->lot_id])->label(FALSE); ?>
    <?= $form->field($message, 'is_system')->hiddenInput(['value' => 0])->label(FALSE); ?>



    <?=
    $form->field($message, 'message')->textarea([
        'placeholder' => 'Введите сообщение',
    ])->label('Сообщение для <span class="blue">'.User::findOne($messager->visavi_id)->username.'</span>, по лоту №'.$messager->lot_id);
    ?>

    <label class="control-label" for="messages-message"></label>
    <?=
    Html::submitButton('Отправить', [ 'class' => 'btn btn-success']);
    ?>


    <?php ActiveForm::end(); ?>
</div>
