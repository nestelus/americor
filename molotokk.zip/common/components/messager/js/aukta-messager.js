
$("#message-filtr-form").on('change', function () {
    $(this).submit();
});
$(document).on('ready pjax:complete', function () {
    $("#js_message-dialog").scrollTop($('#js_messages-block').height() - $("#js_message-dialog").height());

});

$('.profile-message')
        .on('click', '.js_message-del', function () {
            $message = $(this).attr('message_id');
            $.ajax({
                url: '/messages/delete',
                data: {
                    'id': $message
                },
                success: function () {
                    $(".js_message-del[message_id = " + $message + "]").parent().parent().hide('slow');
                    $(".js_message-del[message_id = " + $message + "]").parent().parent().remove();
                }
            });
        });



