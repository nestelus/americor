<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\components;

use yii\bootstrap\Collapse;
use yii\base\InvalidConfigException;
use yii\helpers\ArrayHelper;
use yii\bootstrap\Html;

/**
 * Description of NCCollapse
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class NCCollapse extends Collapse
{

      public function renderItem($header, $item, $index)
      {
            if (array_key_exists('content', $item))
            {
                  $id            = $this->options['id'].'-collapse'.$index;
                  $options       = ArrayHelper::getValue($item, 'contentOptions', []);
                  $options['id'] = $id;
                  Html::addCssClass($options, ['widget' => 'panel-collapse', 'collapse' => 'collapse']);

                  $encodeLabel = isset($item['encode']) ? $item['encode'] : $this->encodeLabels;
                  if ($encodeLabel)
                  {
                        $header = Html::encode($header);
                  }
                  $header = Html::tag('h4', $header, ['class' => 'panel-title']);

                  $headerToggle = Html::a($header, '#'.$id,
                          [
                          'class' => 'collapse-toggle',
                          'data-toggle' => 'collapse',
                          'data-parent' => '#'.$item['options']['id']
                      ])."\n";



                  if (is_string($item['content']) || is_object($item['content']))
                  {
                        $content = Html::tag('div', $item['content'], ['class' => 'panel-body'])."\n";
                  } elseif (is_array($item['content']))
                  {
                        $content = Html::ul($item['content'],
                                [
                                'class' => 'list-group',
                                'itemOptions' => [
                                    'class' => 'list-group-item'
                                ],
                                'encode' => false,
                            ])."\n";
                        if (isset($item['footer']))
                        {
                              $content .= Html::tag('div', $item['footer'], ['class' => 'panel-footer'])."\n";
                        }
                  } else
                  {
                        throw new InvalidConfigException('The "content" option should be a string, array or object.');
                  }
            } else
            {
                  throw new InvalidConfigException('The "content" option is required.');
            }
            $group = [];

            $group[] = Html::tag('div', $headerToggle, ['class' => 'panel-heading']);
            $group[] = Html::tag('div', $content, $options);

            return implode("\n", $group);
      }
}