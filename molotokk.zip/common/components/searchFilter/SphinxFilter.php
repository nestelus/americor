<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\components\searchFilter;

use Yii;
use common\models\auktaModels\Products;
use yii\sphinx\ActiveDataProvider;
use yii\db\Expression;

/**
 * Description of sphinxFilter
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class SphinxFilter extends searchFilter
{
    private $_facets = [];

    protected function _executeFilter()
    {
        parent::_executeFilter();
        if (isset($this->_filter['searchText']) && !empty($this->_filter['searchText'])) {

            $this->query->match((new Expression(':match',
                    [
                    'match' => Yii::$app->sphinx->escapeMatchValue($this->_filter['searchText']),
                ])))
                ->showMeta(true)
                ->facets([
                    'parent_id',
                    'category_id',
            ]);
        }
    }

    public function init()
    {
        parent::init();
        $this->_setFacet();
    }

    public function getResult()
    {

        if (isset($this->_filter['category_id']) && $this->_filter['category_id']
            == -2) {
            return false;
        } else {
            $models   = parent::getResult();
            //$meta     = $provider->getMeta();
            $products = [];
            foreach ($models as $n => $product) {
                ($products[$n] = Products::findOne($product['id']));
                if (is_null($products[$n])) {
                    unset($products[$n]);
                }
            }
            return $products;
        }
    }

    private function _setFacet()
    {
        $provider      = new ActiveDataProvider([
            'query' => $this->query,
        ]);
        $this->_facets = $provider->getFacets();
    }

    public function getFacet($facet = null)
    {
        if (is_null($facet)) {
            return $this->_facets;
        } else {
            if (isset($this->_facets[$facet])) {
                return $this->_facets[$facet];
            }
        }
    }
}
