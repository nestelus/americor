<?php

namespace common\components\searchFilter;

use kartik\widgets\Select2;
use Yii;
use yii\base\Component;
use yii\helpers\Html;
use yii\data\Pagination;
use yii\widgets\MaskedInput;
use yii\helpers\ArrayHelper;
use common\models\Profile;
use common\models\auktaModels\Country;
use common\models\auktaModels\Region;
use kartik\depdrop\DepDrop;
use yii\helpers\Url;

//use yii\widgets\ActiveForm;

/**
 * Description of searchFilter
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class searchFilter extends Component
{
    const VAR_FILTR_STATE       = 'state_id';
    const VAR_FILTR_SORT        = 'sort';
    const VAR_FILTR_MODE        = 'mode';
    const VAR_FILTR_LIMIT       = 'count';
    const VAR_SEARCH_PRICE      = 'price';
    const VAR_SEARCH_TIME_START = 'time_start';
    const VAR_SEARCH_TIME_END   = 'time_end';
    const VAR_SEARCH_REGION     = 'region_id';
    const VAR_SEARCH_CATEGORY   = 'category_id';

    /**
     *
     * запрос (объект query) который надо обрабатывать
     */
    public $query;

    /**
     *
     * @var набор полей запроcа, который участвует в обработке
     */
    public $params = [
    ];
    public $action;
    /*
     * Кнопки фильтра статусов
     */
    public $states = [];

    /**
     *
     * Список количеств пунктов на страницу
     */
    public $arrayCount = [
        10 => 10,
        30 => 30,
        70 => 70,
    ];
    /*
     * Варианты сортировок
     */
    public $arraySort  = [
        'time_start DESC' => 'Сначала новые',
        'time_end ASC' => 'Скоро завершатся',
        'price ASC' => 'По цене - от меньшей к большей',
        'price DESC' => 'По цене - от большей к меньшей',
    ];
    /*
     * текущая сортировка
     */
    public $sort       = 'time_start DESC';
    /*
     * метод отправки данных фильртра
     */
    public $method     = 'get';
    /*
     * массив текущих значений фильтров
     */
    protected $_filter = [];
    /*
     * вид вывода
     */
    public $mode       = 'short';
    /*
     * объект пагинатора
     */
    protected $_pagination;
    /*
     * текущее значение пунктов на страницу
     */
    protected $_limit  = 10;

    public function init()
    {
        if (!Yii::$app->user->isGuest) {
            $profile  = Profile::findOne(Yii::$app->user->id);
            $settings = json_decode($profile->visual_settings, true);
            if (isset($settings[$this->action])) {
                $this->sort   = $settings[$this->action]['sort'];
                $this->_limit = $settings[$this->action]['limit'];
                $this->mode   = $settings[$this->action]['mode'];
            }
        } else {
            $cookies = Yii::$app->request->cookies;
            if ($visual  = $cookies->getValue('visual_'.$this->action)) {
                $this->sort   = $visual['sort'];
                $this->_limit = $visual['limit'];
                $this->mode   = $visual['mode'];
            }
        }


        if (!Yii::$app->user->isGuest) {
            $settings[$this->action]['sort']  = $this->sort;
            $settings[$this->action]['limit'] = $this->_limit;
            $settings[$this->action]['mode']  = $this->mode;
            $profile->updateAttributes(['visual_settings' => json_encode($settings)]);
        } else {
            Yii::$app->response->cookies->add(
                new \yii\web\Cookie(
                [
                'name' => 'visual_'.$this->action,
                'value' => [
                    'sort' => $this->sort,
                    'limit' => $this->_limit,
                    'mode' => $this->mode,
                ],
                ]
                )
            );
        }
        $this->_setFilter();
        $this->_setSort();
        $this->_executeFilter();
        $this->setPagination();
//        var_dump($this->query->createCommand()->rawSql);
//        die();
    }

    protected function _setFilter()
    {
        if ($request = Yii::$app->request) {
            if ($this->method == 'get') {
                $req = $request->get();
            }
            if ($this->method == 'post') {
                $req = $request->post();
            }
        }
        if (!empty($this->states)) {
            $this->_filter[self::VAR_FILTR_STATE] = array_keys($this->states);
        }
        foreach ($req as $key => $value) {
            switch ($key) {
                case self::VAR_FILTR_SORT:
                    $this->sort   = isset($req[$key]) ? $req[$key] : $this->sort;
                    unset($req[$key]);
                    break;
                case self::VAR_FILTR_LIMIT:
                    $this->_limit = isset($req[$key]) ? $req[$key] : $this->_limit;
                    unset($req[$key]);
                    break;
                case self::VAR_FILTR_MODE:
                    $this->mode   = isset($req[$key]) ? $req[$key] : $this->mode;
                    unset($req[$key]);
                    break;
                case self::VAR_FILTR_STATE:
                    if ($req[$key] == -1 && empty($this->states)) {
                        $this->_filter[$key] = array_keys($this->states);
                        break;
                    }

                default:
                    $this->_filter[$key] = $value;
            }
        }
    }

    public function renderVisualForm()
    {
        Yii::$app->view->render(
            '_visual-form', [
            ]
        );
    }
    /*
     * Добавляет или заменяет $arraySort
     */

    public function addSorts(array $newSorts, $merge = true)
    {
        if ($merge) {
            $this->arraySort = array_merge_recursive($this->arraySort, $newSorts);
        } else {
            $this->arraySort = $newSorts;
        }
    }
    /*
     * Возвращает список объектов
     */

    public function getResult()
    {

        return $this->query->offset($this->_pagination->offset)
                ->limit($this->_pagination->limit)
                ->all();
    }
    /*
     * Задаёт внутренний пагинатор
     */

    public function setPagination()
    {
        $countQuery = clone $this->query;

        $this->_pagination = new Pagination(
            [
            'totalCount' => $countQuery->count(),
            'pageSize' => ($this->mode == 'mini') ? $this->_limit * 3 : $this->_limit,
            ]
        );
    }

    public function getPagination()
    {
        return $this->_pagination;
    }

    public function getFilterCount()
    {
        $return = Html::beginTag('p', ['class' => 'category-shop-product-limit']);
        foreach ($this->arrayCount as $key => $value) {
            if ($this->_limit == $value) {
                $return .= '<span class ="current">'.$value.'</span>';
            } else {
                $path_param = array_merge($this->_filter,
                    [
                    'page' => $this->_pagination->offset,
                    self::VAR_FILTR_LIMIT => $value
                ]);
                array_unshift($path_param, Yii::$app->controller->getRoute());
                $return .= '<span>'.Html::a(
                        $value, $path_param
                    ).'</span>';
            }
        }

        $return .= 'предложений на странице';
        $return .= Html::endTag('p');

        return $return;
    }

    public function getFilterSorts()
    {
        if (!empty($this->arraySort)) {
            return
                Select2::widget(
                    [
                        'name' => self::VAR_FILTR_SORT,
                        'data' => $this->arraySort,
                        'value' => $this->sort,
                        'theme' => Select2::THEME_BOOTSTRAP,
                        'options' => [
                            'placeholder' => 'Выберите сортировку',
                        ],
                        'pluginOptions' => [
                            'width' => '250px',
                        ],
                    ]
            );
        }
    }

    public function getCurrentFilter()
    {
        return $this->_filter;
    }

    public function getSearchFields()
    {
        foreach ($this->params as $param) {
            $fields[] = $this->_renderField($param);
        }

        return $fields;
    }

    protected function _renderField($field)
    {
        switch ($field) {
            case self::VAR_SEARCH_PRICE:
                return '<div class="form-group">'
                    .'<label class="control-label for">Цена</label><br/>'
                    .MaskedInput::widget(
                        [
                            'value' => isset($this->_filter['price']['min']) ? $this->_filter['price']['min']
                                    : '',
                            'name' => 'price[min]',
                            'mask' => '9',
                            'clientOptions' => ['repeat' => 10, 'greedy' => false],
                            'options' => ['class' => 'search-field-price'],
                        ]
                    )
                    .'<span class="search-field-price-dash">&mdash;</span>'
                    .MaskedInput::widget(
                        [
                            'value' => isset($this->_filter['price']['max']) ? $this->_filter['price']['max']
                                    : '',
                            'name' => 'price[max]',
                            'mask' => '9',
                            'clientOptions' => ['repeat' => 10, 'greedy' => false],
                            'options' => ['class' => 'search-field-price'],
                        ]
                    ).Yii::$app->params['currency'].'</div>';

            case self::VAR_SEARCH_TIME_START:
                return '<div class="form-group">'
                    .'<label class="control-label for">Выставленые в течение</label>'
                    .Html::dropDownList('time_start',
                        isset($this->_filter['time_start']) ? : '',
                        [
                        3600 => 'часа',
                        10800 => '3 часов',
                        21600 => '6 часов',
                        43200 => '12 часов',
                        86400 => 'суток',
                        172800 => '2-х дней',
                        259200 => '3-х дней',
                        604800 => 'недели',
                        ],
                        [
                        'class' => 'form-control',
                        'prompt' => 'Выбрать',
                    ])
                    .'</div>';

            case self::VAR_SEARCH_TIME_END:
                // var_dump($this->_filter);
                return '<div class="form-group">'
                    .'<label class="control-label for">Завершающиеся в течение</label></br>'
                    .Html::dropDownList('time_stop',
                        isset($this->_filter['time_end']) ? : '',
                        [
                        3600 => 'часа',
                        10800 => '3 часов',
                        21600 => '6 часов',
                        43200 => '12 часов',
                        86400 => 'суток',
                        172800 => '2-х дней',
                        259200 => '3-х дней',
                        604800 => 'недели',
                        ],
                        [
                        'class' => 'form-control',
                        'prompt' => 'Выбрать',
                    ])
                    .'</div>';

            case self::VAR_SEARCH_REGION:
                $country = ArrayHelper::map(Country::find()->orderBy('name')->asArray()->all(),
                        'id', 'name');
                $out     = '<div class="form-group"><label class="control-label for">Страна</label>'
                    .Select2::widget(
                        [

                            'name' => 'city_country_id',
                            'data' => $country,
                            'theme' => Select2::THEME_BOOTSTRAP,
                            'options' => [
                                'id' => 'city_country_id',
                                'placeholder' => 'Выбрать',
                            ],
                        ]
                );
                $out .= '</div><div class="form-group"><label class="control-label for">Регион</label>'.DepDrop::widget(
                        [
                            'type' => DepDrop::TYPE_SELECT2,
                            'name' => 'region_id',
                            'data' => ArrayHelper::map(Region::find()->orderBy('name')->asArray()->all(),
                                'id', 'name'),
                            'options' => ['id' => 'city_region_id'],
                            'select2Options' => [
                                'theme' => Select2::THEME_BOOTSTRAP,
                            ],
                            'pluginOptions' => [
                                'language' => 'ru',
                                'initialize' => true,
                                'depends' => ['city_country_id'],
                                'placeholder' => 'Выбрать',
                                'url' => Url::to(['/city/get-regions']),
                            ],
                        ]
                    ).'</div>';

                return $out;
            case self::VAR_SEARCH_CATEGORY:
        }
    }

    protected function _executeWhereFilter($param, $value)
    {
        if (empty($value)) {
            return;
        }
        switch ($param) {
            case self::VAR_SEARCH_PRICE:

                if (!empty($value['min'])) {
                    $this->query->andWhere(['>=', 'price', (int) $value['min']]);
                }
                if (!empty($value['max'])) {
                    $this->query->andWhere(['<=', 'price', (int) $value['max']]);
                }
                break;

            case self::VAR_SEARCH_TIME_START:
                if (!empty($value)) {
                    $this->query->andWhere(['>=', 'time_start', (int) $value]);
                }

                break;

            case self::VAR_SEARCH_TIME_END:
                if (!empty($value)) {
                    if (!empty($value)) {
                        $this->query->andWhere(['>=', 'time_end', (int) $value]);
                    }

                    break;
                }
                break;
            case self::VAR_SEARCH_REGION:


            default :
                $this->query->andWhere([$param => $value]);
        }
        // var_dump($this->query->createCommand()->rawSql);
    }

    protected function _setSort()
    {
        if ($this->sort) {
            $this->query->orderBy($this->sort);
        }
    }

    protected function _executeFilter()
    {

        if (!empty($this->_filter)) {
            foreach ($this->_filter as $key => $value) {
                if (in_array($key, $this->params) || $key == self::VAR_FILTR_STATE) {
                    $this->_executeWhereFilter($key, $value);
                }
            }
        }
    }

    public function getFilterMode()
    {
        return Html::radioList(
                self::VAR_FILTR_MODE, $this->mode,
                [
                'short' => 'glyphicon glyphicon-th-list',
                'mini' => 'glyphicon glyphicon-th',
                ],
                [
                'id' => 'change-mode',
                'class' => 'btn-group',
                'data-toggle' => 'buttons',
                // 'tag'         => 'span',
                'unselect' => null, // remove hidden field
                'item' => function ($index, $label, $name, $checked, $value) {
                    return '<button class = "btn btn-default " style="height:49px;width:50px;"><i class="'.$label.'"></i>'.
                        Html::radio($name, $checked,
                            ['value' => $value, 'class' => 'project-status-btn']).'</button>';
                },
                    ]
            );
        }

        public function getFilterButtons()
        {
            $return = '';
            if (!empty($this->states)) {
                $return .= '<label>Тип торгов </label>';
                foreach ($this->states as $key => $state) {

                    $return .= '<div>
                    <label>
                    <input type="checkbox" name="state_id[]" value="'.$key.'"'.
                        (in_array($key, $this->_filter['state_id']) ? 'checked' : '')
                        .'/>
                    </label> '
                        .$state.'  </div>';
                }
            }

            return $return;
        }
    }    
