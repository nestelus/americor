<?php

namespace common\components;

use common\widgets\ExtendBlock;
use Yii;

/**
 * Компонент View в MVC паттерне
 *
 */
class View extends \yii\web\View {

  /** @var string папка с шаблонами по умолчанию */
  public $defaultDir = 'default';

  /** @var array зарегестрированный HTML */
  public $html = [];

  /**
   * @inheritdoc
   */
  public function findViewFile($view, $context = null) {
    $path = parent::findViewFile($view, $context);

    if ($this->theme !== null) {
      $path = $this->theme->applyTo($path);
    }
    if (!is_file($path) && Yii::$app->controller !== null) {
      $file = Yii::$app->controller->module->getViewPath() . '/' . $this->defaultDir . '/' . ltrim($view, '/');
      if (pathinfo($file, PATHINFO_EXTENSION) !== '') {
        return $file;
      }
      if (strpos($file, '_tablePartToolbar_') > 0) {
        $file = Yii::$app->controller->module->getViewPath() . '/' . $this->defaultDir . '/' . '_tablePartToolbar';
        if (pathinfo($file, PATHINFO_EXTENSION) !== '') {
          return $file;
        }
      }
      if (strpos($file, '_tablePartEditor_') > 0) {
        $file = Yii::$app->controller->module->getViewPath() . '/' . $this->defaultDir . '/' . '_tablePartEditor';
        if (pathinfo($file, PATHINFO_EXTENSION) !== '') {
          return $file;
        }
      }
      $path = $file . '.' . $this->defaultExtension;

      if ($this->defaultExtension !== 'php' && !is_file($path)) {
        $path = $file . '.php';
      }

      if (!is_file($path)) {
        $curDir = dirname($path);
        return dirname(dirname(dirname(dirname($curDir . '../') . '../') . '../') . '../') . '/views/' . $this->defaultDir . '/' . ltrim($view, '/') . '.php';
      }
    }

    return $path;
  }

  /**
   * Открывает блок, который можно расширить в наследуемых шаблонах
   *
   * @param integer $id            идентификатор блока
   * @param bool    $renderInPlace вывести блок на месте
   *
   * @return ExtendBlock
   */
  public function beginExtBlock($id, $renderInPlace = false) {
    return ExtendBlock::begin(
                    [
                        'id' => $id,
                        'renderInPlace' => $renderInPlace,
                        'view' => $this,
                    ]
    );
  }

  /**
   * Закрывает расширяемый блок
   */
  public function endExtBlock() {
    ExtendBlock::end();
  }

  /**
   * Зегистрация html вначале или в конце body
   * @param $html
   * @param int $position
   * @param null $key
   */
  public function registerHtml($html, $position = self::POS_END, $key = null) {
    $key = $key ? : md5($html);
    $this->html[$position][$key] = $html;
  }

  /**
   * @inheritdoc
   */
  protected function renderBodyBeginHtml() {
    $lines = [];
    if (!empty($this->html[self::POS_BEGIN])) {
      $lines = $this->html[self::POS_BEGIN];
    }
    return implode("\n", $lines) . parent::renderBodyBeginHtml();
  }

  /**
   * @inheritdoc
   */
  protected function renderBodyEndHtml($ajaxMode) {
    $lines = [];
    if (!empty($this->html[self::POS_END])) {
      $lines = $this->html[self::POS_END];
    }
    return implode("\n", $lines) . parent::renderBodyEndHtml($ajaxMode);
  }

}
