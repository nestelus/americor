<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\components;

use DateTimeZone;

/**
 * Description of DateTime
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class DateTime extends \DateTime {

      //put your code here /** @var bool В каком формате приводить объект к строке (с временем или без) */
      public $withTime = true;

      /** SQL формат строки без времени */
      const DB_DATE_FORMAT = 'Y-m-d';

      /** SQL формат строки с временем */
      const DB_DATETIME_FORMAT = 'Y-m-d H:i:s';

      /** SQL формат строки времени */
      const DB_TIME_FORMAT = 'H:i:s';

      /** SQL IMAP формат строки с временем */
      const IMAP_DATETIME_FORMAT = 'j-M-Y';

      /**
       * Конструктор класса
       * @param string       $time
       * @param bool         $withTime
       * @param DateTimeZone $timezone
       */
      public function __construct($time = 'now', $withTime = true, DateTimeZone $timezone = null) {
            parent::__construct($time, $timezone);
            $this->withTime = $withTime;
      }

      /**
       * Магическая функция привидения объекта к строковому представлению
       * @return string
       */
      public function __toString() {
            return (string) $this->format($this->withTime ? self::DB_DATETIME_FORMAT : self::DB_DATE_FORMAT);
      }

}
