<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\components;

use dektrium\rbac\components\DbManager;

/**
 * Description of RbackDbManager
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class RbackDbManager extends DbManager {

      public function assign($role, $userId) {
            $this->revokeAll($userId);

            return parent::assign($role, $userId);
      }

      public function getRoleForUser($user_id) {
            $roles = $this->getRolesByUser($user_id);
            return $roles[0]->name;
      }

}
