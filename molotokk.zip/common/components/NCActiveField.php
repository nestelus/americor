<?php
namespace common\components;

use yii\widgets\ActiveField;
use yii\helpers\Html;

/**
 * Description of NCActiveField
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class NCActiveField extends ActiveField {

  public $model;

  /**
   * @inheritdoc
   */
  public function init() {
    parent::init();

    /* $hints = $this->model->hints();
      if (isset($hints[$this->attribute])) {
      $this->hint($hints[$this->attribute]);
      }
    $autoCompleteData = $this->model->autoCompleteData();
    if (isset($autoCompleteData[$this->attribute])) {
      if (is_callable($autoCompleteData[$this->attribute])) {
        $this->autoComplete(call_user_func($autoCompleteData[$this->attribute]));
      } else {
        $this->autoComplete($autoCompleteData[$this->attribute]);
      }
    }*/
  }

  /**
   * Переопределяем hiddenInput для вывода без label
   * @param array $options Массив опций
   * @return void|static
   */
  public function hiddenInput($options = []) {
    $options = array_merge($this->inputOptions, $options);
    $this->adjustLabelFor($options);
    return Html::activeHiddenInput($this->model, $this->attribute, $options);
  }

  public function fieldSet($options = []) {
    $output = '';
    foreach ($options as $field_name => $field) {
      $output .= $this->{$field['type']}($field['option']);
    }

    return Html::tag('div', $output, ['class = "field-set"']);
  }

}
