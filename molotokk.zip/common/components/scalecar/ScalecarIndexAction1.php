<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\components\scalecar;

use Yii;
use yii\rest\IndexAction;
use yii\data\ActiveDataProvider;
use common\models\auktaModels\Products;
use yii\db\Query;
use common\models\User;
use common\models\Profile;
use common\models\auktaModels\ProductProperties;
use common\models\auktaModels\PropertyReferrence;
use common\models\auktaModels\enumModels\StateProduct;
use common\models\auktaModels\ProductPhotos;
use common\models\auktaModels\Categories;

//use yii\sphinx\Query;
//use yii\sphinx\ActiveDataProvider;
//use molotokk\models\sphinx\Products;

/**
 * Description of ScalecarIndexAction1
 *
 * @author Vladimir
 */
class ScalecarIndexAction1 extends IndexAction
{
    const PROPERTY_ARTICUL  = 3;
    const PROPERTY_VENDOR   = 1;
    const PROPERTY_SCALE    = 5;
    const PROPERTY_CATEGORY = 1;

    public $startRow     = 1;
    public $max_per_page = 25;
    public $sort         = 'date';
    public $searchText;

    public function prepareDataProvider()
    {
        switch ($this->sort) {
            case 'date' :
                $sort = 'p.updated_at DESC';
                break;
            case 'aprice' :
                $sort = 'p.price ASC';
                break;
            case 'dprice' :
                $sort = 'p.price DESC';
                break;
            case 'scale' :
                $sort = 'scale ASC';
                break;
            case 'name' :
                $sort = 'name ASC';
                break;
            default:
                $sort = 'p.updated_at DESC';
        }

//        $photoQuery = new Query();
//        $photoQuery->select(['product_id', 'file_name'])
//            ->from(ProductPhotos::tableName())
//            ->where(['order' => 1]);


        $query = new Query();
        $query->select([
                'p.id',
                'p.name model',
                'CONCAT(up.first_name," ",up.last_name) name',
                'u.username user_name',
                'p.city user_city',
                'p.price',
                'articul.data articul',
                'vendor.value vendor',
                'scale.value scale',
                'CONCAT("'.Yii::getAlias(Yii::$app->params['urlPhotos']).'",p.id,"/",pp.file_name) photoUrl',
            ])
            ->from(Products::tableName().' p')
            ->innerJoin(User::tableName().' u', 'p.user_id = u.id')
            ->innerJoin(Profile::tableName().' up', 'p.user_id = up.user_id')
            ->innerJoin(Categories::tableName().' cat', 'p.category_id = cat.id')
            ->leftJoin(ProductProperties::tableName().' articul',
                ['p.id' => 'articul.product_id', 'articul.category_properties_id' => self::PROPERTY_ARTICUL])
            ->leftJoin(ProductProperties::tableName().' vendorid',
                [ 'p.id' => 'vendorid.product_id', 'vendorid.category_properties_id' => self::PROPERTY_VENDOR])
            ->leftJoin(PropertyReferrence::tableName().' vendor',
                'vendor.id = vendorid.property_referrence_id')
            ->leftJoin(ProductProperties::tableName().' scaleid',
                ['p.id' => 'scaleid.product_id', 'scaleid.category_properties_id' => self::PROPERTY_SCALE])
            ->leftJoin(PropertyReferrence::tableName().' scale',
                'scale.id = scaleid.property_referrence_id')
            ->leftJoin(ProductPhotos::tableName().'pp',
                ['p.id' => 'pp.product_id', 'pp.order' => 1])
            ->andWhere([
                'u.blocked_at' => NULL,
                'cat.parent_id' => self::PROPERTY_CATEGORY,
                'p.state_id' => [StateProduct::STATE_ON_AUCTION, StateProduct::STATE_ON_SALE]
            ])
            ->orderBy($sort);
        if (!empty($this->searchText)) {
            $query->andWhere(['or',
                ['like', 'p.name', $this->searchText],
                ['like', 'p.city', $this->searchText],
                ['like', 'articul.data', $this->searchText],
                ['like', 'vendor.value', $this->searchText],
                ]
            );
        }
        echo $query->createCommand()->rawSql;
        die();


        return new ActiveDataProvider([
            'query' => $query,
            'pagination' => [
                'pageSize' => $this->max_per_page,
                'page' => $this->startRow - 1,
            ],
        ]);
    }
}
