<?php

namespace common\widgets;

use yii\bootstrap\Widget;
use common\models\auktaModels\Products;
use yii\helpers\Html;

/**
 * Description of ShortProductWidget
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class ShortProductWidget extends Widget
{
      public $products;
      public $mode = 'short';

      public function init()
      {
            parent::init();

            if (!is_array($this->products))
            {
                  $this->products = [$this->products];
            }

            foreach ($this->products as $n => $product)
            {
                  if (!is_object($product))
                  {
                        $this->products[$n] = Products::findOne($product['id']);
                  }
            }
      }

      public function run()
      {

            $output = '<div class="product-list clearfix">';
            foreach ($this->products as $product)
            {

                  $output .= Html::tag('div',
                          $this->render($this->mode.'-product', [
                              'product' => $product,
                          ]), [
                          'id' => 'pj_product-item-'.$product->id,
                  ]);
            }
            $output .='</div>';
            return $output;
      }
}