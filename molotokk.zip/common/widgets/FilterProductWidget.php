<?php

namespace common\widgets;

use Yii;
use kartik\daterange\DateRangePicker;
use yii\bootstrap\Widget;
use yii\widgets\MaskedInput;

/**
 * Description of FilterProductList
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class FilterProductWidget extends Widget {

      public $params;

      public function run() {
            foreach ($this->params as $param)
            {
                  $fields[] = $this->renderField($param);
            }
            return $this->render('filter-product', [
                        'fields' => $fields,
            ]);
      }

}
