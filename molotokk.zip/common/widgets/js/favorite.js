/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

  $('.js_action-favorit').click(function(){
        product_id = $(this).attr('product_id');
            $.ajax({
                  url:"/profile/favorite/" + product_id +"/",
                  //dataType: 'json',
                  success: function(data){
                        if(data == 0){
                              $('.js_action-favorit[product_id =' + product_id + ']').html('Добавить в избранное');
                              $('#js_favorit-link-' + product_id).hide();
                        }
                        else {
                              $('.js_action-favorit[product_id =' + product_id + ']').html('Удалить из избранного');
                              $('#js_favorit-link-' + product_id ).show();
                        }
                  }
            });
        });
