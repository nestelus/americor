<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\widgets;

use yii\bootstrap\Widget;
use common\models\auktaModels\Articles;

/**
 * Description of ArticleMenuWidget
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class ArticleMenuWidget extends Widget
{
      public $type;

      public function init()
      {
            parent::init();
      }
}