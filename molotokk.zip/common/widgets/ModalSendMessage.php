<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\widgets;

use yii\bootstrap\Widget;

/**
 * Description of ModalSendMessage
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class ModalSendMessage extends Widget {

      public $profile;
      public $product_id;

      public function run() {

            return $this->render('modal-send-message', [
                        'profile'    => $this->profile,
                        'product_id' => $this->product_id,
            ]);
      }

}
