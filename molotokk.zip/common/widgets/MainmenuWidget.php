<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\widgets;
use yii\base\Widget;

/**
 * Description of MainmenuWidget
 *
 * @author Vladimir
 */
class MainmenuWidget extends Widget {
    
    public $mainMenuItems;


    public function init() {
        parent::init();
        
        if($this->mainMenuItems === NULL)
        {
            $this->mainMenuItems = array();
        }
        
    }
    
    public function run() {
      
        return $this->render('mainmenu',[
            'mainMenuItems' => $this->mainMenuItems,
        ]);
    }
}
