<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\widgets;

use yii\bootstrap\Widget;
use common\models\User;

/**
 * Description of ModalDataContactWidget
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class ModalDataContactWidget extends Widget
{
      public $user_id;
      public $is_modal = true;
      private $_property;
      private $_user;

      public function init()
      {

            $this->_user = User::findOne($this->user_id);
            $profile     = $this->_user->profile;
            if (!empty($profile->first_name))
            {
                  $this->_property['Имя'] = $profile->first_name;
            }
            if (!empty($profile->middle_name))
            {
                  $this->_property['Отчество'] = $profile->middle_name;
            }
            if (!empty($profile->last_name))
            {
                  $this->_property['Фамилия'] = $profile->last_name;
            }

            $this->_property['E-mail'] = $this->_user->email;
            if (!empty($profile->phone))
            {
                  $this->_property['Телефон'] = $profile->phone;
            }
            if (!empty($profile->region_id))
            {
                  $this->_property['Регион'] = $profile->region->name;
            }
            if (!empty($profile->city))
            {
                  $this->_property['Город'] = $profile->city;
            }
      }

      public function run()
      {
            return $this->render('modal-data-contact',
                    [
                    'properties' => $this->_property,
                    'user_id' => $this->_user->id,
                    'username' => $this->_user->username,
                    'is_modal' => $this->is_modal,
            ]);
      }
}