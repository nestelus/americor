<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\widgets;

use yii\base\Widget;
use Yii;

/**
 * Description of HeaderWidget
 *
 * @author Vladimir
 */
class HeaderWidget extends Widget {

    public function init() {
        parent::init();
    }

    public function run() {
        if ($id = Yii::$app->user->getId()) {
            $user = \common\models\User::findIdentity($id);
        } else {
            $user = NULL;
        }
        return $this->render('header', [
                    'user' => $user,
        ]);
    }

}
