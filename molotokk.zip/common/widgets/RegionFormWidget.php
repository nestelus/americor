<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\widgets;

use yii\base\Widget;
use common\models\auktaModels\Region;
use common\models\auktaModels\City;

/**
 * Description of RegionFormWidget
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class RegionFormWidget extends Widget
{
    public $model;
    public $form;

    /**
     * @var bool отображение разделов виджета в строку
     */
    public $inline = false;
    private $_city        = null;
    private $_region_name = null;
    private $_cityname    = null;
    private $_city_id     = null;
    private $_region_id   = null;
    private $_county_id   = 3159;
    private $_region      = null;

    public function init()
    {
        $this->_cityname  = $this->model->city;
        $this->_region_id = $this->model->region_id;
        if (!is_null($this->_region_id)) {
            $this->_region = Region::findOne($this->_region_id);
            if ($this->_region) {
                $this->_region_name = $this->_region->name;
                $this->_county_id   = $this->_region->country_id;
            }
        }
        $this->_city = City::findOne([
                'name' => $this->_cityname,
                'region_id' => $this->_region_id,
        ]);
        if (!$this->_city) {
            $this->_city = new City([
                'country_id' => $this->_county_id,
                'region_id' => $this->_region_id,
            ]);
        }
    }

    public function run()
    {
        $form = $this->inline ? 'region_form_inline' : 'region_form';
        return $this->render($form,
                [
                'model' => $this->model,
                'form' => $this->form,
                'country_id' => $this->_county_id,
                'city' => $this->_city,
                'region_name' => $this->_region_name,
        ]);
    }
}
