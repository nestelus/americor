<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\widgets;

use yii\bootstrap\Widget;

/**
 * Description of PropertyFieldWidget
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class PropertyFieldWidget extends Widget
{
    public $model;
    public $attribute;
    public $properties;

    public function init()
    {
        parent::init();
    }

    public function run()
    {
        $output = '';
        foreach ($this->properties as $key => $property) {
            $output .= $property->renderField($key);
        }
        return $output;
    }
}
