<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * @var $mainMenuItems array Description
 * @var $menuItemData array
 */
?>
<div id="Menu">
    <div id="Points">
        <div class="Content">
            <ul>
              
                 <?php foreach($mainMenuItems as $menuItem => $menuItemData): 
                   
                   ?>
                <li class="<?= (Yii::$app->getRequest()->url === $menuItemData['menuURL']) ? 'Selected' : '' ?>">
                    <i>
                        <a href="<?= $menuItemData['menuURL'] ?>" class="<?= $menuItemData['SelectedItem'] ? 'Marked' : '' ?>"><?= $menuItem ?></a>
                    </i>
                </li>
                <?php endforeach; ?>
             
            </ul>
            <?php
            $sqlDayModel = "
            SELECT deProducts.PRODUCT_ALIAS_NAME
            FROM deProducts, deVendors, deCatalog, deDayModels
            WHERE
            deProducts.VENDOR_ID = deVendors.VENDOR_ID
            AND deProducts.CATALOG_ID = deCatalog.CATALOG_ID
            AND deDayModels.PRODUCT_ID = deProducts.PRODUCT_ID
            AND DATE(deDayModels.DATE) = DATE(NOW())
            AND deDayModels.PRICE = deProducts.PRICE_SPECIAL
            AND deProducts.IS_DELETED != 1
            AND deProducts.IS_PUBLISHED = 1
            AND deProducts.IS_EXPIRED != 1
            AND deCatalog.IS_DELETED != 1
            AND deCatalog.IS_PUBLISHED = 1
            AND deVendors.IS_DELETED != 1
            AND deVendors.IS_PUBLISHED = 1
            LIMIT 1
            ";
            $resultDayModel = @mysql_query($sqlDayModel);
            if (@mysql_num_rows($resultDayModel) > 0) {
            $dayModel = @mysql_fetch_array($resultDayModel);
            ?>

            <form action="<?= @GetItemURL($dayModel['PRODUCT_ALIAS_NAME']) ?>" method="get">
                <div class="b-button b-button-day-model button-style-marked button-size-normal">
                    <input type="submit" value="Модель дня" id="jModelDay" />
                </div>
            </form>
            <?php
            }
            @mysql_free_result($resultDayModel);
            ?>
        </div>
    </div>
    <div id="Search">
        <div class="Content">
            <form name="SiteSearch" action="/search/" method="get">
                <input name="q" value="<?= !empty($searchData['TEXT']) ? $searchData['TEXT'] : '' ?>" type="text" class="SearchField" id="jQuickSearchText" placeholder="название модели, артикул" style="width:205px" />
                <div class="Button SearchButton FloatRight"><i><i><i><i><input type="submit" value="Поиск" title="Искать" /></i></i></i></i></div>
                <input name="vm" value="text" type="hidden" />
            </form>
        </div>
    </div>
</div>


