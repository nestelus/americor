<?php
/* @var $this yii\web\View */
/* @var $product common\models\Products */

use yii\helpers\Html;
use common\models\auktaModels\enumModels\StateProduct;
use common\components\countTimer\CountTimer;

$photo        = $product->getMainPhoto();
$profile      = $product->profile;
$items_action = $product->getItemsAction();
$category     = $product->category;
?>
<div class="product-mini-item">
    <div class="photo-img">
        <?=
        Html::a(
            Html::img(
                $photo ? $photo->getUrlPhoto(263, 200) : '/img/nophoto/nophoto.png',
                [
//                'width' => 263,
//                'height' => 200,
                ]
            ), $product->getUrl()
        );
        ?>
    </div>
    <div class="product-name">
        <?= Html::a($product->name, $product->getUrl()); ?>
    </div>
    <div class="product-info clearfix">
        <div class="price pull-left">
            <?= number_format($product->price, 0, '.', ' ').'  '.Yii::$app->params['currency'] ?>
        </div>
        <div class="countbids pull-right">
            <?php
            switch ($product->state_id) :
                case StateProduct::STATE_ON_SALE:
                    ?>
                    <?= Yii::t('products', 'Купить сейчас') ?>
                    <?php
                    break;
                case StateProduct::STATE_ON_AUCTION:
                    ?>
                    <?= Yii::t('products', 'ставок').':  '.count($product->auctionStakes) ?>
                    <?php
                    break;
                case StateProduct::STATE_ON_SOLD :
                    ?>
                    <?= Yii::t('products', 'Продан') ?>
                    <?=
                    Yii::t('user', '{0, date, MMMM dd, YYYY HH:mm}',
                        [$product->complete_at])
                    ?>
                    <?php break; ?>

            <?php endswitch; ?>
            <p class="countdown">
                <?php
                if (in_array(
                        $product->state_id,
                        [
                        StateProduct::STATE_ON_AUCTION,
                        StateProduct::STATE_ON_SALE,
                        ]
                    )) {
                    echo CountTimer::widget(
                        [
                            'id' => 'cdt-'.$product->id,
                            'pluginOptions' => [
                                'autostart' => true,
                                'countdown' => true,
                                'startAt' => ($product->time_end - time()) * 1000,
                                'stopAt' => 0,
                            ],
                        ]
                    );
                    // echo '&nbsp;до окончания';
                } else {
                    ?>
                    <span class="red">
                        <?=
                        $product->complete_at ? Yii::t('user',
                                '{0, date, d.m.Y в H:mm}',
                                [$product->complete_at]) : ''
                        ?>
                    </span>
                    <?php
                }
                ?>
            </p>
        </div>

    </div>
</div>


