<?php
/* @var $this yii\web\View */
/* @var $model common\models\auktaModels\AuktaModel */
/* @var $form yii\bootstrap\ActiveForm */
use yii\bootstrap\Html;
use common\models\auktaModels\Country;
use yii\helpers\ArrayHelper;
use kartik\depdrop\DepDrop;
use yii\helpers\Url;

?>
<div class="row">
    <div class="col-md-4">
        <?=
        $form->field(
            $city,
            'country_id',
            [
                'template' => "{beginWrapper} {input} {error} {endWrapper}",
                'horizontalCssClasses' => ['wrapper' => 'col-md-12'],
            ]
        )->dropDownList(
            ArrayHelper::map(Country::find()->orderBy('name')->asArray()->all(), 'id', 'name'),
            [
                'class' => 'form-control',
                'id' => 'city_country_id',
            ]
        )
        ?>
    </div>
    <div class="col-md-4">
        <?=
        $form->field(
            $model,
            'region_id',
            [
                'template' => "{beginWrapper} {input} {error} {endWrapper}",
                'horizontalCssClasses' => ['wrapper' => 'col-md-12'],
            ]
        )->widget(
            DepDrop::classname(),
            [
                'type' => DepDrop::TYPE_SELECT2,
                'data' => [$model->region_id => $region_name],
                'options' => ['id' => 'city_region_id'],
                'pluginOptions' => [
                    'language' => 'ru',
                    'initialize' => true,
                    'depends' => ['city_country_id'],
                    'placeholder' => 'Выберите регион',
                    'url' => Url::to(['/city/get-regions']),
                ],
            ]
        );
        ?>
    </div>
    <div class="col-md-4">
        <?= Html::hiddenInput('cityname', $model->city, ['id' => 'cityname']); ?>
        <?=
        $form->field(
            $model,
            'city',
            [
                'template' => "{beginWrapper} {input} {error} {endWrapper}",
                'horizontalCssClasses' => ['wrapper' => 'col-md-12'],
            ]
        )->widget(
            DepDrop::classname(),
            [
                'type' => DepDrop::TYPE_SELECT2,
                'data' => [$model->city => $model->city],
                'options' => ['id' => 'city'],
                'select2Options' => [
                    'pluginOptions' => [
                        'tags' => true,
                    ],
                ],
                'pluginOptions' => [
                    'language' => 'ru',
                    'depends' => ['city_region_id'],
                    'placeholder' => 'Выберите город',
                    'url' => Url::to(['/city/get-city']),
                    'params' => ['cityname'],
                ],
            ]
        );
        ?>
    </div>
</div>
