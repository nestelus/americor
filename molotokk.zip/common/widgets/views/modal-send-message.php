<?php
/* @var $this yii\web\View */
/* @var $user common\models\User */

use yii\widgets\ActiveForm;
use common\models\auktaModels\Messages;
use yii\helpers\Html;
use yii\bootstrap\Modal;
use yii\helpers\Url;

$message = new Messages();

Modal::begin([
    'options' => [
        'id' => 'send_'.$product_id,
    ],
    'header' => 'Новое сообщение',
]);
?>
<div class="row">
    <div class="col-lg-6">
        <?= $profile->last_name ?> <?= $profile->first_name ?><br>
        Город: <?= $profile->city ? : 'Не указан' ?>, Регион: <?=
        $profile->region ? $profile->region->name : 'Не указан'
        ?>
    </div>
    <div class="col-lg-6">
        <?=
        Html::a('Перейти к диалогу',
            Url::to(['messages/messages', 'visavi_id' => $profile->user_id, 'lot_id' => $product_id]));
        ?>
    </div>
</div>

<?php
$form = ActiveForm::begin([
        'id' => 'form-singl-send-'.$product_id,
        'action' => '#',
        // 'option' => [],
    ]);
?>
<?= $form->field($message, 'from_id')->hiddenInput(['value' => Yii::$app->user->id])->label(FALSE); ?>
<?= $form->field($message, 'whom_id')->hiddenInput(['value' => $profile->user_id])->label(FALSE); ?>
<?= $form->field($message, 'product_id')->hiddenInput(['value' => $product_id])->label(FALSE); ?>
<?= $form->field($message, 'is_system')->hiddenInput(['value' => 0])->label(FALSE); ?>


<?=
$form->field($message, 'message')->textarea([
    'placeholder' => 'Введите сообщение',
]);
?>

<?= Html::submitButton('Отправить', [ 'class' => 'btn btn-success']); ?>

<?php ActiveForm::end(); ?>

<?php Modal::end(); ?>

<?php
$js   = <<<JS
  $("#form-singl-send-$product_id").on('beforeSubmit',function() {
                jQuery.ajax({
                    url: "/messages/single-send/",
                    type: "POST",
                    dataType: "json",
                    data: $(this).serialize(),
                    success: function(response) {
                        $(".close").click();
                    },
                    error: function(response) {
                         alert(":-(");
                    }
                });
                return false;
            });
JS;
$this->registerJs($js);



