<?php
/* @var $this yii\web\View */
/* @var $property array */

use yii\helpers\Html;
use yii\bootstrap\Modal;
?>
<?php
if ($is_modal)
{
      Modal::begin([
          'options' => [
              'id' => 'contact-data_'.$user_id,
          ],
          'header' => 'Конактные данные '.$username,
      ]);
}
?>
<div class="panel panel-default">

  <div class="panel-body">

    <?php foreach ($properties as $name => $property) : ?>
          <div class="row">
            <div class="col-md-6 text-right">
              <?= $name ?>:
            </div>
            <div class="col-md-6 text-left">
              <strong> <em>
                  <?= $property; ?>
                </em></strong>
            </div>
          </div>
    <?php endforeach; ?>


  </div>

</div>
<?php
if ($is_modal)
{
      Modal::end();
}
?>
