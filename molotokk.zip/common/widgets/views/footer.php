<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

?>

<div id="Footer" class="mBottom10" itemscope itemtype="http://schema.org/Organization">
    <div class="Content pBottom10">
        <div class="Float fw200">
            <div class="pRight20 pLeft20">
                &copy;<?= date("Y") ?> <span itemprop="name">ООО Нексткар</span><br />
                <a href="mailto:<?= Yii::$app->params['public_email']; ?>" itemprop="email"><?= Yii::$app->params['public_email']; ?></a>
                <br /><br />ОГРН 1097847154305
                <br /><br />
                <a href="/testimonials/">Отзывы покупателей</a><br />
                <a href="/feedback/">Оставить отзыв</a><br />
                <a href="/track-my-order/">Отследить заказ</a>
            </div>
        </div>
        <div class="Float fw200">
            <div class="pRight20 pLeft20">
                <div class="mBottom10" itemprop="address" itemscope itemtype="http://schema.org/PostalAddress">
                    <span itemprop="addressLocality">Москва</span><br />
                    <span itemprop="streetAddress">Багратионовский проезд, 7</span><br />
                    <span itemprop="telephone">8 (495) 212-18-43</span>
                </div>

                <div itemprop="address" itemscope itemtype="http://schema.org/PostalAddress">
                    <span itemprop="addressLocality">Санкт-Петербург</span><br />
                    <span itemprop="streetAddress">пр. Тореза, 35 корп.3</span><br />
                    <span itemprop="telephone">8 (812) 334-18-43</span>
                </div>
                <!--
                Часы работы:<br /><span itemprop="openingHours" datetime="Mo,Tu,We,Th,Fr 14:00−19:00">Пн-Пт с 14:00 до 19:00</span><br /><br />
                -->
            </div>
        </div>
        <div class="Float fw200">
            <div class="pRight20 pLeft20 pBottom5">
                <a href="http://vk.com/scalecar" target="_blank"><img src="/images/we-are-on-vkontakte.png" alt="Мы ВКонтакте" title="Мы ВКонтакте" /></a>
            </div>
            <div class="pRight20 pLeft20 pBottom5">
                <a href="http://odnoklassniki.ru/scalecar/" target="_blank"><img src="/images/we-are-on-odnoklassniki.png" alt="Мы в Одноклассниках" title="Мы в Одноклассниках" /></a>
            </div>
            <div class="pRight20 pLeft20">
                <a href="http://www.facebook.com/scalecar" target="_blank"><img src="/images/we-are-on-facebook.png" alt="Мы на Facebook" title="Мы на Facebook" /></a>
            </div>
            <?/*
            <div class="pRight20 pLeft20">
                <a href="http://instagram.com/scalecar" target="_blank"><img src="/images/scalecar-on-instagram.png" alt="Мы на Instagram" title="Мы на Instagram" /></a>
            </div>
            */?>
        </div>
        <div class="Float">
            <div class="pLeft20">
                <div class="mBottom20"><a
                    href="/">Главная</a> | <a
                    href="/models/">Все модели</a> | <a
                    href="/catalog/archive/">Архив моделей</a>
                </div>
                <div>
                    <div>Принимаем банковские карты и Яндекс.Деньги</div>
                    <div><img src="/images/we-allow-payments.png" alt="" title="" /></div>
                </div>
            </div>
        </div>
    </div>
</div>

<? if (!constant("YII_DEBUG")) {
   
}?>



