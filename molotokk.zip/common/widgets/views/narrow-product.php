<?php
/* @var $this yii\web\View */
/* @var $product common\models\Products */

use yii\helpers\Html;
use Yii;
use yii\bootstrap\Nav;
use common\models\auktaModels\enumModels\StateProduct;
use common\components\countTimer\CountTimer;
use common\widgets\ModalSendMessage;
use common\widgets\ModalDataContactWidget;

$photo        = $product->getMainPhoto();
$profile      = $product->profile;
$items_action = $product->getItemsAction();
$category     = $product->category;
?>
<div class="panel narrow-product">


    <div class="row">
        <div class="col-md-1">
            <?=
            Html::a(Html::img($photo ? $photo->getUrlPhoto(50, 50) : '',
                    [
                    'width' => 50,
                    'hieght' => 50,
                ]), $product->getUrl());
            ?>


        </div>
        <div class="col-md-11">
            Лот № <?= $product->id ?>        <?= Html::a($product->name,
                $product->getUrl()); ?>

            <div class="row">
                <div class="col-md-3">
                    <div class="price">
<?= number_format($product->price, 0, '.', ' ').'  '.Yii::$app->params['currency'] ?>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="countbids">
                        <?php
                        switch ($product->state_id) :
                            case StateProduct::STATE_ON_SALE:
                                ?>
                                <?=
                                Yii::t('products', 'Купить сейчас')
                                ?>
                                <?php
                                break;
                            case StateProduct::STATE_ON_AUCTION:
                                ?>
                                <?=
                                Yii::t('products', 'ставок').':  '.count($product->auctionStakes)
                                ?>
                                <?php
                                break;
                            case StateProduct::STATE_ON_SOLD :
                                ?>
                                <?=
                                Yii::t('products', 'Продан')
                                ?>

                                <?=
                                Yii::t('user', '{0, date, MMMM dd, YYYY HH:mm}',
                                    [$product->complete_at])
                                ?>
                            <?php break; ?>
                    <?php endswitch; ?>
                    </div>
                    <?=
                    Nav::widget([
                        'items' => [
                            [
                                'label' => Yii::t('products', 'Действия'),
                                'items' => $items_action,
                            ],
                        ]
                    ])
                    ?>
                </div>
                <div class="col-md-5 text-right">

                    <span id="js_favorit-link-<?= $product->id ?>"  <?php
                    if (!($product->isMyFavorite())) {
                        echo 'style="display:none"';
                    }
                    ?> >
                        <i class="glyphicon glyphicon-heart text-muted"></i>
                        <?=
                        Html::a(Yii::t('products', 'В избранном'),
                            '/profile/my-favorite/')
                        ?>
                    </span>
                </div>

            </div>

        </div>
    </div>

</div>
<?php if ($product->state_id == StateProduct::STATE_ON_SOLD): ?>
    <?php if ($product->user_id == Yii::$app->user->id): ?>
        <?=
        ModalDataContactWidget::widget([
            'user_id' => $product->buyer_id,
        ]);
        ?>
    <?php endif; ?>

    <?php if ($product->buyer_id == Yii::$app->user->id): ?>
        <?=
        ModalDataContactWidget::widget([
            'user_id' => $product->user_id,
        ]);
        ?>
    <?php endif; ?>
<?php endif ?>

<?=
ModalSendMessage::widget([
    'profile' => $product->profile,
    'product_id' => $product->id,
]);
?>
<?php
$js = <<< JS
        $('.js_action-favorit').click(function(){
        product_id = $(this).attr('product_id');
            $.ajax({
                  url:"/profile/favorite/" + product_id +"/",
                  //dataType: 'json',
                  success: function(data){
                        if(data == 0){
                              $('.js_action-favorit[product_id =' + product_id + ']').html('Добавить в избранное');
                              $('#js_favorit-link-' + product_id).hide();
                        }
                        else {
                              $('.js_action-favorit[product_id =' + product_id + ']').html('Удалить из избранного');
                              $('#js_favorit-link-' + product_id ).show();
                        }
                  }
            });
        });
JS;

$this->registerJs($js);
