<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* @var $this yii\web\View */
/* @var $model common\models\auktaModels\AuktaModel */
/* @var $form yii\bootstrap\ActiveForm */

use yii\bootstrap\Html;
use common\models\auktaModels\Country;
use yii\helpers\ArrayHelper;
use kartik\depdrop\DepDrop;
use yii\helpers\Url;

?>
<?=

$form->field($city, 'country_id')->dropDownList(ArrayHelper::map(Country::find()->orderBy('name')->asArray()->all(), 'id', 'name'), [
    'class' => 'form-control',
    'id'    => 'city_country_id',
])
?>
<?=

$form->field($model, 'region_id')->widget(DepDrop::classname(), [
    'type'          => DepDrop::TYPE_SELECT2,
    'data'          => [$model->region_id => $region_name],
    'options'       => ['id' => 'city_region_id'],
    'pluginOptions' => [
        'language'    => 'ru',
        'initialize'  => true,
        'depends'     => ['city_country_id'],
        'placeholder' => 'Регион...',
        'url'         => Url::to(['/city/get-regions'])
    ]
]);
?>
<?= Html::hiddenInput('cityname', $model->city, ['id' => 'cityname']); ?>
<?=

$form->field($model, 'city')->widget(DepDrop::classname(), [
    'type'           => DepDrop::TYPE_SELECT2,
    'data'           => [$model->city => $model->city],
    'options'        => ['id' => 'city'],
    'select2Options' => [
        'pluginOptions' => [
            'tags' => true,
        ],
    ],
    'pluginOptions'  => [
        'language'    => 'ru',
        // 'initialize' => true,
        'depends'     => ['city_region_id'],
        'placeholder' => 'Населённый пункт...',
        'url'         => Url::to(['/city/get-city']),
        'params'      => ['cityname'],
    ]
]);
?>
