<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use yii\bootstrap\Nav;
?>
<div class="products-list panel panel-default">
  <div class="products-list panel panel-heading">
    <?= $header ?>
  </div>
  <div class="panel panel-body">
    <?php
    echo Nav::widget([
        'items' => $items,
    ]);
    ?>

  </div>

</div>
