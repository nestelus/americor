<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/** 
 * @var $user common\User Description 
 * @var $this yii\web\View 
 */
use Yii;

?>
<!-- no script notification -->
<noscript>
    <div class="NoScriptMessage">Для работы с этим сайтом требуется поддержка Javascript. Ваш браузер не поддерживает JavaScript или поддержка JavaScript выключена. Пожалуйста, включите поддержку Javascript или откройте сайт в другом браузере, поддерживающем Javascript.</div>
</noscript>
<!-- no cookie notification -->

<!--noindex-->

<div class="NoScriptMessage Hidden" id="jNoCookieMessage">Для работы с этим сайтом требуется поддержка Cookie. Ваш браузер не поддерживает Cookie или поддержка Cookie выключена. Пожалуйста, включите поддержку Cookie или откройте сайт в другом браузере, поддерживающем Cookie.</div>
<!--/noindex-->
<?=  $this->render('cart'); ?>

    <div id="Header">
    <?= $this->render('locations'); ?>
    <div id="Logo"><a href="/"><img
        src="/images/logo.png" alt="Магазин моделей ScaleCar.Ru" title="Магазин моделей ScaleCar.Ru" /></a><img
        src="/images/age.png" alt="" title="" /></div>
    <div id="Account" class="Block <?= (isset($user) && $user->IS_VIP == 1) ? 'Vip' : '' ?>">
        <? if (!Yii::$app->user->isGuest): ?>
        <div class="Label"></div>
        <div class="Content"><a href="/account/">личный кабинет</a></div>
        <? else: ?>
        <div class="Label">Покупателям</div>
        <div class="Content"><a href="/login/">вход</a> | <a href="/register/">регистрация</a></div>
        <? endif; ?>
    </div>
    <div id="CartEmpty" class="Block Hidden">
        <div class="Label">ваш заказ</div>
       <div class="Content" id="jCartEmpty">корзина пуста</div>
    </div>
</div>