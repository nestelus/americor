<?php
/* @var $this yii\web\View */
/* @var $product molotokk\models\Products */

use yii\helpers\Html;
use yii\bootstrap\Nav;
use common\models\auktaModels\enumModels\StateProduct;
use common\components\countTimer\CountTimer;
use common\widgets\ModalSendMessage;
use common\widgets\ModalDataContactWidget;
use yii\helpers\Url;

$photo        = $product->getMainPhoto();
$profile      = $product->profile;
$items_action = $product->getItemsAction();
$category     = $product->category;
?>
<div class="shop-product-block clearfix">
    <div class="shop-product-image pull-left">
        <?=
        Html::a(
            Html::img(
                $photo ? $photo->getUrlPhoto(156, 141) : '' ),
            $product->getUrl(true)
        );
        ?>
    </div>
    <div class="shop-product-description pull-left">
        <div class="description">
            <?= Html::a($product->name, $product->getUrl()); ?>
        </div>

        <p class="region">
            <?=
            $product->region ? $product->region->name : Yii::t('products',
                    'Регион не указан')
            ?>
        </p>        
        <p class="countdown">
            <?php
            if (in_array(
                    $product->state_id,
                    [
                    StateProduct::STATE_ON_AUCTION,
                    StateProduct::STATE_ON_SALE,
                    ]
                )) {
                echo CountTimer::widget(
                    [
                        'id' => 'cdt-'.$product->id,
                        'pluginOptions' => [
                            'autostart' => true,
                            'countdown' => true,
                            'startAt' => ($product->time_end - time()) * 1000,
                            'stopAt' => 0,
                        ],
                    ]
                );
                // echo '&nbsp;до окончания';
            } else {
                ?>
                <span class="red">
                    <?=
                    $product->complete_at ? 'Завершен '.Yii::t('user',
                            '{0, date, dd.MM.Y в H:mm}', [$product->complete_at])
                            : ''
                    ?>
                </span>
                <?php
            }
            ?>
        </p>
        <p class="stake">
            <?php
            if ($product->is_auction) {
                $stakes = count($product->auctionStakes);
                if (in_array($stakes, [11, 12, 13, 14])) {
                    $gradient = 'пользователей';
                } else {
                    $lastNumber = (int) substr((string) $stakes,
                            (strlen((string) $stakes) - 1), 1);
                    if (in_array($lastNumber, [0, 5, 6, 7, 8, 9])) {
                        $gradient = "пользователей";
                    } else {
                        if ($lastNumber == 1) {
                            $gradient = "пользователь";
                        } else {
                            if (in_array($lastNumber, [2, 3, 4])) {
                                $gradient = "пользователя";
                            } else {
                                $gradient = "пользователь";
                            }
                        }
                    }
                }
                echo '<span class="font-weight-bold">'.$stakes.' '.$gradient.'</span> сделали ставку';
            }
            ?>
        </p>
    </div>
    <div class="shop-product-price pull-left">
        <div class="js_action-favorit elected <?=
        (!($product->isMyFavorite()) ? 'elected-off' : 'elected-on')
        ?>"
             id="js_favorit-link-<?= $product->id ?>" data-id="<?= $product->id ?>">
        </div>
        <div class="price">
            <?= number_format($product->price, 0, '.', ' ').'  '.Yii::$app->params['currency'] ?>
            <?php if (!empty($items_action)): ?>
                <?=
                Nav::widget([
                    'items' => [
                        [
                            'label' => Yii::t('products', 'Действия'),
                            'items' => $items_action,
                        ],
                    ],
                    'options' => [
                        'class' => 'menu-actions',
                    ]
                ])
                ?>
            <?php endif; ?>
        </div>
        <div class="user">
            <a href="<?= Url::to(['profile/view']) ?><?= $product->user_id ?>">
                <?= $product->user->username ?>(<?= $product->profile->rating ?>)
            </a>
        </div>
    </div>
</div>

<?php if ($product->state_id == StateProduct::STATE_ON_SOLD): ?>
    <?php if ($product->user_id == Yii::$app->user->id): ?>
        <?=
        ModalDataContactWidget::widget(
            [
                'user_id' => $product->buyer_id,
            ]
        );
        ?>
    <?php endif; ?>

    <?php if ($product->buyer_id == Yii::$app->user->id): ?>
        <?=
        ModalDataContactWidget::widget(
            [
                'user_id' => $product->user_id,
            ]
        );
        ?>
    <?php endif; ?>
<?php endif ?>

<?=
ModalSendMessage::widget([
    'profile' => $product->profile,
    'product_id' => $product->id,
]);
?>


<?php
$js = <<< JS
        $('.js_action-favorit').click(function(){
            var favorite = $(this),
            product_id = favorite.data('id');
            $.ajax({
                  url:"/profile/favorite/" + product_id +"/",
                  success: function(data){
                        if(data == 0){
                            favorite.addClass('elected-off').removeClass('elected-on');
                        } else {
                            favorite.addClass('elected-on').removeClass('elected-off');
                        }
                  }
            });
    return false;
        });
JS;

$this->registerJs($js);
