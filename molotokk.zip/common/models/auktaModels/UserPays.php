<?php

namespace common\models\auktaModels;

use Yii;
use yii\behaviors\TimestampBehavior;
use common\models\User;
use common\models\auktaModels\Products;
use common\models\auktaModels\AuktaModel;

/**
 * This is the model class for table "{{%user_pays}}".
 *
 * @property integer $id
 * @property integer $user_id
 * @property string $amount
 * @property integer $direction
 * @property integer $type_id
 * @property string $data
 * @property integer $created_at
 * @property integer $updated_at
 *
 * @property User $user
 */
class UserPays extends AuktaModel {

      const DIRECTION_IN     = 1;
      const DIRECTION_OUT    = 2;
      const STATUS_REQUESTED = 0;
      const STATUS_CHECKED   = 1;
      const STATUS_RESULTED  = 2;
      const STATUS_CONFIRMED = 3;

      /**
       * @inheritdoc
       */
      public static function tableName() {
            return '{{%user_pays}}';
      }

      /**
       * @inheritdoc
       */
      public function rules() {
            return [
                [['user_id', 'amount', 'direction', 'status'], 'required'],
                [['user_id', 'direction', 'type_id', 'created_at', 'updated_at', 'product_id'], 'integer'],
                [['amount'], 'number'],
                [['data', 'payment_system'], 'string'],
                [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(), 'targetAttribute' => ['user_id' => 'id']],
                [['product_id'], 'exist', 'skipOnError' => true, 'targetClass' => Products::className(), 'targetAttribute' => ['user_id' => 'id']],
            ];
      }

      /**
       * @inheritdoc
       */
      public function attributeLabels() {
            return [
                'id'         => Yii::t('users', 'ID'),
                'user_id'    => Yii::t('users', 'User ID'),
                'amount'     => Yii::t('users', 'Сумма'),
                'direction'  => Yii::t('users', 'Входящий/Исходящий'),
                'type_id'    => Yii::t('users', 'Вид платежа'),
                'data'       => Yii::t('users', 'Реквизиты'),
                'status'     => Yii::t('users', 'Статус'),
                'created_at' => Yii::t('users', 'Создан'),
                'updated_at' => Yii::t('users', 'Изменен'),
            ];
      }

      public function behaviors() {
            return [
                [
                    'class' => TimestampBehavior::className(),
                ],
            ];
      }

      public function fillData($data) {
            if (isset($data['pg_sig']))
            {
                  unset($data['pg_sig']);
            }
            $this->updateAttributes(['data' => json_encode($data)]);
      }

      public function paymentRequest($event) {
            if ($this->status == self::STATUS_REQUESTED)
            {
                  $this->updateAttributes([
                      'payment_id' => $event->gatewayData['pg_payment_id'],
                      'status'     => self::STATUS_RESULTED,
                  ]);

                  $event->handled = true;
            }
      }

      public function paymentSuccess($event) {
            $user        = $this->user;
            $balance_new = $user->balance + $this->amount;
            $this->updateAttributes(['status' => self::STATUS_CONFIRMED]);

            $user->updateAttributes(['balance' => $balance_new]);
      }

      /**
       * @return \yii\db\ActiveQuery
       */
      public function getUser() {
            return $this->hasOne(User::className(), ['id' => 'user_id']);
      }

      public function getProduct() {
            return $this->hasOne(Products::className(), ['id' => 'product_id']);
      }

}
