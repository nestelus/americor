<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\auktaModels\enumModels;

use common\models\EnumModel;

/**
 * Description of ArticleTypes
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class ArticleTypes extends EnumModel {

    //  const ARTICLE_OTHER = 0;
    const ARTICLE_HELP = 1;

    // const ARTICLE_LANDING = 2;

    public static $list = [
        //  self::ARTICLE_OTHER   => 'Other article',
        self::ARTICLE_HELP => 'Help',
            //  self::ARTICLE_LANDING => 'Landing',
    ];

}
