<?php

namespace common\models\auktaModels\enumModels;

use common\models\EnumModel;

/**
 * Description of RatingType
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class RatingType extends EnumModel {

      const RATING_NEGATIVE = -1;
      const RATING_NEUTRAL  = 0;
      const RATING_POSITIVE = 1;

      public static $list = [
          self::RATING_NEGATIVE => 'Negative Feedback',
          self::RATING_NEUTRAL  => 'Neutral Feedback',
          self::RATING_POSITIVE => 'Positive Feedback',
      ];

}
