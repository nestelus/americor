<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\auktaModels\enumModels;

use common\models\EnumModel;

/**
 * Description of PayMethod
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class PayMethod extends EnumModel
{
    const TYPE_BY_AGREEMENT   = 0;
    const TYPE_BANK_TRANSFER  = 1;
    const TYPE_CASH_PRIVATE   = 2;
    const TYPE_ONLINE         = 3;
    const TYPE_POST_TRANSFER  = 4;
    const TYPE_MOBILE_BALANCE = 5;
    const TYPE_BANK_CARD      = 6;
    const TYPE_FROM_BANK_CARD = 7;

    public static $list = [
        self::TYPE_BY_AGREEMENT => 'По договоренности',
        self::TYPE_BANK_TRANSFER => 'Банковский перевод',
        self::TYPE_CASH_PRIVATE => 'Наличными при встрече',
        self::TYPE_ONLINE => 'On-line перевод',
        self::TYPE_POST_TRANSFER => 'Почтовый перевод',
        self::TYPE_MOBILE_BALANCE => 'Пополнение баланса сотового телефона',
        self::TYPE_BANK_CARD => 'На банковскую карту',
        self::TYPE_FROM_BANK_CARD => 'Оплата банковской картой',
    ];

}
