<?php

/**
 * Description of StateModel
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */

namespace common\models\auktaModels\enumModels;

use common\models\EnumModel;

class SaveLot extends EnumModel {

    const SAVE_LOT_NOW = 1;
    const SAVE_LOT_DRAFT = 2;
    const SAVE_LOT_FUTURE = 3;

    public static $list = [
        self::SAVE_LOT_NOW    => 'Сейчас',
        self::SAVE_LOT_DRAFT  => 'Сохранить в черновики',
        self::SAVE_LOT_FUTURE => 'Выбрать время начала',
    ];
    public $category = 'categories';

}
