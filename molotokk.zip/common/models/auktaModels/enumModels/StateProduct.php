<?php

namespace common\models\auktaModels\enumModels;

use common\models\EnumModel;

/**
 * Description of StateModel
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class StateProduct extends EnumModel
{
    const STATE_ON_CREATE   = 0;
    const STATE_ON_MODERATE = 1;
    const STATE_ON_AUCTION  = 2;
    const STATE_ON_SALE     = 3;
    const STATE_ON_HIDE     = 5;
    const STATE_ON_SOLD     = 6;
    const STATE_ON_ARHIVE   = 7;

    public static $list = [
        self::STATE_ON_CREATE => 'Создаётся',
        self::STATE_ON_MODERATE => 'На модерации',
        self::STATE_ON_AUCTION => 'Аукцион',
        self::STATE_ON_SALE => 'В продаже',
        self::STATE_ON_HIDE => 'Снят с продажи',
        self::STATE_ON_SOLD => 'Продан',
        self::STATE_ON_ARHIVE => 'В архиве'
    ];
    public $category    = 'categories';

}
