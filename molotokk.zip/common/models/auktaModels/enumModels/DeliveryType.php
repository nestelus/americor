<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\auktaModels\enumModels;

use common\models\EnumModel;

/**
 * Description of DeliveryType
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class DeliveryType extends EnumModel {

    const TYPE_SELF = 3;
    const TYPE_POST = 1;
    const TYPE_COURIER = 2;

    public static $list = [
        self::TYPE_SELF    => 'Self Delivery',
        self::TYPE_POST    => 'By Post',
        self::TYPE_COURIER => 'By Courier',
    ];

}
