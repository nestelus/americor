<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\auktaModels\enumModels;

use common\models\EnumModel;

/**
 * Description of PaymentType
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class PaymentType extends EnumModel {

      const TYPE_FILL_UP    = 0;
      const TYPE_COMMISSION = 1;
      const TYPE_MARKETING  = 2;

      public static $list = [
          self::TYPE_FILL_UP    => 'Пополнение баланса',
          self::TYPE_COMMISSION => 'Комиссия за продажу',
          self::TYPE_MARKETING  => 'Оплата акции',
      ];

}
