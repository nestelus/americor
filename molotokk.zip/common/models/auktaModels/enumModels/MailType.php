<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\auktaModels\enumModels;

use common\models\EnumModel;

/**
 * Description of MailType
 *
 * @author Vladimir
 */
class MailType extends EnumModel
{
    const MAIL_LOT_BUY          = 1;
    const MAIL_LOT_BUY_AUCTION  = 2;
    const MAIL_LOT_SELL         = 3;
    const MAIL_LOT_SELL_AUCTION = 4;
    const MAIL_LOT_CLOSED       = 5;
    const MAIL_LOT_PUBLIC       = 6;
    const MAIL_LOT_REPUBLIC     = 7;
    const MAIL_MESSAGE_FROM_LOT      = 9;
    const MAIL_MESSAGE_TO_LOT        = 10;
    const MAIL_LOT_OWER_BID          = 11;
    const MAIL_LOT_CANCEL_BID        = 12;
    const MAIL_REMEMBE_CLOSE_BUYER   = 13;
    const MAIL_REMEMBE_CLOSE_SELLER  = 14;
    const MAIL_REMEMBE_RATING_BUYER  = 15;
    const MAIL_REMEMBE_RATING_SELLER = 16;
    const MAIL_USER_BLOCKED          = 17;

    public static $list = [
        self::MAIL_LOT_BUY => 'Пользователь купил лот',
        self::MAIL_LOT_BUY_AUCTION => 'Пользователь выиграл аукцион',
        self::MAIL_LOT_SELL => 'Пользователь продал лот',
        self::MAIL_LOT_SELL_AUCTION => 'Пользователь продал лот с аукциона',
        self::MAIL_LOT_CLOSED => 'Лот пользователя завершен',
        self::MAIL_LOT_PUBLIC => 'Пользователь выставил лот',
        self::MAIL_LOT_REPUBLIC => 'Лот пользователя был перевыставлен',
        self::MAIL_MESSAGE_FROM_LOT => 'Пользователь получил сообщение от продавца',
        self::MAIL_MESSAGE_TO_LOT => 'Пользователь получил сообщение от покупателя',
        self::MAIL_LOT_OWER_BID => 'Ставка пользователя перебита',
        self::MAIL_LOT_CANCEL_BID => 'Ставка пользователея отменена',
        self::MAIL_REMEMBE_CLOSE_BUYER => 'Напоминание покупателю о завершении сделки',
        self::MAIL_REMEMBE_CLOSE_SELLER => 'Напоминание продавцу о завершении сделки',
        self::MAIL_REMEMBE_RATING_SELLER => 'Напоминание продавцу оставить отзыв',
        self::MAIL_REMEMBE_RATING_BUYER => 'Напоминание покупателю оставить отзыв',
        self::MAIL_USER_BLOCKED => 'Пользователь заблокирован админом',
    ];

}
