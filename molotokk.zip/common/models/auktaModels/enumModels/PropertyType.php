<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\auktaModels\enumModels;

use common\models\EnumModel;

/**
 * Description of PropertyType
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class PropertyType extends EnumModel
{
    const TYPE_STRING = 0;
    const TYPE_INT    = 1;
    const TYPE_DATE   = 2;
    const TYPE_LIST   = 3;

    public static $list = [
        self::TYPE_STRING => 'string',
        self::TYPE_DATE => 'date',
        self::TYPE_INT => 'integer',
        self::TYPE_LIST => 'list',
    ];
    public $category    = 'categories';

}
