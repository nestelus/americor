<?php

namespace common\models\auktaModels;

use kartik\widgets\DatePicker;
use Yii;
use common\models\auktaModels\CategoryProperties;
use common\models\auktaModels\Products;
use common\models\auktaModels\enumModels\PropertyType;
use yii\helpers\Html;
use common\models\auktaModels\PropertyReferrence;
use yii\helpers\ArrayHelper;

/**
 * This is the model class for table "{{%product_properties}}".

 *
 * @property integer $id
 * @property integer $category_properties_id

 * @property string $data
 * @property integer $property_referrence_id
 *
 * @property PropertyReferrence $propertyReferrence
 * @property CategoryProperties $categoryProperties
 * @property Products $product
 */
class ProductProperties extends \common\models\auktaModels\AuktaModel
{

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%product_properties}}';
    }
    /*  public function beforeSave($insert) {
      if (parent::beforeSave($insert))
      {
      if ($error = $this->productValidate())
      {
      $this->errors[] = $error;
      return FALSE;
      }
      return true;
      }
      return FALSE;
      }
     *
     */

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['category_properties_id', 'product_id'], 'required'],
            [['category_properties_id', 'product_id', 'property_referrence_id'],
                'integer'],
            [['data'], 'string', 'max' => 255],
            [['category_properties_id', 'product_id'], 'unique', 'targetAttribute' => ['category_properties_id',
                    'product_id'], 'message' => 'The combination of Category Properties ID and Product ID has already been taken.'],
            [['property_referrence_id'], 'exist', 'skipOnError' => true, 'targetClass' => PropertyReferrence::className(),
                'targetAttribute' => ['property_referrence_id' => 'id']],
            [['category_properties_id'], 'exist', 'skipOnError' => true, 'targetClass' => CategoryProperties::className(),
                'targetAttribute' => ['category_properties_id' => 'id']],
            [['product_id'], 'exist', 'skipOnError' => true, 'targetClass' => Products::className(),
                'targetAttribute' => ['product_id' => 'id']],
            ['data', 'required', 'when' => function ($model) {
                    return ($model->getCategoryProperties()->one()->is_mandatory
                        && $model->getCategoryProperties()->one()->type_id != PropertyType::TYPE_LIST);
                }],
            ['data', 'integer', 'when' => function ($model) {
                    return $model->getCategoryProperties()->one()->type_id == PropertyType::TYPE_INT;
                }],
            ['data', 'string', 'when' => function ($model) {
                    return $model->getCategoryProperties()->one()->type_id == PropertyType::TYPE_STRING;
                }],
            ['property_referrence_id', 'required', 'when' => function ($model) {
                    return ($model->getCategoryProperties()->one()->is_mandatory
                        && $model->getCategoryProperties()->one()->type_id == PropertyType::TYPE_LIST);
                }],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('products', 'ID'),
            'category_properties_id' => Yii::t('products',
                'Category Properties ID'),
            'product_id' => Yii::t('products', 'Product ID'),
            'data' => Yii::t('products', 'Data'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getPropertyReferrence()
    {
        return $this->hasOne(PropertyReferrence::className(),
                ['id' => 'property_referrence_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCategoryProperties()
    {
        return $this->hasOne(CategoryProperties::className(),
                ['id' => 'category_properties_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProduct()
    {
        return $this->hasOne(Products::className(), ['id' => 'product_id']);
    }

    public function renderField($key)
    {
        $property = $this->categoryProperties;
        $output   = Html::hiddenInput("properties[$key][id]", $this->id)
            .Html::hiddenInput("properties[$key][category_properties_id]",
                $this->category_properties_id)
            .'<label class="control-label for col-md-2">'
            .$property->name.($property->is_mandatory ? '<span style="color:red"> *</span>'
                    : '')
            .'</label>'
            .'<div class="col-md-4" style="padding-bottom:25px">'
            .$this->renderWidget($key)
            .'</div>';

        return $output;
    }

    public function renderWidget($key)
    {
        $property        = $this->categoryProperties;
        $params['class'] = 'form-control';
        $output          = '';
        switch ($property->type_id) {
            case PropertyType::TYPE_INT:
            case PropertyType::TYPE_STRING:

                $output .= Html::textInput("properties[$key][data]",
                        $this->data, $params);
                break;
            case PropertyType::TYPE_DATE:

                $output .= DatePicker::widget([
                        'name' => "properties[$key][data]",
                        'type' => DatePicker::TYPE_COMPONENT_PREPEND,
                        'value' => $this->data,
                        'pluginOptions' => [
                            'autoclose' => true,
                            'format' => 'dd-M-yyyy'
                        ]
                ]);
                break;
            case PropertyType::TYPE_LIST:

                $items = ArrayHelper::map(PropertyReferrence::find()
                            ->where(['reference_type_id' => $property->referrence_type_id])
                            ->orderBy('value')->all(), 'id', 'value');
                $output .= Html::dropDownList("properties[$key][property_referrence_id]",
                        $this->property_referrence_id, $items,
                        [
                        'prompt' => Yii::t('general', '-- Выберите значение --'),
                        'class' => 'form-control',
                ]);
                break;

            default :
                $output .= Html::textInput("properties[$key][data]",
                        $this->data, $params);
        }
        return $output;
    }

    public function productValidate()
    {
        $category_property = $this->categoryProperties;
        $error             = FALSE;
        if ($category_property->is_mandatory) {
            if ($category_property->type_id == PropertyType::TYPE_LIST && empty($this->property_referrence_id) or
                ( $category_property->type_id != PropertyType::TYPE_LIST && empty($this->data))) {
                $error = Yii::t('products',
                        'Поле "{name}" обязательно для заполнения',
                        ['name' => $category_property->name]);
            }
        }
        return $error;
    }

    public static function populateProperties($product, $properties)
    {
        $modelProperties = [];
        // var_dump($properties);
        // die();
        foreach ($properties as $property) {

            if ($property['id']) {
                $modelProperty = ProductProperties::findOne($property['id']);
            } elseif (!$modelProperty = ProductProperties::findOne(['product_id' => $product->id,
                    'category_properties_id' => $properties['category_properties_id']])) {
                $modelProperty = new ProductProperties();
            }
            $modelProperty->setAttributes($property);
            $modelProperties[] = $modelProperty;
        }
        return $modelProperties;
    }

    public function __toString()
    {

        $category_property = $this->categoryProperties;
        switch ($category_property->type_id) {
            case PropertyType::TYPE_LIST:
                return $this->propertyReferrence ? $this->propertyReferrence->value
                        : null;
            default :
                return $this->data;
        }
    }
}
