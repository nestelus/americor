<?php

namespace common\models\auktaModels;

use Yii;
use common\models\auktaModels\Products;
use common\models\User;
use common\models\Profile;
use common\models\auktaModels\enumModels\MailType;

/**
 * This is the model class for table "{{%auction_stakes}}".
 *
 * @property integer $id
 * @property integer $user_id
 * @property integer $product_id
 * @property string $amount
 * @property integer $created_at
 *
 * @property Products $product
 * @property User $user
 */
class AuctionStakes extends AuktaModel
{

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%auction_stakes}}';
    }
    /*  public function scenarios() {
      return array_merge(parent::scenarios(), [
      'stake' => ['amount', 'product_id'],
      ]);
      } */

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['amount', 'product_id'], 'required'],
            [['user_id', 'product_id', 'created_at'], 'integer'],
            [['amount', 'current_price'], 'number'],
            // [['amount', 'product_id'], 'required', 'on' => 'stake'],
            [['amount'], function($attribute, $params) {
                $nextStake = $this->product->getMyNextStake();

                if ($this->$attribute < $nextStake) {
                    $this->addError($attribute,
                        Yii::t('products',
                            'Сумма не может быть менее {nextStake}',
                            [
                            'nextStake' => $nextStake
                    ]));
                    return false;
                }
                return true;
            }],
            [['product_id'], 'exist', 'skipOnError' => true, 'targetClass' => Products::className(),
                'targetAttribute' => ['product_id' => 'id']],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(),
                'targetAttribute' => ['user_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('sales', 'ID'),
            'user_id' => Yii::t('sales', 'Покупатель'),
            'product_id' => Yii::t('sales', 'Товар'),
            'amount' => Yii::t('sales', 'Сумма ставки'),
            'current_price' => Yii::t('sales', 'Текущая цена'),
            'current_leader' => Yii::t('sales', 'Текущая лидер'),
            'created_at' => Yii::t('sales', 'Время ставки'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProduct()
    {
        return $this->hasOne(Products::className(), ['id' => 'product_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProfile()
    {
        return $this->hasOne(Profile::className(), ['user_id' => 'user_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLeader()
    {
        return $this->hasOne(User::className(), ['id' => 'current_leader']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getLeaderProfile()
    {
        return $this->hasOne(Profile::className(),
                ['user_id' => 'current_leader']);
    }

    public function beforeSave($insert)
    {
        if ($insert) {
            $this->created_at     = time();
            $this->current_leader = $this->product->currentStaker ? $this->product->currentStaker->user_id
                    : 0;
        }
        return parent::beforeSave($insert);
    }

    public function afterSave($insert, $changedAttributes)
    {
        if ($insert) {
            if ($this->product->complete_at && $this->created_at > $this->product->complete_at) {
                $this->delete();
                Yii::$app->getSession()->setFlash('error',
                    'Ваша ставка не принята. Аукцион завершен');
                return false;
            } else {
                $new_price = $this->product->getNextPrice();
                $this->product->updateAttributes(['price' => $new_price]);
                $this->updateAttributes(['current_price' => $new_price]);
                $this->updateAttributes(['current_leader' => $this->product->currentStaker->user_id]);
            }
        }
        return parent::afterSave($insert, $changedAttributes);
    }
}
