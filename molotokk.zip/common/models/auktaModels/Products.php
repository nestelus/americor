<?php

namespace common\models\auktaModels;

use Yii;
use yii\behaviors\TimestampBehavior;
use common\models\auktaModels\ProductProperties;
use common\models\auktaModels\enumModels\PropertyType;
use common\models\auktaModels\Categories;
use common\models\auktaModels\ProductPhotos;
use common\models\auktaModels\DeliveryTypes;
use common\models\auktaModels\PaymentTypes;
use common\models\auktaModels\PaymentProduct;
use common\models\auktaModels\DeliveryProduct;
use yii\imagine\Image;
use common\models\auktaModels\AuctionStakes;
use common\models\Profile;
use common\models\auktaModels\UserRatings;
use common\models\auktaModels\ProductsFavorite;
use common\models\auktaModels\enumModels\StateProduct;
use common\models\auktaModels\ProductsTags;
use common\models\auktaModels\Tags;
use common\models\auktaModels\Region;
use dosamigos\taggable\Taggable;
use common\models\User;
use common\models\auktaModels\Sales;
use common\components\Inflector;
use Imagine\Image\Box;
use yii\helpers\Url;
use common\models\MailMessages;
use common\models\auktaModels\enumModels\MailType;

/**
 * Description of Products
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 * This is the model class for table "{{%products}}".
 *
 * @property integer $id
 * @property string $name
 * @property integer $user_id
 * @property string $description
 * @property integer $category_id
 * @property integer $state_id
 * @property string $price
 * @property boolean $is_multilot
 * @property int $quality
 * @property string $lot
 * @property integer $buyer_id
 * @property integer $is_auction
 * @property string $time_start
 * @property string $time_stop
 * @property integer $conditional
 * @property string $price_stop
 * @property integer $complete_at
 * @property integer $created_at
 * @property integer $updated_at
 *
 * @property ProductPhotos[] $productPhotos
 * @property ProductProperties[] $productProperties
 * @property User $buyer
 * @property Categories $category
 * @property DeliveryTypes $deliveryType[]
 * @property PaymentTypes $paymentType[]
 * @property User $user
 * @property AuctionStakes $auctionStakes
 * @property Profile $profile
 */
class Products extends AuktaModel
{
    public $uploadImages;

    /** Стандартные методы * */
    public static function tableName()
    {
        return '{{%products}}';
    }

    public function scenarios()
    {
        $scenarios                 = parent::scenarios();
        $scenarios['Product']      = [
            'name',
            'conditional',
            'user_id', //владелец
            'description', // описание
            'category_id', // категория
            'state_id', // статус
            'price',
        ];
        $scenarios['sales']        = [
            'lot', // № лота (на всякий случай)
            'buyer_id', // покупатель, или тот, кто зарезервировал
            'delivery_type_id', // способ доставки
            'payment_type_id', // способ оплаты
            'is_auction',
        ];
        $scenarios['auction']      = [
            'time_start',
            'time_stop',
            'price_stop',
        ];
        $scenarios['uploadPhotos'] = [
            'uploadImages',
        ];
        return $scenarios;
    }

    public function rules()
    {
        return [
            [['name', 'user_id', 'category_id', 'price',], 'required'],
            [['user_id', 'category_id', 'state_id', 'buyer_id', 'is_auction',
                'is_multilot', 'num_public', 'quality', 'complete_at', 'created_at',
                'updated_at', 'time_stop', 'time_start', 'time_end', 'count_views',
                'is_prepay', 'is_deliverypay'],
                'integer'],
            [['description'], 'string'],
            [['description'], 'filter', 'filter' => function($value) {
                return strip_tags($value);
            }],
            ['conditional', 'in', 'range' => [0, 1, 2]],
            [['conditional', 'num_public'], 'default', 'value' => 0],
            [['price', 'price_stop'], 'number'],
            [['quality'], 'default', 'value' => 1],
            [['quality'], 'required'],
            [['name', 'lot', 'city'], 'string', 'max' => 64],
            [['uploadImages'], 'file', 'skipOnEmpty' => True, 'extensions' => 'jpg, jpeg, png',
                'maxFiles' => 10],
            [['buyer_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(),
                'targetAttribute' => ['buyer_id' => 'id']],
            [['category_id'], 'exist', 'skipOnError' => true, 'targetClass' => Categories::className(),
                'targetAttribute' => ['category_id' => 'id']],
            [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(),
                'targetAttribute' => ['user_id' => 'id']],
            [['tagNames', 'slug'], 'safe'],
            [['region_id'], 'exist', 'skipOnError' => true, 'targetClass' => Region::className(),
                'targetAttribute' => ['region_id' => 'id']],
            ['is_auction', 'default', 'value' => 1],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('products', 'ID'),
            'name' => Yii::t('products', 'Название лота'),
            'user_id' => Yii::t('products', 'Продавец'),
            'description' => Yii::t('products', 'Описание лота'),
            'category_id' => Yii::t('products', 'Категория'),
            'state_id' => Yii::t('products', 'Статус'),
            'price' => Yii::t('products', 'Цена'),
            'lot' => Yii::t('products', 'Лот'),
            'buyer_id' => Yii::t('products', 'Покупатель'),
            'region_id' => Yii::t('products', 'Регион'),
            'city' => Yii::t('products', 'Город'),
            'num_public' => Yii::t('products', 'Сколько раз'),
            'is_auction' => Yii::t('products', 'Тип торгов'),
            'is_multilot' => Yii::t('products',
                'Я хочу выставить несколько одинаковых лотов'),
            'quality' => Yii::t('products', 'Общее количество'),
            'time_start' => Yii::t('products', 'Время начала торгов'),
            'time_stop' => Yii::t('products', 'Длительность'),
            'time_end' => Yii::t('products', 'Время окончания торгов'),
            'price_stop' => Yii::t('products', 'Цена "Купить сейчас"'),
            'conditional' => Yii::t('products', 'Состояние'),
            'complete_at' => Yii::t('products', 'Завершен'),
            'created_at' => Yii::t('general', 'Создан'),
            'updated_at' => Yii::t('general', 'Обновлен'),
            'deliveryTypes' => Yii::t('products', 'Способы доставки'),
            'deliveryProduct' => Yii::t('products', 'Способы доставки'),
            'paymentTypes' => Yii::t('products', 'Способы оплаты'),
            'paymentProduct' => Yii::t('products', 'Способы оплаты'),
            'productProperties' => Yii::t('products', 'Характеристики товара'),
            'tagNames' => Yii::t('products', 'Теги для лота'),
            'uploadImages' => Yii::t('products', 'Загрузка фото'),
            'count_views' => Yii::t('products', 'Просмотров'),
            'is_deliverypay' => Yii::t('products', 'Доставку оплачивает'),
            'is_prepay' => Yii::t('products', 'Предоплата'),
        ];
    }

    public function behaviors()
    {
        return [
            [
                'class' => TimestampBehavior::className(),
            ],
            [
                'class' => Taggable::className(),
                'asArray' => true,
            ],
        ];
    }

    public function beforeDelete()
    {
        if (parent::beforeDelete()) {
            foreach ($this->productPhotos as $photo) {
                $photo->delete();
            }
            $this->time_end = $this->time_start + $this->time_stop;
            return true;
        }
        return false;
    }

    public function beforeSave($insert)
    {
        if (parent::beforeSave($insert)) {
            if (is_null($this->is_auction)) {
                $this->is_auction = 1;
            }

            return true;
        }
        return false;
    }

    public function afterSave($insert, $changedAttributes)
    {
        parent::afterSave($insert, $changedAttributes);

        if (isset($changedAttributes['category_id'])) {
            $this->refreshProperties();
        }
    }

    public function refreshProperties()
    {
        foreach ($this->productProperties as $old_property) {
            $old_property->delete();
        }
        $category = $this->category;
        if ($category) {
            $category_properties = $category->categoryProperties;

            foreach ($category_properties as $category_property) {
                $productProperty                         = new ProductProperties();
                $productProperty->product_id             = $this->id;
                $productProperty->category_properties_id = $category_property->id;
                $productProperty->save(false);
            }
        }
    }
    /** Валидация при выставлении */

    /**
     *
     * @param type $properties
     * @return boolean
     */
    public function updateProperties($properties)
    {
        $error = FALSE;
        foreach ($properties as $property) {

            if ($property['id']) {
                $modelProperty = ProductProperties::findOne($property['id']);

                $modelProperty->setAttributes($property);
                $modelProperty->product_id = $this->id;
                if (!$modelProperty->save()) {
                    $error = TRUE;
                }
            }
        }

        return $error;
    }

    public function validateProperties()
    {
        $properties = $this->productProperties;

        $no_errors = TRUE;
        foreach ($properties as $property) {
            if ($error = $property->productValidate()) {
                $this->addError('productProperties', $error);

                $no_errors = FALSE;
            }
        }

        return $no_errors;
    }

    public function updateDeliveryProduct($deliveries)
    {
        $old_deliveries = $this->getDeliveryProduct()->all();
        if (!empty($old_deliveries)) {
            foreach ($old_deliveries as $old_delivery) {
                $old_delivery->delete();
            }
        }

        if (!empty($deliveries)) {
            foreach ($deliveries as $dlivery_id) {
                $delivery                   = new DeliveryProduct();
                $delivery->product_id       = $this->id;
                $delivery->delivery_type_id = $dlivery_id;
                $delivery->save();
            }
        }
    }

    public function updatePaymentMethods($payments)
    {
        $old_payments = $this->getPaymentProduct()->all();

        foreach ($old_payments as $old_payment) {
            $old_payment->delete();
        }
        if (!empty($payments)) {
            foreach ($payments as $payment_id) {
                $payment                = new PaymentProduct();
                $payment->product_id    = $this->id;
                $payment->pay_method_id = $payment_id;
                $payment->save();
            }
        }
    }

    public function auctionValidate()
    {
        if ($this->is_auction) {
            if (!$this->time_stop) {
                $this->addError('time_stop',
                    Yii::t('products', 'Укажите длительность аукциона'));
            }
        }
        return TRUE;
    }

    public function uploadPhoto()
    {
        $this->scenario = 'uploadPhotos';
        if ($this->validate()) {
            foreach ($this->uploadImages as $image) {
                $img    = Image::getImagine()->open(Yii::getAlias($image->tempName));
                $size   = $img->getSize();
                $width  = $size->getWidth();
                $height = $size->getHeight();
                if ($width > 1200) {
                    $ratio  = $width / $height;
                    $width  = 1200;
                    $height = round($width / $ratio);
                    $box    = new Box($width, $height);
                    $img->resize($box);
                }
                if ($height > 900) {
                    $ratio  = $width / $height;
                    $height = 900;
                    $width  = round($height * $ratio);
                    $box    = new Box($width, $height);
                    $img->resize($box);
                }

                $ext        = end((explode(".", $image->name)));
                $modelPhoto = new ProductPhotos();

                $modelPhoto->file_name  = Yii::$app->security->generateRandomString(10).".{$ext}";
                $modelPhoto->product_id = $this->id;

                $modelPhoto->created_at = time();

                $path = $modelPhoto->getPathPhoto();

                //mkdir(dirname($path), 0777, TRUE) or die(dirname($path));
                is_dir(dirname($path)) or mkdir(dirname($path), 0777, TRUE);

                if ($img->save($path)) {
                    $modelPhoto->save();
                    $modelPhoto->nextOrder();
                } else {
                    return false;
                }
            }
            return true;
        } else {
            return false;
        }
    }

    public function moderateProduct()
    {
        //валидация цены (можно убрать)
        if (empty($this->price)) {
            $this->addError('price', Yii::t('products', 'Укажите цену'));
            return false;
        }
        // валидация фото
        if (count($this->productPhotos) == 0) {
            $this->addError('productPhotos',
                Yii::t('products',
                    'Для выставления на продажу лот должен содержать хотя бы одно фото'));
            return false;
        }
        // валидация свойств
        if (!$this->validateProperties()) {
            return false;
        }
        // валидация аукциона
        if ($this->is_auction) {
            if (!$this->auctionValidate()) {
                return false;
            }
        }
        return $this->save();
    }

    public function publicProduct()
    {
        if ($this->state_id == StateProduct::STATE_ON_CREATE) {
            $this->state_id    = $this->is_auction ? StateProduct::STATE_ON_AUCTION
                    : StateProduct::STATE_ON_SALE;
            $this->time_start  = time();
            $this->time_end    = $this->time_start + $this->time_stop;
            $this->price_start = $this->price;
            $this->slug        = $this->getSlug();
            if ($this->save()) {
                $mail_public = new MailMessages([
                    'type' => MailType::MAIL_LOT_PUBLIC,
                    'model' => $this,
                ]);
                $mail_public->send();
                return true;
            }
            return false;
        }
    }

    public function cloneProduct()
    {
        $clone              = new Products();
        $clone->name        = $this->name;
        $clone->description = $this->description;
        $clone->user_id     = $this->user_id;
        $clone->category_id = $this->category_id;
        $clone->price       = $this->price;
        $clone->conditional = $this->conditional;
        $clone->lot         = $this->lot;
        $clone->is_auction  = $this->is_auction;
        $clone->time_stop   = $this->time_stop;
        $clone->price_stop  = $this->price_stop;
        $clone->is_multilot = $this->is_multilot;
        $clone->region_id   = $this->region_id;
        $clone->city        = $this->city;
        $clone->num_public  = $this->num_public;
        $clone->tagNames    = $this->tagNames;

        $clone->state_id = StateProduct::STATE_ON_CREATE;

        if ($clone->save(FALSE)) {
            foreach ($this->productProperties as $property) {
                $clone_property = new ProductProperties([
                    'category_properties_id' => $property->category_properties_id,
                    'product_id' => $clone->id,
                    'data' => $property->data,
                    'property_referrence_id' => $property->property_referrence_id,
                ]);
                $clone_property->save();
            }
            foreach ($this->productPhotos as $photo) {
                $new_photo             = new ProductPhotos();
                $new_photo->product_id = $clone->id;
                $new_photo->file_name  = $photo->file_name;
                $new_photo->order      = $photo->order;
                $new_photo->save();
                $path                  = $new_photo->getPathPhoto();
                is_dir(dirname($path)) or mkdir(dirname($path), 0777, TRUE);
                copy($photo->getPathPhoto(), $path);
            }
            foreach ($this->deliveryProduct as $delivery) {
                $new_dtp = new DeliveryProduct([
                    'product_id' => $clone->id,
                    'delivery_type_id' => $delivery->delivery_type_id,
                ]);
                $new_dtp->save();
            }
            foreach ($this->paymentProduct as $payment) {
                $new_pay = new PaymentProduct([
                    'product_id' => $clone->id,
                    'pay_method_id' => $payment->pay_method_id,
                ]);
                $new_pay->save();
            }
            return $clone;
        } else {
            return false;
        }
    }

    public function onBuy($buyer_id)
    {
        if ($this->state_id == StateProduct::STATE_ON_SALE || $this->state_id == StateProduct::STATE_ON_AUCTION) {
            if ($this->state_id == StateProduct::STATE_ON_AUCTION) {
                $this->price = $this->price_stop;
            }
            $this->time_stop = null;
            $this->time_end  = time();
            $this->state_id  = StateProduct::STATE_ON_SOLD;
            $this->buyer_id  = $buyer_id;

            $this->complete_at = time();

            if ($this->save(FALSE)) {
                return $this->id;
            }
            return FALSE;
        }
        return FALSE;
    }

    public static function closeAuctions()
    {

        $auctions = self::find()
            ->where(['state_id' => [
                    StateProduct::STATE_ON_AUCTION,
                    StateProduct::STATE_ON_SALE,
            ]])
            ->andWhere(['<=', 'time_end', time()]);

        foreach ($auctions->each() as $auction) {
            $auction->endAuction();
            echo $auction->id;
        }
    }

    public function endAuction($forse = false)
    {
        if (!$forse &&
            !(in_array($this->state_id,
                [StateProduct::STATE_ON_AUCTION, StateProduct::STATE_ON_SALE]) && ($this->time_end
            <= time()))) {
            return;
        }
        if (StateProduct::STATE_ON_AUCTION) {
            $buyer = $this->getCurrentStaker();
            if ($buyer) {
                $buyer_profile      = $buyer->profile;
                $sales              = new Sales([
                    'product_id' => $this->id,
                    'amount' => $this->price,
                    'quality' => $this->quality,
                    'seller_id' => $this->user_id,
                    'buyer_id' => $buyer->user_id,
                ]);
                $delivery_addresses = $buyer_profile->getDeliveryAdresses()->one();
                if ($delivery_addresses) {
                    $sales->region_id = $delivery_addresses->region_id;
                    $sales->phone     = $delivery_addresses->phone;
                    $sales->city      = $delivery_addresses->city;
                    $sales->zip       = $delivery_addresses->zip;
                    $sales->address   = $delivery_addresses->address;
                    $sales->fio       = $delivery_addresses->fio;
                } else {
                    $sales->region_id = $buyer_profile->region_id;
                    $sales->phone     = $buyer_profile->phone;
                    $sales->city      = $buyer_profile->city;
                    $sales->zip       = $buyer_profile->zip;
                    $sales->address   = $buyer_profile->address;
                    $sales->fio       = $buyer_profile->first_name.' '.$buyer_profile->last_name;
                }
                $sales->save();
                $this->updateAttributes([
                    'buyer_id' => $buyer->user_id,
                    'state_id' => StateProduct::STATE_ON_SOLD,
                    'complete_at' => $this->time_end,
                    'time_stop' => null,
                ]);

                $mail_sell = new MailMessages([
                    'type' => MailType::MAIL_LOT_SELL_AUCTION,
                    'model' => $this,
                ]);
                $mail_sell->send();
                $mail_buy  = new MailMessages([
                    'type' => MailType::MAIL_LOT_BUY_AUCTION,
                    'model' => $this,
                ]);
                $mail_buy->send();

                return true;
            }
        }
        // Перевыставление
        if ($this->num_public && !$forse) {
            $this->updateAttributes([
                'num_public' => $this->num_public - 1,
                'time_end' => $this->time_end + $this->time_stop,
                'time_start' => $this->time_end,
            ]);
            $mail_republic = new MailMessages([
                'type' => MailType::MAIL_LOT_REPUBLIC,
                'model' => $this,
            ]);
            $mail_republic->send();

            return true;
        }
        //Закрытие
        $this->updateAttributes([
            'complete_at' => $this->time_end,
            'state_id' => StateProduct::STATE_ON_HIDE,
        ]);
        $mail_closed = new MailMessages([
            'type' => MailType::MAIL_LOT_CLOSED,
            'model' => $this,
        ]);
        $mail_closed->send();
        return true;
    }

    public function getMyNextStake()
    {
        if (Yii::$app->user->isGuest || !$this->isStaker(Yii::$app->user->id)) {
            return $this->getNextStake();
        } else {
            $myStake = $this->getMyStakes()->one();

            return max([$this->getNextStake($myStake->amount), $this->getNextStake()]);
        }
    }
    /*
     * Максимальная ставка на данный товар
     */

    public function getMaxStake()
    {
        return $this->getAuctionStakes()->orderBy(['amount' => SORT_DESC, 'created_at' => SORT_ASC])->one();
    }
    /*
     * Возвращает цену, которая должна быть у товара
     */

    public function getNextPrice()
    {
        /* @var $stakes yii\db\Query */
        // получаем двух лидеров, и их ставки
        $stakes = $this->getAuctionStakes()
            ->select(['product_id', 'amount' => 'MAX(amount)'])
            ->groupBy('user_id')
            ->orderBy(['amount' => SORT_DESC])
            ->limit(2)//;
            ->all();

        switch (count($stakes)) {
            case 2:
                //если есть два лидера, $next_price = ставке второго
                $next_price = $stakes[1]->amount;
                break;
            case 1:
            case 0:
                // если всего один участник, то цена не изменяется
                return $this->price;

            default :
                $next_price = $this->price;
        }
        /*
         *
         * $this->getNextStake($next_price) - получаем следующий шаг от максимума второгго
         * min() эта цена не должна быть больше максимальной ставки
         */
        return min([
            $this->getNextStake($next_price),
            $this->getMaxStake()->amount
        ]);
    }

    public function getNextStake($price = null)
    {
        $price = is_null($price) ? $this->price : $price;
        if (count($this->auctionStakes) == 0) {
            return $price;
        }
        if ($price < 1000) {
            if ($price < 100) {
                return $price + 1;
            } elseif ($price >= 100 && $price < 200) {
                return $price + 2;
            } elseif ($price >= 200 && $price < 500) {
                return $price + 5;
            } elseif ($price >= 500 && $price < 1000) {
                return $price + 10;
            }
        } elseif (substr($price, 0, 1) == '1' || substr($price, 0, 1) == '2') {
            return $price + 2 * (10 ** (strlen((int) $price) - 3));
        } elseif (substr($price, 0, 1) == '3' || substr($price, 0, 1) == '4' || substr($price,
                0, 1) == '5') {
            return $price + 5 * (10 ** (strlen((int) $price) - 3));
        } else {
            return $price + (10 ** (strlen((int) $price) - 2));
        }
    }

    protected function _itemAction($key)
    {
        $action  = [];
        $user_id = Yii::$app->user->getId();
        switch ($key) {
            // избранное
            case 'favorite' :
                if ($this->getFavorite()->where(['user_id' => $user_id])->one()) {
                    $label = 'Удалить из избранного';
                } else {
                    $label = 'Добавить в избранное';
                }
                $action = [
                    'label' => $label,
                    'url' => '#',
                    'linkOptions' => [
                        'class' => 'js_action-favorit',
                        'product_id' => $this->id,
                    ],
                ];
                break;
//Посмотреть другие товары продавца
            case 'other':
                $action = [
                    'label' => (Yii::t('nc_users',
                        'Посмотреть другие товары продавца')),
                    'url' => '/profile/products-list/'.$this->user_id.'/',
                ];
                break;
// Сообщение продавцу
            case 'message_seller':
                if (Yii::$app->user->isGuest) {
                    $action = [
                        'label' => (Yii::t('nc_users',
                            'Отправить сообщение продавцу')),
                        'url' => Url::to(['messages/messages', 'visavi_id' => $this->user_id,
                            'lot_id' => $this->id]),
                    ];
                } else {
                    $action = [
                        'label' => (Yii::t('nc_users',
                            'Отправить сообщение продавцу')),
                        'url' => '#',
                        'linkOptions' => [
                            'data-toggle' => 'modal',
                            'data-target' => '#send_'.$this->id,
                        ],
                    ];
                }
                break;
// Редактировать
            case 'edit':
                $action = [
                    'label' => (Yii::t('nc_users', 'Редактировать')),
                    'url' => '/admin-product/update/'.$this->id.'/',
                    'linkOptions' => [
                        'class' => 'pjax-user_menu'
                    ]
                ];
                break;

//Удалить
            case 'delete':
                $action = [
                    'label' => (Yii::t('nc_users', 'Удалить')),
                    'url' => [
                        '/admin-product/delete/',
                        'id' => $this->id,
                    ],
                    'linkOptions' => [
                        'data-method' => 'post'
                    ],
                ];
                break;
//Выставить похожий
            case 'double':
                $action = [
                    'label' => (Yii::t('nc_users', 'Выставить похожий')),
                    'url' => '/admin-product/clone/'.$this->id.'/',
                ];
                break;
//Перервыставить
            case 'recreate':
                $action = [
                    'label' => (Yii::t('nc_users', 'Выставить заново')),
                    'url' => '/admin-product/clone/'.$this->id.'/',
                ];
                break;
//Снять с продажи
            case 'hide':
                $action = [
                    'label' => (Yii::t('nc_users', 'Снять с продажи')),
                    'url' => '/admin-product/outsale/'.$this->id.'/',
                    'linkOptions' => [
                        'onClick' => "ga('send', 'event', 'Завершение', 'Снят с торгов')",
                    ]
                ];
                break;
//Завершить досрочно
            case 'ending':
                $action = [
                    'label' => (Yii::t('nc_users', 'Завершить досрочно')),
                    'url' => '/products/end-forse/'.$this->id.'/',
                ];
                break;

//Контактные данные контрагента
            case 'contact':
                if ($this->user_id == $user_id):
                    $action = [
                        'label' => (Yii::t('nc_users',
                            'Контактные данные покупателя')),
                        'url' => '#',
                        'linkOptions' => [
                            'data-toggle' => 'modal',
                            'data-target' => '#contact-data_'.$this->buyer_id,
                        ],
                    ];
                endif;
                if ($this->buyer_id == $user_id):
                    $action = [
                        'label' => (Yii::t('nc_users',
                            'Контактные данные продавца')),
                        'url' => '#',
                        'linkOptions' => [
                            'data-toggle' => 'modal',
                            'data-target' => '#contact-data_'.$this->user_id,
                        ],
                    ];
                endif;
                break;
// отзыв
            case 'rating':
                if ($this->user_id == $user_id):
                    if (count($this->salerRating) == 0):

                        $action = [
                            'label' => (Yii::t('nc_users',
                                'Оставить отзыв о покупателе')),
                            'url' => '/profile/add-ratings-buyer/'.$this->id.'/',
                            'linkOptions' => [
                                'data-pjax' => 0,
                            ],
                        ];
                    endif;


                endif;
                if ($this->buyer_id == $user_id):

                    if (count($this->buyerRating) == 0):
                        $action = [
                            'label' => (Yii::t('nc_users',
                                'Оставить отзыв о продавце')),
                            'url' => '/profile/add-ratings-seller/'.$this->id.'/',
                            'linkOptions' => [
                                'data-pjax' => 0,
                            ],
                        ];
                    endif;

                endif;
                break;
//Напомнить об оплате
            case 'remembe_pay':
                $action = [
                    'label' => 'Напомнить об оплате',
                    'url' => '/products/remembe-pay/'.$this->id.'/',
                ];
                break;
        }
        return $action;
    }

    public function getItemsAction()
    {
        //$items_action = [];
        $user_id = Yii::$app->user->getId();
// Я продавец
        if ($this->user_id == $user_id) {
            //Черновики
            if ($this->state_id == StateProduct::STATE_ON_CREATE) {
                $items_action[] = $this->_itemAction('edit');
                $items_action[] = $this->_itemAction('delete');
                $items_action[] = $this->_itemAction('double');
                return $items_action;
            }
            //В продаже "Купить сейчас"
            if ($this->state_id == StateProduct::STATE_ON_SALE) {
                $items_action[] = $this->_itemAction('edit');
                $items_action[] = $this->_itemAction('double');
                $items_action[] = $this->_itemAction('hide');
                return $items_action;
            }
            //  В продаже Аукцион (Я продавец):  з, и, к, л
            if ($this->state_id == StateProduct::STATE_ON_AUCTION) {
                if (count($this->auctionStakes) == 0) {
                    $items_action[] = $this->_itemAction('edit');
                    $items_action[] = $this->_itemAction('hide');
                }
                $items_action[] = $this->_itemAction('ending');
                $items_action[] = $this->_itemAction('double');

                return $items_action;
            }
            if ($this->state_id == StateProduct::STATE_ON_SOLD) {
                $items_action[] = $this->_itemAction('contact');
                $items_action[] = $this->_itemAction('remembe_pay');
                if (count($this->salerRating) == 0) {
                    $items_action[] = $this->_itemAction('rating');
                }
                $items_action[] = $this->_itemAction('double');

                return $items_action;
            }
            if ($this->state_id == StateProduct::STATE_ON_HIDE) {
                $items_action[] = $this->_itemAction('double');
                $items_action[] = $this->_itemAction('recreate');
                return $items_action;
            }
        } else {
// Я покупатель
            //  В продаже
            if ($this->state_id == StateProduct::STATE_ON_SALE) {
                $items_action[] = $this->_itemAction('favorite');
                $items_action[] = $this->_itemAction('other');
                $items_action[] = $this->_itemAction('message_seller');
                return $items_action;
            }
            // Аукцион
            if ($this->state_id == StateProduct::STATE_ON_AUCTION) {
                $items_action[] = $this->_itemAction('favorite');
                $items_action[] = $this->_itemAction('other');
                $items_action[] = $this->_itemAction('message_seller');

                return $items_action;
            }
            // Продан
            if ($this->state_id == StateProduct::STATE_ON_SOLD) {
                $items_action[] = $this->_itemAction('favorite');
                $items_action[] = $this->_itemAction('other');
                $items_action[] = $this->_itemAction('message_seller');
                if ($this->buyer_id == $user_id) {
                    if (count($this->buyerRating) == 0) {
                        $items_action[] = $this->_itemAction('rating');
                    }
                    $items_action[] = $this->_itemAction('contact');
                }
                return $items_action;
            }
        }
        //  return $this->_itemAction('edit');
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProductPhotos()
    {
        return $this->hasMany(ProductPhotos::className(), ['product_id' => 'id'])->orderBy(['order' => SORT_DESC]);
    }

    public function getMainPhoto()
    {
        if (!empty($this->getProductPhotos()->all())) {
            $mainPhoto = $this->getProductPhotos()->andWhere(['order' => 1])->one();
            if ($mainPhoto) {
                return $mainPhoto;
            }
            /**  @var  $photo common\models\auktaModels\ProductPhotos */
            $photo = $this->getProductPhotos()->one();
            $photo->updateAttributes(['order' => 1]);
            return $photo;
        }
        $nophoto = new ProductPhotos([
            'file_name' => 'nophoto.png',
        ]);
        return $nophoto;
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProductProperties()
    {
        return $this->hasMany(ProductProperties::className(),
                ['product_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBuyer()
    {
        return $this->hasOne(User::className(), ['id' => 'buyer_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getCategory()
    {
        return $this->hasOne(Categories::className(), ['id' => 'category_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDeliveryProduct()
    {
        return $this->hasMany(DeliveryProduct::className(),
                ['product_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getDeliveryTypes()
    {
        return $this->hasMany(DeliveryTypes::className(),
                    ['id' => 'delivery_type_id'])
                ->via('deliveryProduct');
    }

    public function getPaymentProduct()
    {
        return $this->hasMany(PaymentProduct::className(),
                ['product_id' => 'id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getUser()
    {
        return $this->hasOne(User::className(), ['id' => 'user_id']);
    }
    /*
     * Все ставки аукциона
     */

    public function getAuctionStakes()
    {
        return $this->hasMany(AuctionStakes::className(), ['product_id' => 'id']);
    }

    public function getMyStakes()
    {
        return $this->getAuctionStakes()
                ->where(['user_id' => Yii::$app->user->id])
                ->orderBy(['created_at' => SORT_DESC]);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProfile()
    {
        return $this->hasOne(Profile::className(), ['user_id' => 'user_id']);
    }

    public function getSalerRating()
    {
        return $this->hasMany(UserRatings::className(), ['product_id' => 'id'])->where(['author_id' => $this->user_id]);
    }

    public function getBuyerRating()
    {
        return $this->hasMany(UserRatings::className(), ['product_id' => 'id'])->where(['author_id' => $this->buyer_id]);
    }
    /*
     * текущий лидер аукциона
     */

    public function getCurrentStaker()
    {
        return $this->hasMany(AuctionStakes::className(), ['product_id' => 'id'])->orderBy(['amount' => SORT_DESC,
                'created_at' => SORT_ASC])->one();
    }

    public function isStaker($user_id)
    {
        return count($this->getAuctionStakes()->where(['user_id' => $user_id])->all())
            > 0;
    }

    public function getFavorite()
    {
        return $this->hasMany(ProductsFavorite::className(),
                ['product_id' => 'id']);
    }

    public function isMyFavorite()
    {
        return count($this->getFavorite()->where(['user_id' => Yii::$app->user->id])->one())
            > 0;
    }

    public function getProductTags()
    {
        return $this->hasMany(ProductsTags::className(), ['product_id' => 'id']);
    }

    public function getTags()
    {
        return $this->hasMany(Tags::className(), ['id' => 'tags_id'])
                ->viaTable('{{%products_tags}}', ['product_id' => 'id']);
    }

    public function getMessages()
    {
        return $this->hasMany(Messages::className(), ['product_id' => 'id']);
    }

    public function getWhomMessages()
    {
        return $this->hasMany(User::className(), ['id' => 'whom_id'])->via('messages');
    }

    public function getFromMessages()
    {
        return $this->hasMany(User::className(), ['id' => 'from_id'])->via('messages');
    }

    public function getSales()
    {
        return $this->hasMany(Sales::className(), ['product_id' => 'id']);
    }

    public function getRegion()
    {
        return $this->hasOne(Region::className(), ['id' => 'region_id']);
    }

    public function getUrl($abs = false)
    {
        if (!empty($this->slug)) {
            if ($abs) {
                return Yii::$app->params['homeURL'].'products/'.$this->slug.'_'.$this->id;
            } else {
                return '/products/'.$this->slug.'_'.$this->id;
            }
        } else {
            if ($abs) {
                return Yii::$app->params['homeURL'].'products/view/'.$this->id.'/';
            }
        }

        return Url::to(['products/view', 'id' => $this->id], $abs);
    }

    public function getSlug()
    {
        $slug = Inflector::slug($this->name);
//        $properties = $this->productProperties;
//        foreach ($properties as $property) {
//            if ($property->categoryProperties->type_id == PropertyType::TYPE_LIST) {
//                if (!empty($property->property_referrence_id)) {
//                    $slug[] = Inflector::slug($property->propertyReferrence->value);
//                }
//            } else {
//                if (!empty($property->data)) {
//                    $slug[] = Inflector::slug($property->data);
//                }
//            }
//        }
//        $url = str_replace('_', '-', implode('-', $slug));

        return $slug;
    }
}
