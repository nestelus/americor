<?php

namespace common\models\auktaModels;

use Yii;
use common\models\User;
use common\models\auktaModels\Region;
use common\models\auktaModels\DeliveryAddresses;
use yii\behaviors\TimestampBehavior;
use common\models\auktaModels\Products;
use common\models\MailMessages;
use common\models\auktaModels\enumModels\MailType;

/**
 * This is the model class for table "{{%sales}}".
 *
 * @property integer $id
 * @property integer $product_id
 * @property string $amount
 * @property integer $quality
 * @property integer $seller_id
 * @property integer $buyer_id
 * @property string $first_name
 * @property string $last_name
 * @property string $phone
 * @property integer $region_id
 * @property string $city
 * @property string $zip
 * @property string $address
 * @property integer $created_at
 * @property integer $updated_at
 *
 * @property Region $region
 * @property User $buyer
 * @property User $seller
 */
class Sales extends \common\models\auktaModels\AuktaModel
{

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%sales}}';
    }

    public function behaviors()
    {
        return [
            [
                'class' => TimestampBehavior::className(),
            ],
        ];
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['product_id', 'amount', 'seller_id', 'buyer_id'], 'required'],
            [['product_id', 'quality', 'seller_id', 'buyer_id', 'region_id', 'created_at',
                'updated_at'], 'integer'],
            [['amount'], 'number'],
            [['address', 'description'], 'string'],
            ['quality', 'validateQuality'],
            ['quality', 'required'],
            [['fio', 'phone', 'city', 'zip'], 'string', 'max' => 255],
            [['region_id'], 'exist', 'skipOnError' => true, 'targetClass' => Region::className(),
                'targetAttribute' => ['region_id' => 'id']],
            [['buyer_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(),
                'targetAttribute' => ['buyer_id' => 'id']],
            [['seller_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(),
                'targetAttribute' => ['seller_id' => 'id']],
            [['product_id'], 'exist', 'skipOnError' => true, 'targetClass' => Products::className(),
                'targetAttribute' => ['product_id' => 'id']],
        ];
    }

    public function validateQuality($attribute, $params)
    {

        $quality = Products::findOne($this->product_id)->quality;
        if ($quality < $this->$attribute) {
            $this->addError($attribute,
                'Количество должно быть меньше '.$quality);
        }
        if (!($this->$attribute)) {
            $this->addError($attribute, 'Укажите количество');
        }
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('sales', 'ID'),
            'product_id' => Yii::t('sales', 'Лот'),
            'amount' => Yii::t('sales', 'Сумма'),
            'quality' => Yii::t('sales', 'Количество'),
            'seller_id' => Yii::t('sales', 'Продавец'),
            'seller' => Yii::t('sales', 'Продавец'),
            'buyer_id' => Yii::t('sales', 'Покупатель'),
            'buyer' => Yii::t('sales', 'Покупатель'),
            'fio' => 'Контактное лицо',
            'phone' => Yii::t('sales', 'Телефон для связи'),
            'region_id' => Yii::t('sales', 'Регион'),
            'region' => Yii::t('sales', 'Регион'),
            'city' => Yii::t('sales', 'Город'),
            'zip' => Yii::t('sales', 'Почтовый индекс'),
            'address' => Yii::t('sales', 'Адрес'),
            'description' => 'Комментарии для продавца',
            'created_at' => Yii::t('sales', 'Создано'),
            'updated_at' => Yii::t('sales', 'Updated At'),
        ];
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getRegion()
    {
        return $this->hasOne(Region::className(), ['id' => 'region_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getBuyer()
    {
        return $this->hasOne(User::className(), ['id' => 'buyer_id']);
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getSeller()
    {
        return $this->hasOne(User::className(), ['id' => 'seller_id']);
    }

    public function getProduct()
    {
        return $this->hasOne(Products::className(), ['id' => 'product_id']);
    }

    public function addAddress($name)
    {
        $address            = new DeliveryAddresses();
        $address->user_id   = $this->buyer_id;
        $address->phone     = $this->phone;
        $address->region_id = $this->region_id;
        $address->city      = $this->city;
        $address->address   = $this->address;
        $address->zip       = $this->zip;
        $address->name      = $name;

        $address->save();
    }

    public function onBuy()
    {
        /* @var $product Products */
        $product = $this->product;

        if ($product->is_multilot && $product->quality > $this->quality) {
            $product->updateAttributes(['quality' => $product->quality - $this->quality]);
            $id = $this->product_id;
        } else {
            $id = $product->onBuy($this->buyer_id);
        }
        if ($id) {
            $mail_sell = new MailMessages([
                'type' => MailType::MAIL_LOT_SELL,
                'model' => $this,
            ]);
            $mail_sell->send();
            $mail_buy  = new MailMessages([
                'type' => MailType::MAIL_LOT_BUY,
                'model' => $this,
            ]);
            $mail_buy->send();
        }
        return $id;
    }
}
