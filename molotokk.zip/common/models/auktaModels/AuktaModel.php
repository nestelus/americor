<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\models\auktaModels;

use yii\data\ActiveDataProvider;
use yii\db\ActiveQuery;
use yii\db\ActiveRecord;
use yii\helpers\Inflector;
use Yii;
use yii\db\Schema;
use common\components\DateTime;

/**
 * Description of AuctaModel
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
abstract class AuktaModel extends ActiveRecord
{
    /** Сценарий для фильтрации моделей */
    const SCENARIO_SEARCH = 'search';

    /**
     * @var array массив настроек полей модели, для внутреннего использования
     */
    protected $_fieldsOptions = [];

    /**
     * @var array массив атрибутов со связями
     */
    protected $_attributesWithRelations = [];
    protected $_is_sefl                 = false;

    /**
     * @inheritdoc
     */
    public function transactions()
    {
        $scenarios = $this->scenarios();
        foreach ($scenarios as $scenario => $value) {
            $scenarios[$scenario] = self::OP_ALL;
        }
        return $scenarios;
    }

    /**
     * Магическая функция для получения свойства объекта
     *
     * @param string $name наименование свойства
     *
     * @return mixed
     */
    public function __get($name)
    {

        $columns = $this->getDb()->getTableSchema($this->tableName())->columns;
        if (isset($columns[$name])) {
            $column = $columns[$name];
            if ($column->type == Schema::TYPE_DATETIME || $column->type == Schema::TYPE_DATE) {
                $value = parent::__get($name);
                if (is_null($value)) {
                    return null;
                } elseif (strtotime($value) !== false) {
                    return new DateTime($value,
                        $column->type == Schema::TYPE_DATETIME);
                }
            }
        }
        return parent::__get($name);
    }

    /**
     * @inheritdoc
     */
    public function __set($name, $value)
    {
        $columns = $this->getDb()->getTableSchema($this->tableName())->columns;
        if (isset($columns[$name])) {
            $column = $columns[$name];
            /* if (($column->type == Schema::TYPE_DATETIME || $column->type == Schema::TYPE_DATE) && !($value instanceof DateTime) && $value)
              {
              $value = new DateTime($value, $column->type == Schema::TYPE_DATETIME);
              } */
        }
        parent::__set($name, $value);
    }

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return Inflector::camel2id(self::className(), '_');
    }
    /**
     * @inheritdoc
     */

    /**
     * Возврщает провайдер для поиска моделей
     * @param array $params параметры для поиска
     * @param ActiveQuery $query экземпляр запроса к бд
     * @return ActiveDataProvider
     */
    public function search($params, $query = null)
    {
        /** @var ActiveQuery $query */
        if (!$query) {
            $query = static::find();
        }
        $dataProvider = new ActiveDataProvider([
            'query' => $query,
        ]);
        $dataProvider->setSort(['defaultOrder' => $this->searchDefaultOrder()]);
        $this->load($params);

        $fieldOptions = $this->getFieldsOptions();

        foreach ($this->attributes() as $attribute) {
            if ($this->$attribute && isset($fieldOptions[$attribute])) {
                if (in_array($fieldOptions[$attribute]['type'],
                        ['smallint', 'integer', 'bigint', 'float', 'decimal', 'money',
                        'boolean', 'date', 'datetime', 'enum', 'reference'])) {
                    $value = $this->$attribute;

                    $operand = false;
                    if (strpos($value, '>=') === 0 || strpos($value, '<=') === 0) {
                        $operand = substr($value, 0, 2);
                        $value   = substr($value, 2);
                    } elseif (strpos($value, '>') === 0 || strpos($value, '<') === 0) {
                        $operand = substr($value, 0, 1);
                        $value   = substr($value, 1);
                    }
                    if (in_array($fieldOptions[$attribute]['type'],
                            ['date', 'datetime'])) {
                        $value = (string) (new DateTime($value));
                    }
                    if ($operand) {
                        $query->andWhere($attribute.$operand.':'.$attribute,
                            [':'.$attribute => $value]);
                    } else {
                        $query->andWhere([$attribute => $value]);
                    }
                } else {
                    $query->andWhere(['ilike', $attribute, $this->$attribute]);
                }
            }
        }

        return $dataProvider;
    }

    /**
     * Возвращает массив сортировок по умолчанию для поиска
     *
     * @return array
     */
    protected function searchDefaultOrder()
    {
        $defaultOrder = [];
        foreach ($this->primaryKey() as $field) {
            $defaultOrder[$field] = SORT_ASC;
        }
        return $defaultOrder;
    }
}
