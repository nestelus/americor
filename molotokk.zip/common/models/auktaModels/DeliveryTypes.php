<?php

namespace common\models\auktaModels;

use Yii;
use common\models\auktaModels\Products;
use \common\models\auktaModels\AuktaModel;
use common\models\auktaModels\enumModels\DeliveryType;

/**
 * This is the model class for table "{{%delivery_types}}".
 *
 * @property integer $id
 * @property integer $user_id
 * @property string $name
 * @property integer $type_id
 * @property string $cost
 * @property integer $term
 * @property string $Conditional
 *
 * @property User $user
 * @property Sales[] $sales
 */
class DeliveryTypes extends AuktaModel
{

      /**
       * @inheritdoc
       */
      public static function tableName()
      {
            return '{{%delivery_types}}';
      }

      public function init()
      {
            $this->is_default = TRUE;
            parent::init();
      }

      public function beforeValidate()
      {
            if ($parent = parent::beforeValidate())
            {
                  if (empty($this->name))
                  {
                        $this->name = DeliveryType::getLabel($this->type_id);
                  }
            }
            return $parent;
      }

      public function getSingularNominativeName()
      {
            return Yii::t('sales', 'Способ доставки');
      }

      public function getPluralNominativeName()
      {
            return Yii::t('sales', 'Способы доставки');
      }

      /**
       * @inheritdoc
       */
      public function rules()
      {
            return [
                [['user_id', 'type_id'], 'required'],
                [['user_id', 'type_id', 'is_default'], 'integer'],
                ['name', 'unique', 'message' => 'Измените название способа, чтобы отличать его от других.'],
                [['conditional', 'name', 'cost', 'term'], 'string'],
                [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => Yii::$app->getUser()->identityClass,
                    'targetAttribute' => ['user_id' => 'id']],
            ];
      }

      /**
       * @inheritdoc
       */
      public function attributeLabels()
      {
            return [
                'id' => Yii::t('sales', 'ID'),
                'name' => Yii::t('sales', 'Название'),
                'user_id' => Yii::t('sales', 'User ID'),
                'type_id' => Yii::t('sales', 'Тип'),
                'cost' => Yii::t('sales', 'Стоимость доставки'),
                'term' => Yii::t('sales', 'Сроки доставки'),
                'conditional' => Yii::t('sales', 'Прочие условия'),
                'is_default' => Yii::t('sales',
                    'Применять по умолчанию к новым товарам'),
            ];
      }

      /**
       * @return \yii\db\ActiveQuery
       */
      public function getUser()
      {
            return $this->hasOne(Yii::$app->getUser()->identityClass,
                    ['id' => 'user_id']);
      }

      /**
       * @return \yii\db\ActiveQuery
       */
      public function getProducts()
      {
            return $this->hasMany(Products::className(), ['id' => 'product_id'])
                    ->viaTable('{{%delivery_product}}',
                        ['delivery_type_id' => 'id']);
      }
}