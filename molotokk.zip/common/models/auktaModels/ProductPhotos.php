<?php

namespace common\models\auktaModels;

use Yii;
use yii\imagine\Image;
use Imagine\Image\Box;

/**
 * This is the model class for table "{{%product_photos}}".
 *
 * @property integer $id
 * @property string $file_name
 * @property integer $product_id
 * @property integer $created_at
 *
 * @property Products $product
 */
class ProductPhotos extends \common\models\auktaModels\AuktaModel
{
    public $image;

    /**
     * @inheritdoc
     */
    public static function tableName()
    {
        return '{{%product_photos}}';
    }

    public function beforeSave($insert)
    {
        if ($insert) {
            $this->created_at = time();
        }
        return parent::beforeSave($insert);
    }

    /**
     * @inheritdoc
     */
    public function rules()
    {
        return [
            [['file_name', 'product_id'], 'required'],
            [['product_id', 'created_at', 'order'], 'integer'],
            [['file_name'], 'string', 'max' => 255],
            [['image'], 'safe'],
            [['image'], 'file', 'extensions' => 'jpg, gif, png'],
            [['product_id'], 'exist', 'skipOnError' => true, 'targetClass' => Products::className(),
                'targetAttribute' => ['product_id' => 'id']],
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('products', 'ID'),
            'file_name' => Yii::t('products', 'File Name'),
            'product_id' => Yii::t('products', 'Product ID'),
            'order' => Yii::t('products', 'Order'),
            'created_at' => Yii::t('general', 'Created At'),
            'image' => Yii::t('products', 'Photo'),
        ];
    }

    public function delete()
    {
        $file_origin = $this->getPathPhoto();
        $dir_thumb   = dirname($file_origin).'/'.(explode('.', $this->file_name)[0]);
        if ($objs        = glob($dir_thumb."/*")) {
            foreach ($objs as $obj) {
                @unlink($obj);
            }
        }
        if (is_dir($dir_thumb)) {
            rmdir($dir_thumb);
        }
        @unlink($file_origin);
        parent::delete();
    }

    /**
     * @return \yii\db\ActiveQuery
     */
    public function getProduct()
    {
        return $this->hasOne(Products::className(), ['id' => 'product_id']);
    }

    public function nextOrder($main = FALSE)
    {
        $product = $this->product;

        if ($main) {
            $main_photo = $product->mainPhoto;
            if ($main_photo) {
                $main_photo->updateAttributes(['order' => 0]);
            }
            $this->updateAttributes(['order' => 1]);
        } else {
            $photos = $product->getProductPhotos()->where(['order' => 1])->count();

            $this->updateAttributes(['order' => (1 - $photos)]);
        }

        /* @var $product molotokk/models/Products */

        return TRUE;
    }

    public function setMain()
    {
        if ($this->order == 1) {
            return true;
        }
        $old_main = $this->product->getMainPhoto();
        if ($old_main) {
            $old_main->updateAttributes(['order' => 0]);
        }
        $this->updateAttributes(['order' => 1]);
    }

    public function upPhoto()
    {

        if ($upperPhoto = self::find(['product_id' => $this->product_id])
            ->andWhere('`order` < '.$this->order)
            ->orderBy('order', SORT_DESC)
            ->one()) {

            $order = $this->order;

            $this->order = $upperPhoto->order;
            if ($this->save()) {

                $upperPhoto->order = $order;
                $upperPhoto->save();
            }
        }
        return true;
    }

    public function downPhoto()
    {

        if ($downPhoto = self::find(['product_id' => $this->product_id])
            ->andWhere('`order` > '.$this->order)
            ->orderBy('order')
            ->one()) {
            $order       = $this->order;
            $this->order = $downPhoto->order;
            if ($this->save()) {
                $downPhoto->order = $order;
                $downPhoto->save();
            }
        }
        return true;
    }

    public function getPathPhoto($w = null, $h = null)
    {
        $path = Yii::getAlias(Yii::$app->params['pathPhotos']).$this->product_id.'/';
        if (!file_exists($path.$this->file_name)) {
            $path = Yii::getAlias(Yii::$app->params['pathPhotosLocal']).$this->product_id.'/';
            if (!file_exists($path)) {
                mkdir(($path), 0777, TRUE);
            }
        }


        if (!is_null($w) || !is_null($h)) {
            $ext = end((explode(".", $this->file_name)));
            return $path.(explode(".", $this->file_name)[0]).'/'.(is_null($w) ? ''
                        : ('W'.$w)).(is_null($h) ? '' : ('H'.$h)).".{$ext}";
        } else {
            return $path.$this->file_name;
        }
    }

    public function getUrlPhoto($w = null, $h = null)
    {
        $path = Yii::getAlias(Yii::$app->params['urlPhotos']).$this->product_id.'/';

        if (!is_null($w) || !is_null($h)) {
            $ext = end((explode(".", $this->file_name)));

            $path_w_h = $path.(explode(".", $this->file_name)[0]).'/'.(is_null($w)
                        ? '' : ('W'.$w)).(is_null($h) ? '' : ('H'.$h)).".{$ext}";
            return $path_w_h;
        } else {
            return $path.$this->file_name;
        }

        $photofile = @fopen($path.$this->file_name, 'rb');
        if ($photofile == false) {
            $path      = Yii::getAlias(Yii::$app->params['urlPhotosLocal']).$this->product_id.'/';
            $photofile = @fopen($path.$this->file_name, 'rb');
            if ($photofile == false) {
                $path            = Yii::getAlias('@static/img/nophoto/');
                $this->file_name = 'nophoto.png';
            }
        } else {
            fclose($photofile);
        }
        if (!is_null($w) || !is_null($h)) {
            $ext      = end((explode(".", $this->file_name)));
            $path_w_h = $path.(explode(".", $this->file_name)[0]).'/'.(is_null($w)
                        ? '' : ('W'.$w)).(is_null($h) ? '' : ('H'.$h)).".{$ext}";

//            var_dump($path_w_h);
//            die();
            $photo_min = @fopen($path_w_h, 'rb');

            if ($photo_min == false) {
                $path_trumb = $this->getPathPhoto($w, $h);
                file_exists(dirname($path_trumb)) or mkdir(dirname($path_trumb),
                        0777, TRUE);
//                var_dump((dirname($path_trumb)));
//                die();

                $img    = Image::getImagine()->open($path.$this->file_name);
                $size   = $img->getSize();
                $width  = $size->getWidth();
                $height = $size->getHeight();
                if (!is_null($w) && $width > $w) {
                    $ratio  = $width / $height;
                    $width  = $w;
                    $height = round($width / $ratio);
                    $box    = new Box($width, $height);
                    $img->resize($box);
                }
                if (!is_null($h) && $height > $h) {
                    $ratio  = $width / $height;
                    $height = $h;
                    $width  = round($height * $ratio);
                    $box    = new Box($width, $height);
                    $img->resize($box);
                }
                $img->save($path_trumb);
                $path_w_h = Yii::getAlias(Yii::$app->params['urlPhotosLocal']).$this->product_id.'/'.(explode(".",
                        $this->file_name)[0]).'/'.(is_null($w) ? '' : ('W'.$w)).(is_null($h)
                            ? '' : ('H'.$h)).".{$ext}";
            } else {
                fclose($photo_min);
            }
            return $path_w_h;
        }

        return $path.$this->file_name;
    }
}
