<?php

namespace common\models\auktaModels;

use Yii;
use common\models\User;
use common\models\auktaModels\Products;
use common\models\Profile;

/**
 * This is the model class for table "{{%user_ratings}}".
 *
 * @property integer $id
 * @property integer $author_id
 * @property integer $user_id
 * @property integer $rating_type
 * @property string $rating_text
 * @property string $created_at
 *
 * @property User $author
 * @property User $user
 */
class UserRatings extends \common\models\auktaModels\AuktaModel
{
      const RATING_NEGATIVE       = -1;
      const RATING_POSITIVE       = 1;
      const RATING_NEUTRAL        = 0;
      const DIRECTION_FROM_BUYER  = 1;
      const DIRECTION_FROM_SELLER = 2;

      /**
       * @inheritdoc
       */
      public static function tableName()
      {
            return '{{%user_ratings}}';
      }

      public function afterSave($insert, $changedAttributes)
      {
            parent::afterSave($insert, $changedAttributes);
            if ($insert)
            {
                  $profile = Profile::findOne($this->user_id);
                  $profile->rating += $this->rating_type;
                  $profile->save();
            }
      }

      public function beforeSave($insert)
      {
            if (parent::beforeSave($insert))
            {
                  $this->created_at = time();
                  return true;
            }
            return false;
      }

      /**
       * @inheritdoc
       */
      public function rules()
      {
            return [
                [['author_id', 'user_id', 'product_id', 'rating_text'], 'required'],
                ['rating_type', 'default', 'value' => 0],
                [['author_id', 'user_id', 'rating_type', 'product_id', 'direction'],
                    'integer'],
                [['rating_text'], 'string', 'min' => 5, 'tooShort' => 'Отзыв не может быть короче 5 символов'],
                [['rating_text'], 'string', 'max' => 300, 'tooLong' => 'Слишком длинный отзыв. Оставьте не более 300 символов'],
                [['rating_text'], 'filter', 'filter' => function($value)
                {
                      return htmlentities(strip_tags($value));
                }],
                [['author_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(),
                    'targetAttribute' => ['author_id' => 'id']],
                [['user_id'], 'exist', 'skipOnError' => true, 'targetClass' => User::className(),
                    'targetAttribute' => ['user_id' => 'id']],
                [['product_id'], 'exist', 'skipOnError' => true, 'targetClass' => Products::className(),
                    'targetAttribute' => ['product_id' => 'id']],
            ];
      }

      /**
       * @inheritdoc
       */
      public function attributeLabels()
      {
            return [
                'id' => Yii::t('nc_users', 'ID'),
                'author_id' => Yii::t('nc_users', 'Author ID'),
                'user_id' => Yii::t('nc_users', 'User ID'),
                'rating_type' => Yii::t('nc_users', 'Тип'),
                'rating_text' => Yii::t('nc_users', 'Отзыв'),
            ];
      }

      /**
       * @return \yii\db\ActiveQuery
       */
      public function getAuthor()
      {
            return $this->hasOne(User::className(), ['id' => 'author_id']);
      }

      /**
       * @return \yii\db\ActiveQuery
       */
      public function getUser()
      {
            return $this->hasOne(User::className(), ['id' => 'user_id']);
      }

      /**
       * @return \yii\db\ActiveQuery
       */
      public function getProduct()
      {
            return $this->hasOne(Products::className(), ['id' => 'product_id']);
      }
}