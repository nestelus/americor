<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\rbac;

use yii\rbac\Rule;

/**
 * Description of OwnItemRule
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class OwnItemRule extends Rule {

      public $name = 'isAuthor'; // Имя правила

      public function execute($user_id, $item, $params) {

            return isset($params['model']) ? $params['model']->user_id == $user_id : false;
      }

}
