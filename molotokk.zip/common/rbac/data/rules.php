<?php
return [
    'isAuthor' => 'O:23:"common\\rbac\\OwnItemRule":3:{s:4:"name";s:8:"isAuthor";s:9:"createdAt";N;s:9:"updatedAt";N;}',
];
