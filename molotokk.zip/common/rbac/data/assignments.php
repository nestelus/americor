<?php
return [
    1 => [
        'admin',
    ],
    4 => [
        'user',
    ],
    2 => [
        'admin',
    ],
    3 => [
        'admin',
    ],
];
