<?php
return [
    'admin' => [
        'type' => 1,
    ],
    'moderator' => [
        'type' => 1,
    ],
    'user' => [
        'type' => 1,
        'children' => [
            'adminOwnProduct',
            'createProduct',
            'viewOwnProducts',
        ],
    ],
    'seller' => [
        'type' => 1,
    ],
    'adminOwnProduct' => [
        'type' => 2,
        'description' => 'Редактирование своего товара',
        'ruleName' => 'isAuthor',
    ],
    'viewOwnProducts' => [
        'type' => 2,
        'description' => 'Просмотр своих товаров',
    ],
    'createProduct' => [
        'type' => 2,
        'description' => 'Создание товара',
    ],
];
