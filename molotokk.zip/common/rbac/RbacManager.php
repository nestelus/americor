<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace common\rbac;

use yii\rbac\PhpManager as BasePhpManager;
use dektrium\rbac\components\ManagerInterface;
use common\models\User;

/**
 * Description of RbacManager
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class RbacManager extends BasePhpManager implements ManagerInterface {

      public function getItem($name) {

      }

      public function getItemsByUser($userId) {

            if (empty($userId))
            {
                  return [];
            }

            $role_name = User::findOne($userId)->role;

            $roles[$role_name] = $this->getItem($role_name);

            return $roles;
      }

      public function getItems($type = null, $excludeItems = []) {
            $items = [];

            foreach ($this->items as $name => $item)
            {
                  /* @var $item Item */
                  if ($item->type == $type && !in_array($name, $excludeItems))
                  {
                        $items[$name] = $item;
                  }
            }

            return $items;
      }

      public function checkAccess($userId, $permissionName, $params = array()) {
            $roles = $this->getRolesByUser($userId);
            foreach ($roles as $role)
            {
                  if ($role->name == 'admin')
                  {
                        return true;
                  }
            }
            return parent::checkAccess($userId, $permissionName, $params);
      }

      public function getUsersByRoles($role) {
            $users = [];
            foreach ($this->assignments as $user_id => $assigments)
            {
                  foreach ($assigments as $itemName => $assignment)
                  {
                        if ($itemName == $role)
                        {
                              $users[] = $user_id;
                        }
                  }
            }
            return $users;
      }

}
