<?php

namespace backend\models\aukta;

use common\models\auktaModels\PaymentSystems as commonPaymentSystem;

/**
 * Description of PaymentSystems
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class PaymentSystems extends commonPaymentSystem {

      public static function updatePaymentSystems($paymentsSystems) {

            foreach ($paymentsSystems as $paymentsSystem)
            {
                  if (!($paySys = self::findOne(['pg_payment_system' => $paymentsSystem->pg_payment_system])))
                  {
                        $paySys = new self();
                  }
            }
      }

}
