<?php

namespace backend\models\aukta;

use common\models\auktaModels\Categories as commonCategories;

/**
 * Description of Categories
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class Categories extends commonCategories
{

}