<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace backend\models\aukta;

use common\models\auktaModels\Products as commonProducts;

/**
 * Description of Products
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class Products extends commonProducts {
      //put your code here
}
