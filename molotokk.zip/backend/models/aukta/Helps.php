<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace backend\models\aukta;

use common\models\Helps as commonHelps;
use Yii;

/**
 * Description of help
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class Helps extends commonHelps {

      public function save() {
            $file = Yii::getAlias('@common/helps/') . $this->url . '.html';
            // chmod($file, 0777);
            return file_put_contents($file, '<h1>' . $this->title . '</h1>'
                    . $this->html);
      }

      public function rules() {
            return array_merge(parent::rules(), [
                [['url', 'html', 'title'], 'string'],
            ]);
      }

}
