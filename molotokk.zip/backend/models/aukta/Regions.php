<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace backend\models\aukta;

use common\models\auktaModels\Regions as commonRegions;

/**
 * Description of Regions
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class Regions extends commonRegions {
      //put your code here
}
