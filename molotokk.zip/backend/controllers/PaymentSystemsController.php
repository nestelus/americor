<?php

namespace backend\controllers;

use Yii;
use common\models\auktaModels\PaymentSystems;
use yii\data\ActiveDataProvider;
use common\controllers\AuktaController;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * PaymentSystemsController implements the CRUD actions for PaymentSystems model.
 */
class PaymentSystemsController extends AuktaController {

      /**
       * @inheritdoc
       */
      public function behaviors() {
            return [
                'verbs' => [
                    'class'   => VerbFilter::className(),
                    'actions' => [
                        'delete' => ['POST'],
                    ],
                ],
            ];
      }

      /**
       * Lists all PaymentSystems models.
       * @return mixed
       */
      public function actionIndex() {
            $dataProvider = new ActiveDataProvider([
                'query' => PaymentSystems::find(),
            ]);

            return $this->render('index', [
                        'dataProvider' => $dataProvider,
            ]);
      }

      /**
       * Displays a single PaymentSystems model.
       * @param integer $id
       * @return mixed
       */
      public function actionView($id) {
            return $this->render('view', [
                        'model' => $this->findModel($id),
            ]);
      }

      /**
       * Creates a new PaymentSystems model.
       * If creation is successful, the browser will be redirected to the 'view' page.
       * @return mixed
       */
      public function actionCreate() {
            $model = new PaymentSystems();

            if ($model->load(Yii::$app->request->post()) && $model->save())
            {
                  return $this->redirect(['view', 'id' => $model->id]);
            }
            else
            {
                  return $this->render('create', [
                              'model' => $model,
                  ]);
            }
      }

      /**
       * Updates an existing PaymentSystems model.
       * If update is successful, the browser will be redirected to the 'view' page.
       * @param integer $id
       * @return mixed
       */
      public function actionUpdate($id) {
            $model = $this->findModel($id);

            if ($model->load(Yii::$app->request->post()) && $model->save())
            {
                  return $this->redirect(['view', 'id' => $model->id]);
            }
            else
            {
                  return $this->render('update', [
                              'model' => $model,
                  ]);
            }
      }

      /**
       * Deletes an existing PaymentSystems model.
       * If deletion is successful, the browser will be redirected to the 'index' page.
       * @param integer $id
       * @return mixed
       */
      public function actionDelete($id) {
            $this->findModel($id)->delete();

            return $this->redirect(['index']);
      }

      /**
       * Finds the PaymentSystems model based on its primary key value.
       * If the model is not found, a 404 HTTP exception will be thrown.
       * @param integer $id
       * @return PaymentSystems the loaded model
       * @throws NotFoundHttpException if the model cannot be found
       */
      protected function findModel($id) {
            if (($model = PaymentSystems::findOne($id)) !== null)
            {
                  return $model;
            }
            else
            {
                  throw new NotFoundHttpException('The requested page does not exist.');
            }
      }

      public function actionPaymentSystems() {
            $platron_api = Yii::$app->get('platron');
            $response    = $platron_api->getUrlListSystems(0);
      }

}
