<?php

namespace backend\controllers;

use Yii;
use common\models\auktaModels\Articles;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use common\controllers\AuktaController;
use common\models\auktaModels\enumModels\ArticleTypes;

/**
 * ArticlesController implements the CRUD actions for Articles model.
 */
class ArticlesController extends AuktaController {

    /**
     * @inheritdoc
     */
    public function behaviors() {
        return [
            'verbs' => [
                'class'   => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all Articles models.
     * @return mixed
     */
    public function actionIndex($type = null) {
        if (is_null($type))
        {
            $type = ArticleTypes::ARTICLE_HELP;
        }

        return $this->render('index', [
                    'model' => null,
                    'type'  => $type,
                    'view'  => 'view',
        ]);
    }

    /**
     * Displays a single Articles model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id) {
        $model = $this->findModel($id);
        $type = $model->type;
        {
            return $this->render('index', [
                        'model' => $model,
                        'type'  => $type,
                        'view'  => 'view',
            ]);
        }
    }

    /**
     * Creates a new Articles model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate($type, $parent_id = null) {
        $model = new Articles([
            'type'      => $type,
            'parent_id' => $parent_id,
        ]);

        if ($model->load(Yii::$app->request->post()) && $model->save())
        {
            return $this->redirect(['view', 'id' => $model->id]);
        }
        else
        {
            return $this->render('index', [
                        'model' => $model,
                        'type'  => $type,
                        'view'  => 'create',
            ]);
        }
    }

    /**
     * Updates an existing Articles model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id) {
        $model = $this->findModel($id);
        $type = $model->type;

        if ($model->load(Yii::$app->request->post()) && $model->save())
        {
            return $this->redirect(['view', 'id' => $model->id]);
        }
        else
        {
            return $this->render('index', [
                        'model' => $model,
                        'type'  => $type,
                        'view'  => 'update',
            ]);
        }
    }

    /**
     * Deletes an existing Articles model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id) {
        $article = $this->findModel($id);
        Articles::updateAll(['parent_id' => $article->parent_id], ['parent_id' => $id]);
        $article->delete();
        return $this->redirect(['index']);
    }

    /**
     * Finds the Articles model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return Articles the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id) {
        if (($model = Articles::findOne($id)) !== null)
        {
            return $model;
        }
        else
        {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

}
