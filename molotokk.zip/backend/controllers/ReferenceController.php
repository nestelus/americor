<?php

namespace backend\controllers;

use Yii;
use common\models\auktaModels\ReferenceType;
use common\models\auktaModels\PropertyReferrence;
use yii\data\ActiveDataProvider;
use common\controllers\AuktaController;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;

/**
 * ReferenceController implements the CRUD actions for ReferenceType model.
 */
class ReferenceController extends AuktaController {

    /**
     * @inheritdoc
     */
    public function behaviors() {
        return [
            'verbs' => [
                'class'   => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all ReferenceType models.
     * @return mixed
     */
    public function actionIndex() {
        $dataProvider = new ActiveDataProvider([
            'query' => ReferenceType::find(),
        ]);
        return $this->render('index', [
                    'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Creates a new ReferenceType model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate() {
        $model = new ReferenceType();

        if ($model->load(Yii::$app->request->post()) && $model->save())
        {
            return $this->redirect('/reference/');
        }
    }

    /**
     * Updates an existing ReferenceType model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id) {
        $model = $this->findModel($id);

        if ($model->load(Yii::$app->request->post()) && $model->save())
        {
            return $this->redirect('/reference/');
        }
        else
        {
            return $this->renderPartial('_form', [
                        'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing ReferenceType model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id) {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    public function actionViewList($id) {
        $dataProvider = new ActiveDataProvider([
            'query' => PropertyReferrence::find()->where(['reference_type_id' => $id]),
        ]);
        return $this->renderPartial('view-list', [

                    'dataProvider'   => $dataProvider,
                    'reference_type' => ReferenceType::findOne($id),
        ]);
    }

    public function actionAddValue($id = null) {
        $property = new PropertyReferrence();
        if (is_null($id))
        {
            $property->load(Yii::$app->request->post());
            $property->save();
            $id = $property->reference_type_id;
            $dataProvider = new ActiveDataProvider([
                'query' => PropertyReferrence::find()->where(['reference_type_id' => $id]),
            ]);
            return $this->renderPartial('view-list', [

                        'dataProvider'   => $dataProvider,
                        'reference_type' => ReferenceType::findOne($id),
            ]);
        }
        return $this->renderPartial('_form_value', [
                    'model'          => $property,
                    'reference_type' => ReferenceType::findOne($id),
        ]);
    }

    public function actionUpdateValue($id) {
        $reference = PropertyReferrence::findOne($id);

        if ($reference->load(Yii::$app->request->post()) && $reference->save())
        {
            $dataProvider = new ActiveDataProvider([
                'query' => PropertyReferrence::find()->where(['reference_type_id' => $reference->reference_type_id]),
            ]);
            return $this->renderPartial('view-list', [

                        'dataProvider'   => $dataProvider,
                        'reference_type' => ReferenceType::findOne($reference->reference_type_id),
            ]);
        }
        return $this->renderPartial('_form_value', [
                    'model'          => $reference,
                    'reference_type' => ReferenceType::findOne($reference->reference_type_id),
        ]);
    }

    /**
     * Deletes an existing ReferenceType model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDeleteValue($id) {
        $reference = PropertyReferrence::findOne($id);
        $reference_type = $reference->reference_type_id;
        $reference->delete();
        $dataProvider = new ActiveDataProvider([
            'query' => PropertyReferrence::find()->where(['reference_type_id' => $reference_type]),
        ]);


        return $this->renderPartial('view-list', [

                    'dataProvider'   => $dataProvider,
                    'reference_type' => ReferenceType::findOne($reference_type),
        ]);
    }

    /**
     * Finds the ReferenceType model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return ReferenceType the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id) {
        if (($model = ReferenceType::findOne($id)) !== null)
        {
            return $model;
        }
        else
        {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }

}
