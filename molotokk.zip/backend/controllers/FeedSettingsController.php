<?php

namespace backend\controllers;

use Yii;
use common\models\FeedSettings;
use yii\data\ActiveDataProvider;
use yii\web\Controller;
use yii\web\NotFoundHttpException;
use yii\filters\VerbFilter;
use common\models\auktaModels\Categories;
use common\models\FeedProperties;
use yii\helpers\Url;
use common\components\feeds\AuktaFeed;

/**
 * FeedSettingsController implements the CRUD actions for FeedSettings model.
 */
class FeedSettingsController extends Controller
{

    /**
     * @inheritdoc
     */
    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    /**
     * Lists all FeedSettings models.
     * @return mixed
     */
    public function actionIndex()
    {
        $dataProvider = new ActiveDataProvider([
            'query' => FeedSettings::find(),
        ]);

        return $this->render('index',
                [
                'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Displays a single FeedSettings model.
     * @param integer $id
     * @return mixed
     */
    public function actionView($id)
    {
        $feed         = $this->findModel($id);
        $dataProvider = new ActiveDataProvider([
            'query' => $feed->getFeedAssigns(),
        ]);
        return $this->render('view',
                [
                'model' => $this->findModel($id),
                'dataProvider' => $dataProvider,
        ]);
    }

    /**
     * Creates a new FeedSettings model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionCreate()
    {
        $model = new FeedSettings();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('create',
                    [
                    'model' => $model,
            ]);
        }
    }

    /**
     * Updates an existing FeedSettings model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionUpdate($id)
    {
        $model = $this->findModel($id);
        if ($post  = Yii::$app->request->post()) {
            $model->load($post);
            $model->save(false);
            //var_dump($post);
            if (isset($post['FeedProperties'])) {
                $model->updateFeedProperties($post['FeedProperties']);
            }
            if (isset($post['deliveryProduct'])) {
                $model->updateDeliveryFeed($post['deliveryProduct']);
            }
            if (isset($post['paymentProduct'])) {
                $model->updatePaymentMethods($post['paymentProduct']);
            }

            return $this->redirect(['view', 'id' => $model->id]);
        } else {
            return $this->render('update',
                    [
                    'model' => $model,
            ]);
        }
    }

    /**
     * Deletes an existing FeedSettings model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDelete($id)
    {
        $this->findModel($id)->delete();

        return $this->redirect(['index']);
    }

    public function actionGetProperties($id)
    {
        if (Yii::$app->request->isAjax) {
            $category       = Categories::findOne($id);
            if ($cat_properties = $category->categoryProperties) {
                foreach ($cat_properties as $property) {
                    $feed_property[] = new FeedProperties([
                        'category_property_id' => $property->id,
                    ]);
                }
                return $this->renderPartial('_properties',
                        [
                        'properties' => $feed_property,
                ]);
            }
        }
        return false;
    }

    public function actionRunFeed($id)
    {
        $feed = FeedSettings::findOne($id);
        if (!empty($feed)) {
            $aukta_feed       = new AuktaFeed();
            $aukta_feed->feed = $feed;
            $aukta_feed->run();
            $aukta_feed->reset();
        }
        return $this->redirect(Url::to(['feed-settings/view', 'id' => $id]));
    }

    /**
     * Finds the FeedSettings model based on its primary key value.
     * If the model is not found, a 404 HTTP exception will be thrown.
     * @param integer $id
     * @return FeedSettings the loaded model
     * @throws NotFoundHttpException if the model cannot be found
     */
    protected function findModel($id)
    {
        if (($model = FeedSettings::findOne($id)) !== null) {
            return $model;
        } else {
            throw new NotFoundHttpException('The requested page does not exist.');
        }
    }
}
