<?php

namespace backend\controllers;

use Yii;
use common\controllers\CategoriesController as commonCategories;
use backend\models\aukta\Categories;
use \backend\models\aukta\CategoryProperties;
use yii\data\ActiveDataProvider;
use yii\helpers\Url;

/**
 * Description of CategoriesController
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class CategoriesController extends commonCategories
{
    public $modelClass = 'backend\Categories';

    public function actionIndex($id = NULL)
    {
        $model = new Categories();

        return $this->render('index',
                [
                'model' => $model,
                'id' => $id,
        ]);
    }

    public function actionCreate()
    {
        $model = new Categories();
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect(['index', [
                        'model' => $model,
            ]]);
        }
    }

    public function actionUpdateName()
    {
        $post = Yii::$app->request->post();
        if (Yii::$app->request->isAjax) {
            if ($category = Categories::findOne($post['id'])) {
                $category->updateAttributes(['name' => $post['name']]);
                return $category->name;
            } else {
                return false;
            }
        }
    }

    public function actionDelete($id)
    {
        $post = Yii::$app->request->post();

        $category = Categories::findOne($id);
        if (empty($category->childrenCategories)) {
            if ($category->moveLotTo($post['to_id'])) {
                $parent = $category->parent;
                $category->delete();
                $parent->setType();
            }
        } else {
            Yii::$app->session->setFlash('error',
                'У категории есть подкатегории. Удаление невозможно');
        }
        return $this->redirect(Url::toRoute('/categories'));
    }

    public function actionMove()
    {
        $post = Yii::$app->request->post();
        if (Yii::$app->request->isAjax) {
            $category            = Categories::findOne($post['id']);
            $category->parent_id = $post['parent_id'];
            $category->save();
            return json_encode(Categories::treeItems());
        }
    }

    public function actionSaveProperty($id)
    {
        $model              = new CategoryProperties();
        $model->category_id = $id;
        $category           = Categories::findOne($id);
        if ($post               = Yii::$app->request->post()) {

            if ($model->load($post) && $model->save()) {

                $category_properties = new ActiveDataProvider([
                    'query' => CategoryProperties::find()->where(['category_id' => $model->category_id]),
                ]);
                return $this->renderPartial(
                        'category_properties',
                        [
                        'dataProvider' => $category_properties,
                        'category' => $category,
                        ]
                );
                //return $this->redirect(['/categories/index/' . $model->category_id . '/']);
            }
        } else {

            Yii::$app->getSession()->setFlash('addProperty', $model->firstErrors);
            return $this->renderPartial('_form_property',
                    [
                    'model' => $model,
                    'category' => $category,
            ]);
        }
    }

    public function actionViewProperties($id)
    {
        $category            = Categories::findOne($id);
        $category_properties = new ActiveDataProvider([
            'query' => CategoryProperties::find()->where(['category_id' => $id]),
        ]);
        return $this->renderPartial(
                'category_properties',
                [
                'dataProvider' => $category_properties,
                'category' => $category,
                ]
        );
    }

    public function actionAddProperty($id)
    {
        $model    = new CategoryProperties();
        $category = Categories::findOne($id); {
            return $this->renderAjax('_form_property',
                    [
                    'model' => $model,
                    'category' => $category,
            ]);
        }
    }

    public function actionUpdateProperty($id)
    {

        $model = CategoryProperties::findOne($id);


        return $this->renderPartial('_form_property',
                [
                'model' => $model,
                'category' => $model->category,
        ]);
    }

    public function actionDeleteProperty($id)
    {
        $model    = CategoryProperties::findOne($id);
        $category = $model->category;

        $model->delete();

        $category_properties = new ActiveDataProvider([
            'query' => CategoryProperties::find()->where(['category_id' => $category->id]),
        ]);
        return $this->renderPartial(
                'category_properties',
                [
                'dataProvider' => $category_properties,
                'category' => $category,
                ]
        );
    }
}
