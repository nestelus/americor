<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace backend\modules\aukta\controllers;

use common\controllers\AuktaController;
use yii\data\ActiveDataProvider;
use common\models\auktaModels\enumModels\StateProduct;
use backend\models\aukta\Products;

/**
 * Description of ProducsController
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class ProductsController extends AuktaController {

      public $modelClass = 'backend\models\aukta\Products';

      public function actionProducts($state_id = null) {


            $dataProvider = new ActiveDataProvider();
            $query        = Products::find();


            if (!is_null($state_id))
            {
                  $query->where(['state_id' => $state_id]);
            }
            $dataProvider->query = $query;
            $view                = is_null($state_id) ? 'index' : StateProduct::createByValue($state_id);

            return $this->render('index', [

                        'dataProvider' => $dataProvider,
            ]);
      }

      /*
       * Одобрение модератором
       */

      public function actionConfirm($id) {

            $model = Products::findOne($id);

            if ($model && $model->state_id == StateProduct::STATE_ON_MODERATE)
            {
                  $model->state_id = $model->is_auction ? StateProduct::STATE_ON_CONFIRM : StateProduct::STATE_ON_SALE;
                  $model->save();
            }
            return $this->redirect(['products/products/' . StateProduct::STATE_ON_MODERATE]);
      }

}
