<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace backend\controllers;

use Yii;
use common\controllers\AuktaController;
use common\models\auktaModels\Products;
use common\models\auktaModels\enumModels\MailType;
use common\models\MailMessages;
use common\models\auktaModels\Sales;
use common\models\auktaModels\Messages;
use common\models\auktaModels\enumModels\StateProduct;
use common\models\auktaModels\AuctionStakes;

/**
 * Description of MailController
 *
 * @author Vladimir
 */
class MailController extends AuktaController
{

    public function actionIndex()
    {
        $mail_types = MailType::listData();

        foreach ($mail_types as $type => $name) {

            $model            = $this->_getModel($type);
            $mail_type[$name] = new MailMessages([
                'type' => $type,
                'model' => $model,
            ]);
        }
        return $this->render('index',
                [
                'mailTypes' => $mail_type,
                ]
        );
    }

    public function actionRenderMail($id)
    {
        $mail = new MailMessages(['type' => $id, 'model' => $this->_getModel($id)]);
        return(Yii::$app->mailer->render($mail->template, $mail->params,
                'layouts/html')
            );
    }

    protected function _getModel($type)
    {
        switch ($type) {
            case MailType::MAIL_MESSAGE_TO_LOT:
            case MailType::MAIL_MESSAGE_FROM_LOT:
                $model = Messages::find()->limit(1)->one();
                break;
            case MailType::MAIL_LOT_BUY:
            case MailType::MAIL_LOT_SELL:
                $model = Sales::find()->limit(1)->one();
                break;

            case MailType::MAIL_LOT_BUY_AUCTION:
            case MailType::MAIL_LOT_SELL_AUCTION:
            case MailType::MAIL_REMEMBE_CLOSE_BUYER:
            case MailType::MAIL_REMEMBE_CLOSE_SELLER:
            case MailType::MAIL_REMEMBE_RATING_BUYER:
            case MailType::MAIL_REMEMBE_RATING_SELLER:
                $model = Products::findOne(['state_id' => StateProduct::STATE_ON_SOLD]);
                break;
            case MailType::MAIL_LOT_PUBLIC:
            case MailType::MAIL_LOT_REPUBLIC:
                $model = Products::findOne(['state_id' => StateProduct::STATE_ON_SALE]);
                break;
            case MailType::MAIL_LOT_CLOSED:
                $model = Products::findOne(['state_id' => StateProduct::STATE_ON_HIDE]);
                break;
            case MailType::MAIL_LOT_OWER_BID:
            case MailType::MAIL_LOT_CANCEL_BID :
                $model = AuctionStakes::find()->limit(1)->one();
                break;
            case MailType::MAIL_USER_BLOCKED:
                $model = \common\models\User::find()->limit(1)->one();
        }


        return $model;
    }

    public function actionLotBuy($id)
    {
        $lot = Products::findOne($id);
        return(Yii::$app->mailer->render('lot-buy',
                [
                'lot' => $lot,
                ], 'layouts/html')
            );
    }

    public function actionLotSell($id)
    {
        $lot = Products::findOne($id);
        return(Yii::$app->mailer->render('lot-sell',
                [
                'lot' => $lot,
                ], 'layouts/html')
            );
    }

    public function actionLotBuyAuction($id)
    {
        $lot = Products::findOne($id);
        return(Yii::$app->mailer->render('lot-buy-auction',
                [
                'lot' => $lot,
                ], 'layouts/html')
            );
    }

    public function actionLotSellAuction($id)
    {
        $lot = Products::findOne($id);
        return(Yii::$app->mailer->render('lot-sell-auction',
                [
                'lot' => $lot,
                ], 'layouts/html')
            );
    }

    public function actionLotClosed($id)
    {
        $lot = Products::findOne($id);
        return(Yii::$app->mailer->render('lot-closed',
                [
                'lot' => $lot,
                ], 'layouts/html')
            );
    }

    public function actionLotPublic($id)
    {
        $lot = Products::findOne($id);
        return(Yii::$app->mailer->render('lot-public',
                [
                'lot' => $lot,
                ], 'layouts/html')
            );
    }

    public function actionLotRepublic($id)
    {
        $lot = Products::findOne($id);
        return(Yii::$app->mailer->render('lot-republic',
                [
                'lot' => $lot,
                ], 'layouts/html')
            );
    }

    public function actionLotRemembePay($id)
    {
        $lot = Products::findOne($id);
        return(Yii::$app->mailer->render('lot-remembe-pay',
                [
                'lot' => $lot,
                ], 'layouts/html')
            );
    }

    public function actionMessageFromLot($id)
    {
        $message = Messages::findOne($id);
        return(Yii::$app->mailer->render('message-from-lot',
                [
                'message' => $message,
                ], 'layouts/html')
            );
    }

    public function actionMessageToLot($id)
    {
        $message = Messages::findOne($id);
        return(Yii::$app->mailer->render('message-to-lot',
                [
                'message' => $message,
                ], 'layouts/html')
            );
    }

    public function actionLotOwerBid($id)
    {
        $stake = AuctionStakes::findOne($id);
        return(Yii::$app->mailer->render('lot-ower-bid',
                [
                'stake' => $stake,
                ], 'layouts/html')
            );
    }

    public function actionLotCancelBid($id)
    {
        $stake = AuctionStakes::findOne($id);
        return(Yii::$app->mailer->render('lot-cancel-bid',
                [
                'stake' => $stake,
                ], 'layouts/html')
            );
    }

    public function actionRemembeCloseBuyer($id)
    {
        $product = Products::findOne($id);
        return(Yii::$app->mailer->render('remembe-close-buyer',
                [
                'product' => $product,
                ], 'layouts/html')
            );
    }

    public function actionRemembeCloseSeller($id)
    {
        $product = Products::findOne($id);
        return(Yii::$app->mailer->render('remembe-close-seller',
                [
                'product' => $product,
                ], 'layouts/html')
            );
    }
}
