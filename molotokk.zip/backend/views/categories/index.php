<?php

use yii\helpers\Html;
use yii\bootstrap\Modal;
use yii\widgets\ActiveForm;
use yii\widgets\Pjax;
use yii\helpers\ArrayHelper;
use backend\models\aukta\Categories;
use common\widgets\Alert;

/**
 * @var yii\web\View                    $this
 */
$items = Categories::treeItems();

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<?php
Modal::begin([
    'header' => 'Категория',
    'id'     => 'modal_add_category',
])
?>
<?php
$form = ActiveForm::begin([
            'action' => '/categories/create/',
        ]);
?>

<?= $form->field($model, 'name'); ?>
<?=
$form->field($model, 'parent_id')->dropDownList(
        ArrayHelper::map($model->find()->all(), 'id', 'name', 'parent.name'), [
    'prompt' => '--Родительская категория--',
]);
?>
<div class="form-group">
    <?= Html::submitButton($model->isNewRecord ? 'Создать' : 'Сохранить', ['class' => 'btn btn-primary']); ?>
</div>
<?php ActiveForm::end() ?>
<?php Modal::end(); ?>

<div class="group-form">
    <?= Alert::widget() ?>
    <div class="col-md-4">
        <h1>Категории </h1>
        <?=
        Html::a('Добавить', ['#'], [
            'data-toggle' => 'modal',
            'data-target' => '#modal_add_category',
            'id'          => 'js_btn_add',
            'class'       => 'btn btn-primary',
        ]);
        ?>



        <p>
            <?=
            $this->render('_category_tree', [
                'id'    => $id,
                'items' => $items,
            ]);
            ?>

        </p>
    </div>

    <div id="properties" class="col-md-8">
        <?php
        Pjax::begin([
            'id'              => 'pj_properties',
            'enablePushState' => false,
            'linkSelector'    => '.pj_properties',
            'formSelector'    => '#pj_form_add-property',
        ])
        ?>

        <?php Pjax::end() ?>

    </div>

</div>
