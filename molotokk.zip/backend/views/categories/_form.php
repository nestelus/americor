<?php

/**
 * @var model backend\models\aukta\Categories
 */
use yii\helpers\ArrayHelper;
use common\components\NCActiveForm as ActiveForm;
use yii\helpers\Html;
?>
<div class="Model-form">
  <?php
  $form = ActiveForm::begin();

  echo $form->field($model, 'name');
  echo $form->field($model, 'parent_id')->dropDownList(
          ArrayHelper::map($model->find()->all(), 'id', 'name'), [
      'prompt' => '--Родительская категория--',
  ]);
  ?>
  <div class="form-group">
    <?php
// Блок кнопок формы

    echo Html::submitButton($model->isNewRecord ? 'Создать' : 'Сохранить', ['class' => 'btn btn-primary']);
    ?>
  </div>

</div>

