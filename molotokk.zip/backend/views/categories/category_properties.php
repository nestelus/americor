<?php

use yii\helpers\Html;
use yii\grid\GridView;
use common\models\auktaModels\enumModels\PropertyType;
use common\models\auktaModels\ReferenceType;
use yii\helpers\ArrayHelper;
use yii\bootstrap\Modal;
use yii\helpers\Url;
use yii\widgets\ActiveForm;
use backend\models\aukta\Categories;
use backend\models\aukta\CategoryProperties;
use yii\widgets\Pjax;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>

<?php if ($category) : ?>
    <h3><?= $category->getCategoryPath() ?></h3>
    <?=
    Html::a('Добавить характеристику',
        Url::to([
            '/categories/add-property/',
            'id' => $category->id,
        ]), [
        'class' => 'btn btn-success pj_properties ',
        ]
    )
    ?>

    <?php
    if (empty($category->childrenCategories)):
        Modal::begin([
            'header' => 'Удалить категорию <strong>'.$category->getCategoryPath().'</strong>',
            'id' => 'modal_del_category',
            'toggleButton' => [
                'id' => 'js_del_category',
                'label' => 'Удалить категорию',
                'tag' => 'button',
                'class' => 'btn btn-danger',
            ],
        ])
        ?>
        <?php
        $form = ActiveForm::begin([
                'action' => Url::to(['/categories/delete', 'id' => $category->id]),
        ]);
        ?>

        <div class="form-group">

            <label>Укажите категорию, в которую будут перенесены лоты</label>
            <?=
            Html::dropDownList('to_id', null,
                ArrayHelper::map(Categories::find()->where(['type' => 1])->all(),
                    'id', 'name', 'parent.name'),
                [
                'prompt' => '--Для переноса--',
                'class' => 'form-control'
            ]);
            ?>
        </div>
        <div class="form-group">
            <?=
            Html::submitButton('Удалить', ['class' => 'btn btn-danger']);
            ?>
        </div>
        <?php ActiveForm::end() ?>
        <?php Modal::end(); ?>
    <?php endif; ?>
    <p>
        <?=
        GridView::widget([
            'dataProvider' => $dataProvider,
            'columns' => [
                [
                    'class' => 'yii\grid\SerialColumn',
                ],
                ['class' => 'yii\grid\ActionColumn',
                    'template' => '{update} {delete}',
                    'urlCreator' => function( $action, $model, $key, $index ) {
                        return '/categories/'.$action.'-property/'.$key.'/';
                    },
                    'buttonOptions' => [
                        'class' => 'pj_properties',
                        'data-pjax' => 1,
                    ]
                ],
                'name',
                [
                    'class' => 'yii\grid\DataColumn',
                    'attribute' => 'type_id',
                    'content' => function ($model, $key, $index, $column) {
                        return PropertyType::getLabel($model->type_id);
                    },
                ],
                'referrenceType.name',
                [
                    'attribute' => 'is_mandatory',
                    'content' => function ($model, $key, $index, $column) {
                        return $model->is_mandatory ? 'Да' : 'Нет';
                    },
                ]
            ],
        ]);
        ?>
    </p>
<?php endif; ?>









