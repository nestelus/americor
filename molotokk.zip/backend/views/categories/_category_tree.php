<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use wbraganca\fancytree\FancytreeWidget;
use yii\web\JsExpression;
?>
<?php // var_dump($items);                        ?>
<?=

FancytreeWidget::widget([
    'options' => [
        'source'          => $items,
        'autoCollapse'    => false,
        'clickFolderMode' => 3,
        'init'            => new JsExpression('
            function(event, data){
                node = data.tree.getNodeByKey("' . $id . '");
                if (!(null === node)){
                    node.setExpanded();
                    node.setActive();
                    }
                }'),
        'activate'        => new JsExpression('
                        function(node, data) {
                              node  = data.node;
                              $.ajax({
                                    url: "/categories/view-properties/"+node.key+"/",
                                    success: function(data) {
                                    $("#pj_properties").html(data);}
                              });
                        }'),
        'extensions'      => ['dnd', 'edit'],
        'dnd'             => [
            'focusOnClick'          => true,
            'preventVoidMoves'      => true,
            'preventRecursiveMoves' => true,
            'autoExpandMS'          => 300,
            'dragStart'             => new JsExpression('function(node, data) {
                return true;
            }'),
            'dragEnter'             => new JsExpression('function(node, data) {
                return true;
            }'),
            'dragDrop'              => new JsExpression('function(node, data) {
                data.otherNode.moveTo(node, data.hitMode);
                 $.ajax({
                        url: "/categories/move/",
                        type: "POST",
                        data:({
                              id: data.otherNode.key ,
                              parent_id: node.key
                              }),
                        async: false,
                        dataType: "json",
                        success: function(items) {
                              data.tree.reload(items);
                              newnode = data.tree.getNodeByKey(data.otherNode.key);
                              newnode.setExpanded();
                              newnode.setActive();
                              }
                        });
            }'),
        ],
        'edit'            => [
            'adjustWidthOfs' => 4,
            'inputCss'       => '{  color: #000}',
            'triggerCancel'  => ["esc", "tab", "click"],
            'triggerStart'   => ["f2", "dblclick", "shift+click", "mac+enter"],
            'save'           => new JsExpression('function(event, data){
                    var node = data.node;
                    $.ajax({
                        url: "/categories/update-name/",
                        type: "POST",
                        data: { id: node.key, name: data.input.val() }
                      }).done(function(result){
                        node.setTitle(result);
                        node.setActive();
                      }).fail(function(result){
                        node.setTitle(data.orgTitle);
                      });
                    return true;
                }'),
            'close'          => new JsExpression('function(event, data){
                if( data.save ) {
                  $(data.node.span).addClass("pending");
                }
              }'),
        ],
    ],
]);
?>

