<?php


  $this->title = $model->getSingularNominativeName() . ' (создать)';


if (empty($this->params['breadcrumbs'])) {
  $this->params['breadcrumbs'][] = ['label' => $model->getPluralNominativeName(), 'url' => ['index']];
  $this->params['breadcrumbs'][] = $this->title;
}

require($this->findViewFile('_form', $this->context));

