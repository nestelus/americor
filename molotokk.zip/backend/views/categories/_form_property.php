<?php

/**
 * @var yii\web\View                    $this
 * @var backend\models\aukta            $model
 * @var backend\models\aukta\Categories $category
 *
 */
use yii\widgets\ActiveForm;
use yii\bootstrap\Html;
use yii\helpers\Url;
use yii\helpers\ArrayHelper;
use common\models\auktaModels\enumModels\PropertyType;
use common\models\auktaModels\ReferenceType;
?>
<h3>Новая характеристика категории "<?= $category->getCategoryPath() ?>"</h3>
<?php
echo common\widgets\Alert::widget();
$form = ActiveForm::begin([
        'action' => Url::to(['categories/save-property', 'id' => $category->id]),
        'method' => 'post',
        'id' => 'pj_form_add-property',
        'options' => [
            'data-pjax' => 1,
        ]
    ]);

echo $form->field($model, 'id')->hiddenInput()->label(false);

echo $form->field($model, 'name');
echo $form->field($model, 'is_mandatory')->checkbox();
echo $form->field($model, 'type_id')->dropDownList(PropertyType::getLabels());
echo $form->field($model, 'referrence_type_id')->dropDownList(ArrayHelper::map(ReferenceType::find()->all(),
        'id', 'name'), ['prompt' => '--Укажите список--']);
?>
<div class="form-group">
    <?=
    Html::submitButton($model->isNewRecord ? 'Создать' : 'Сохранить',
        ['class' => 'btn btn-primary']);
    ?>
</div>
<?php ActiveForm::end() ?>

