<?php

use yii\widgets\ActiveForm;
use yii\bootstrap\Html;
?>
<h1>Страница "Справка"</h1>
<?php
echo Html::textInput('title');

