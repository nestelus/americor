<?php

/**
 * @var yii\web\View                    $this
 * @var yii\data\DataProviderInterface  $dataProvider
 * @var BaseActiveRecord $searchModel
 */

use yii\grid\GridView;
use yii\helpers\Html;

/** @var Controller $controller */
$controller = $this->context;
/** @var Reference $modelClass */
$modelClass = $controller->modelClass;

if (empty($this->title)) {
    $this->title = $modelClass::getPluralNominativeName();
}

if (empty($this->params['breadcrumbs'])) {
    $this->params['breadcrumbs'][] = $this->title;
}

$actionsTemplate = [];
//if (Yii::$app->user->can($controller->viewPermission)) {
//    $actionsTemplate[] = '{view}';
//}
//if (Yii::$app->user->can($controller->updatePermission)) {
    $actionsTemplate[] = '{update}';
//}
//if (Yii::$app->user->can($controller->deletePermission)) {
    $actionsTemplate[] = '{delete}';
//}
$actionsTemplate = implode(' ', $actionsTemplate);

\yii\widgets\Pjax::begin(['formSelector' => '#column_sortable_form', 'linkSelector' => '[data-sort]']);
echo GridView::widget(
    [

        'dataProvider'         => $dataProvider,
        'filterModel'          => $searchModel,

    
        'tableOptions' => [
            'class' => 'table table-striped table-bordered',
        ],
        'options' => [
            'data-pjax'=>1,
        ],
    ]
);
\yii\widgets\Pjax::end();
