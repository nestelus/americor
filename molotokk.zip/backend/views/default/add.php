<?php

use yii\helpers\Html;
use yii\helpers\Inflector;
use yii\helpers\StringHelper;

/* @var \app\components\View $this */
/* @var $model  */

$this->title = Yii::t('user', 'Add {modelClass}', [
    'modelClass' => Inflector::camel2words(StringHelper::basename($model->className())),
]);

$this->params['breadcrumbs'][] = ['label' => Inflector::pluralize(Inflector::camel2words(StringHelper::basename($model->className()))),
    'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>

<div class="auth-item-create">
    <h1><?= Html::encode($this->title) ?></h1>
    <?php echo $this->render('_form', [
        'model' => $model,
        'hiddenFields' => $hiddenFields
    ]); ?>
</div>