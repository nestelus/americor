<?php

/**
 * @var yii\web\View             $this
 * @var \app\models\BaseActiveRecord $model
 */
if (empty($this->title)) {
  $this->title = $model->getSingularNominativeName() . ' (новый элемент)';
}

if (empty($this->params['breadcrumbs'])) {
  $this->params['breadcrumbs'][] = ['label' => $model->getPluralNominativeName(), 'url' => ['index']];
  $this->params['breadcrumbs'][] = $this->title;
}

require($this->findViewFile('_form', $this->context));
