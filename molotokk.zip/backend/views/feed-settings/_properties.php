<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use yii\helpers\Html;
?>
<div class="row">
    <div class="col-md-12">
        <fieldset>
            <legend>
                Поля фида для характеристик
            </legend>
        </fieldset>

        <?php foreach ($properties as $property) : ?>
            <?php $category_property = $property->categoryProperty; ?>
            <div class="row form-group">
                <div class="col-md-3 text-right">
                    <label><?= $category_property->name ?> </label>
                </div>
                <div class="col-md-7">  
                    <?=
                    Html::textInput('FeedProperties['.$property->category_property_id.']',
                        $property->feed_key,
                        [
                        'class' => 'form-control',
                    ]);
                    ?>
                </div>
            </div>

        <?php endforeach; ?>

    </div>
</div>
