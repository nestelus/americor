<?php

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use kartik\widgets\Select2;
use common\widgets\RegionFormWidget;
use yii\helpers\ArrayHelper;
use common\models\User;
use backend\models\aukta\Categories;
use common\models\auktaModels\enumModels\PayMethod;
use common\models\auktaModels\enumModels\DeliveryType;
use yii\widgets\Pjax;

/* @var $this yii\web\View */
/* @var $model common\models\FeedSettings */
/* @var $form yii\widgets\ActiveForm */

$users      = ArrayHelper::map(User::find()->all(), 'id', 'username');
$categories = ArrayHelper::map(Categories::findAll(['type' => Categories::CATEGORY_END_TYPE]),
        'id', 'name', 'parent_id');
?>
<style>
    div.required label:after {
        content: " *";
        color: red;
    }
</style>

<div class="feed-settings-form">
    <?php $form       = ActiveForm::begin(); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Настройки feed
                </div>
                <div class="panel-body">
                    <?= $form->field($model, 'title')->textInput(['maxlength' => true]) ?>

                    <?= $form->field($model, 'url')->textInput(['maxlength' => true]) ?>

                    <?= $form->field($model, 'is_active')->checkbox() ?>

                    <?=
                    $form->field($model, 'user_id')->widget(Select2::className(),
                        [
                        'data' => $users,
                        'options' => ['placeholder' => 'Выберите пользователя'],
                    ])
                    ?>
                </div>
            </div>

            <div class="panel panel-default">
                <div class="panel-heading">
                    Значения по умолчанию
                </div>
                <div class="panel-body">                 

                    <?=
                    $form->field($model, 'category_id', [])->widget(Select2::className(),
                        [
                        'id' => 'js_category',
                        'data' => $categories,
                        'options' => ['placeholder' => 'Укажите категорию ...'],
                    ])
                    ?>

                    <div id="pj_feed-property">
                        <?php if (!empty($model->feedProperties)): ?>

                            <?=
                            $this->render('_properties',
                                [
                                'properties' => $model->feedProperties,
                            ])
                            ?>
                        <?php endif; ?>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <fieldset>
                                <legend>
                                    Условия продажи
                                </legend>
                                <div class="admin-product-fieldset-content">
                                    <div class="row">
                                        <div class="col-md-12">

                                            <?=
                                            $form->field(
                                                $model, 'is_auction'
                                            )->dropDownList(
                                                [
                                                1 => 'Аукцион',
                                                0 => 'Купить сейчас',
                                                ],
                                                [
                                                'id' => 'auction',
                                                ]
                                            )
                                            ?>
                                        </div>
                                    </div>


                                    <div class="row">
                                        <div class="col-md-12">
                                            <?=
                                            $form->field(
                                                $model, 'time_stop',
                                                ['horizontalCssClasses' => ['wrapper' => 'col-md-2']]
                                            )->dropDownList(
                                                [
                                                259200 => '3 дня',
                                                604800 => '7 Дней',
                                                1209600 => '14 Дней',
                                                1814400 => '21 День',
                                                ], ['class' => 'form-control']
                                            )
                                            ?>
                                        </div>
                                    </div>
                                    <?=
                                    $form->field($model, 'is_multilot')->checkbox()
                                    ?>

                                    <?=
                                    $form->field($model, 'quality')->textInput()
                                    ?>
                                </div>
                            </fieldset>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <fieldset>
                                <legend>
                                    Оплата и доставка
                                </legend>
                                <div class="admin-product-fieldset-content">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <?=
                                            $form->field($model, 'is_prepay',
                                                ['inline' => true])->radioList(
                                                [1 => 'Требуется', 0 => 'Не требуется']
                                            )
                                            ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="control-label col-md-3 col-lg-2">
                                                    Способы оплаты
                                                </label>
                                                <div class="col-md-8 col-lg-9 checkbox">
                                                    <?=
                                                    Html::checkboxList(
                                                        'paymentProduct',
                                                        ArrayHelper::map($model->feedPaymentTypes,
                                                            'payment_method_id',
                                                            'payment_method_id'),
                                                        PayMethod::getLabels(),
                                                        ['itemOptions' => ['labelOptions' => ['class' => 'padding-right-35']]]
                                                    )
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <?=
                                            $form->field(
                                                $model, 'is_deliverypay',
                                                [
                                                'inline' => true,
                                                ]
                                            )->radioList(
                                                [0 => 'Покупатель', 1 => 'Продавец']
                                            )
                                            ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label class="control-label col-md-3 col-lg-2">
                                                    Способы доставки
                                                </label>
                                                <div class="col-md-8 col-lg-9 checkbox">
                                                    <?=
                                                    Html::checkboxList(
                                                        'deliveryProduct',
                                                        ArrayHelper::map($model->feedDeliveryTypes,
                                                            'delivery_type_id',
                                                            'delivery_type_id'),
                                                        DeliveryType::getLabels(),
                                                        ['itemOptions' => ['labelOptions' => ['class' => 'padding-right-35']]]
                                                    )
                                                    ?>
                                                    <div class="help-block help-block-error "></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <label class="control-label col-md-3 col-lg-2">
                                            Местоположение
                                        </label>
                                        <div class="col-md-9 col-lg-9">
                                            <?=
                                            RegionFormWidget::widget(
                                                [
                                                    'model' => $model,
                                                    'form' => $form,
                                                    'inline' => true,
                                                ]
                                            )
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </fieldset>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="form-group">
        <?=
        Html::submitButton('Сохранить',
            ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary'])
        ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>

<?php
$js = <<<JS
    $("#feedsettings-category_id").change(function(){
    categori_id = $(this).val();
    $.ajax('/feed-settings/get-properties/' + categori_id + '/',
            {
                type: "POST",
                dataType:'html',
                success: function(data){
                    $('#pj_feed-property').html(data);
                }
            }
        );
    });
JS;
$this->registerJs($js);



