<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title                   = 'Feed Settings';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="feed-settings-index">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?=
        Html::a('Create Feed Settings', ['create'],
            ['class' => 'btn btn-success'])
        ?>
    </p>
    <?php Pjax::begin(); ?>    <?=
    GridView::widget([
        'dataProvider' => $dataProvider,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            'id',
            'title',
            'url:url',
            'is_active',
            'user.username',
            // 'description:ntext',
            // 'category_id',
            // 'is_multilot',
            // 'quality',
            // 'region_id',
            // 'city',
            // 'num_public',
            // 'is_auction',
            // 'time_start:datetime',
            // 'time_stop:datetime',
            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]);
    ?>
<?php Pjax::end(); ?>
</div>
