<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
use common\models\auktaModels\enumModels\StateProduct;

/* @var $this yii\web\View */
/* @var $model common\models\FeedSettings */

$this->title                   = $model->title;
$this->params['breadcrumbs'][] = ['label' => 'Feed Settings', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="feed-settings-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?=
        Html::a('Настройка', ['update', 'id' => $model->id],
            ['class' => 'btn btn-primary'])
        ?>
        <?=
        Html::a('Удалить', ['delete', 'id' => $model->id],
            [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Вы уверены, что хотите удалить Feed '.$model->title.'?',
                'method' => 'post',
            ],
        ])
        ?>
        <?=
        Html::a('Запустить', ['run-feed', 'id' => $model->id],
            [
            'class' => 'btn btn-success',
        ])
        ?>
    </p>
    <?php Pjax::begin(); ?>    <?=
    GridView::widget([
        'dataProvider' => $dataProvider,
        'columns' => [

            'key_feed',
            'keyAukta.name',
            'keyAukta.time_start:datetime',
            'keyAukta.time_end:datetime',
            [
                'attribute' => 'keyAukta.state_id',
                'content' => function($model) {
                    return StateProduct::getNameByValue($model->keyAukta->state_id);
                }
            ],
            'created_at:datetime',
            'updated_at:datetime',
            'action',
            [
                'class' => 'yii\grid\ActionColumn',
                'template' => '{view}',
                'urlCreator' => function ($action, $model) {
                    return Yii::$app->params['homeURL'].'products/view/'.$model->key_aukta.'/';
                }
            ],
        ],
    ]);
    ?>
    <?php Pjax::end(); ?>


</div>
