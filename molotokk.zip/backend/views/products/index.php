<?php

use yii\helpers\Html;
use yii\grid\GridView;
use common\models\auktaModels\enumModels\StateProduct;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title                   = 'Товары';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="products-index">




  <p>
    <?= Html::a('Все', ['index'], ['class' => 'btn btn-success']) ?>
    <?= Html::a('На модерации', ['products/products/' . StateProduct::STATE_ON_MODERATE], ['class' => 'btn btn-success']) ?>
    <?= Html::a('В продаже', ['products/products/' . StateProduct::STATE_ON_SALE], ['class' => 'btn btn-success']) ?>
  </p>

  <?=
  GridView::widget([
      'dataProvider' => $dataProvider,
      'columns'      => [
          [
              'class' => 'yii\grid\SerialColumn'
          ],
          [
              'attribute' => 'name',
          ],
          'description:ntext',
          [
              'label'     => Yii::t('products', 'Category'),
              'attribute' => 'category.name',
          ],
          'created_at:datetime',
          'updated_at:datetime',
          [
              'attribute' => 'state_id',
              'content'   => function ($model, $key, $index, $column) {
                    return StateProduct::getLabel($model->state_id);
              },
          ],
          [
              'class'   => 'yii\grid\ActionColumn',
              'buttons' => [
                  'confirm' => function ($url, $model, $key) {
                        return $model->state_id == StateProduct::STATE_ON_MODERATE ?
                                Html::a('Одобрить', $url) : '';
                  },
                  'decline' => function ($url, $model, $key) {
                        return $model->state_id == StateProduct::STATE_ON_MODERATE ?
                                Html::a('Отклонить', $url) : '';
                  },
              ],
              'template'                     => '{view} {confirm} {decline}'
          ],
      ],
  ]);
  ?>

