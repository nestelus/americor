<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\bootstrap\Modal;
use yii\helpers\Url;
use common\models\auktaModels\ReferenceType;
use yii\widgets\Pjax;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Списки';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="reference-type-index">
    <div class="col-md-3">
        <h1><?= Html::encode($this->title) ?></h1>

        <p>
            <?php
            Modal::begin([
                'header'       => 'Новый список',
                'options'      => [
                    'id' => 'modal_new-list'
                ],
                'toggleButton' => [
                    'label' => 'Добавить список',
                    'tag'   => 'button',
                    'class' => 'btn btn-primary',
                ],
            ]);
            $model = new ReferenceType();
            ?>
            <?=
            $this->render('_form', [
                'model' => $model,
            ])
            ?>



            <?php Modal::end() ?>

        </p>

        <?=
        GridView::widget([
            'dataProvider' => $dataProvider,
            'columns'      => [
                [
                    'label'   => 'Название списка',
                    'content' => function($model) {
                        return Html::a(
                                        $model->name, Url::to(['/reference/view-list', 'id' => $model->id]), ['class' => 'pj_ref-view-list']);
                    }
                        ],
                        [
                            'class'         => 'yii\grid\ActionColumn',
                            'template'      => '{update} {delete}',
                            'buttonOptions' => [
                                'class'     => 'pj_ref-view-list',
                                'data-pjax' => 1,
                            ],
                        ],
                    ],
                ]);
                ?>
            </div>
            <div class="col-md-9">
                <?php
                Pjax::begin([
                    'options'            => [
                        'id' => 'pj_ref-list_value',
                    ],
                    'linkSelector'       => '.pj_ref-view-list',
                    'formSelector'       => '.pj_reference-list',
                    'enablePushState'    => false,
                    'enableReplaceState' => false,
                ])
                ?>

                <?php Pjax::end() ?>
    </div>
</div>
