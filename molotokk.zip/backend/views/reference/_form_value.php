<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model common\models\auktaModels\ReferenceType */
/* @var $form yii\widgets\ActiveForm */

$this->title = 'Новое значения списка ' . $reference_type->name;
?>
<div class="reference-type-form">
    <h1><?= Html::encode($this->title) ?></h1>

    <?php
    $form = ActiveForm::begin([
                'action'  => $model->isNewRecord ? Url::to('/reference/add-value/') : Url::to(['/reference/update-value/', 'id' => $model->id]),
                'options' => [
                    'class' => 'pj_reference-list',
                ],
    ]);
    ?>

    <?= $form->field($model, 'reference_type_id')->hiddenInput(['value' => $reference_type->id])->label(false) ?>
    <?= $form->field($model, 'value')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Добавить' : 'Изменить', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
