<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model common\models\auktaModels\ReferenceType */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="reference-type-form">
    <h1><?= $model->isNewRecord ? 'Новый список' : 'Редактирование списка ' . $model->name ?> </h1>
    <?php
    $form = ActiveForm::begin([
                'action'  => $model->isNewRecord ? Url::to(['/reference/create/']) : Url::to(['/reference/update/', 'id' => $model->id]),
                'options' => [
                    'class' => 'pj_reference-list',
                ],
    ]);
    ?>


    <?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>

    <div class="form-group">
        <?= Html::submitButton($model->isNewRecord ? 'Добавить' : 'Сохранить', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
