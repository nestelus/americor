<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Значения списка ' . $reference_type->name;
?>
<div class="reference-type-list">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Добавить значение', Url::to(['/reference/add-value/', 'id' => $reference_type->id]), ['class' => 'btn btn-primary  pj_ref-view-list']) ?>


    </p>

    <?=
    GridView::widget([
        'dataProvider' => $dataProvider,
        'columns'      => [
            'value',
            [
                'class'         => 'yii\grid\ActionColumn',
                'template'      => '{update} {delete}',
                'buttonOptions' => [
                    'class'     => 'pj_ref-view-list',
                    'data-pjax' => 1,
                ],
                'urlCreator'    => function($action, $model) {
            return Url::to(['/reference/' . $action . '-value/', 'id' => $model->id]);
        }
            ],
        ],
            ]
    );
    ?>
</div>


