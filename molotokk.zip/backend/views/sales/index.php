<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;

/* @var $this yii\web\View */
/* @var $searchModel common\models\auktaModels\search\Sales */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title                   = 'Продажи';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="sales-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <?php // echo $this->render('_search', ['model' => $searchModel]);  ?>


    <?php Pjax::begin(); ?>    <?=
    GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],
            [
                'label' => 'Название лота',
                'attribute' => 'product_id',
                'content' => function ($model) {
                    return $model->product->name;
                },
                'enableSorting' => true,
            ],
            'amount',
            'quality',
            [
                'label' => 'Продавец',
                'attribute' => 'seller_id',
                'content' => function ($model) {
                    return $model->seller->username;
                },
                'enableSorting' => true,
            ],
            [
                'label' => 'Покупатель',
                'attribute' => 'buyer_id',
                'content' => function ($model) {
                    return $model->buyer->username;
                },
                'enableSorting' => true,
            ],
            // 'phone',
            // 'region_id',
            // 'city',
            // 'zip',
            // 'address:ntext',
            'created_at:datetime',
            // 'updated_at',
            // 'description:ntext',
            [
                'class' => 'yii\grid\ActionColumn',
                'template' => '{view} {delete}'
            ],
        ],
    ]);
    ?>
    <?php Pjax::end(); ?></div>
