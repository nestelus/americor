<?php

use yii\helpers\Html;
use yii\data\ActiveDataProvider;

/* @var $this yii\web\View */
/* @var $model common\models\auktaModels\Country */

$this->title                   = $model->name;
$this->params['breadcrumbs'][] = ['label' => 'Страны', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="country-view">

  <h1><?= Html::encode($this->title) ?></h1>

  <p>
    <?= Html::a('Редактировать', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
    <?=
    Html::a('Удалить', ['delete', 'id' => $model->id],
        [
        'class' => 'btn btn-danger',
        'data' => [
            'confirm' => 'Вы уверены?',
            'method' => 'post',
        ],
    ])
    ?>
  </p>

  <div class="row">
    <div class="col-md-6">
      <?php
      $dataProvider                  = new ActiveDataProvider([
          'query' => $model->getRegions(),
      ]);

     echo $this->render('regions', [
              'dataProvider' => $dataProvider,
      ]);
      ?>
    </div>
    <div class="col-md-6">
 <?php
      $dataProvider                  = new ActiveDataProvider([
          'query' => $model->getCities(),
      ]);

     echo $this->render('cities', [
              'dataProvider' => $dataProvider,
      ]);
      ?>
    </div>
  </div>

</div>
