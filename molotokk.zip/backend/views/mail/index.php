<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use yii\helpers\Html;
use yii\helpers\Url;

foreach ($mailTypes as $name => $mailMessage) :
    ?>
    <div class="row">
        <div class ="col-lg-3">
            <?= $name ?>
        </div>
        <div class ="col-lg-5">
            <?=
            Html::a('Пример',
                Url::to(['mail/render-mail', 'id' => $mailMessage->type]))
            ?>
        </div>
    </div>
    <div class="row">
        <div class ="col-lg-2 col-lg-offset-1">
            Тема письма:
        </div>
        <div class ="col-lg-5">
            <?= $mailMessage->subject ?>
        </div>
    </div>
    <div class="row">
        <div class ="col-lg-2 col-lg-offset-1">
            Шаблон:
        </div>
        <div class ="col-lg-5">
            <?= $mailMessage->template ?>
        </div>
    </div>
    <div class="row">
        <div class ="col-lg-2 col-lg-offset-1">
            От кого:
        </div>
        <div class ="col-lg-5">
            <?php print_r($mailMessage->from) ?>
        </div>
    </div>
    <div class="row">
        <div class ="col-lg-2 col-lg-offset-1">
            Кому:
        </div>
        <div class ="col-lg-5">
            <?= $mailMessage->to ?>
        </div>
    </div>
    <hr/>

<?php endforeach; ?>
