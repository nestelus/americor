<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\auktaModels\Articles */

$this->title                   = $model->title;
$this->params['breadcrumbs'][] = ['label' => 'Articles', 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="articles-view">

  <h1><?= Html::encode($this->title) ?></h1>

  <p>
    <?= Html::a('Редактировать', ['update', 'id' => $model->id],
        ['class' => 'btn btn-primary'])
    ?>
    <?=
    Html::a('Удалить', ['delete', 'id' => $model->id],
        [
        'class' => 'btn btn-danger',
        'data' => [
            'confirm' => 'Are you sure you want to delete this item?',
            'method' => 'post',
        ],
    ])
    ?>
  </p>
  <div>
    <?= $model->body ?>
  </div>


</div>
