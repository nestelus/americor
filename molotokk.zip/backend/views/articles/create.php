<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model common\models\auktaModels\Articles */
/* @var $type int */

$this->title = 'Создать';
?>
<div class="articles-create">

  <h1><?= Html::encode($this->title) ?></h1>

  <?=
  $this->render('_form', [
      'model' => $model,
      'type' => $type,
  ])
  ?>

</div>
