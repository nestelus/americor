<?php

use yii\bootstrap\Nav;
use common\models\auktaModels\enumModels\ArticleTypes;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */
/* @var $types array */
/* @var $type int */
/* @var $view string */

$types = ArticleTypes::getLabels();
$items = [];
foreach ($types as $key => $value)
{
    $items[] = [
        'label' => $value,
        'url'   => ['index', 'type' => $key],
    ];
}
?>
<div class="articles-index">



    <?php
    echo Nav::widget([
        'options' => [
            'class' => 'nav nav-tabs',
        ],
        'items'   => $items,
    ]);
    ?>
    <?=
    $this->render('index-type', [

        'model' => $model,
        'type'  => $type,
        'view'  => $view,
    ])
    ?>

</div>
