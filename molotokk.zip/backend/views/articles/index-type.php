<?php

use yii\helpers\Html;
use common\models\auktaModels\enumModels\ArticleTypes;
use common\models\auktaModels\Articles;
use execut\widget\TreeView;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */
/* @var $type int */

$this->title = ArticleTypes::getLabel($type);
$this->params['breadcrumbs'][] = $this->title;

$items = Articles::treeItems($type);
?>
<div class="articles-index">

    <h1><?= Html::encode($this->title) ?></h1>
    <div class="row">
        <div  class="col-md-3">
            <div class="panel-group">
                <?=
                Html::a('Добавить ' . $this->title, ['create', 'type' => $type, 'parent_id' => $model ? $model->id : null], [
                    'class' => 'btn btn-success'
                ])
                ?>
                <p>
                    <?php if (!empty($items)): ?>
                        <?=
                        TreeView::widget([
                            'id'               => 'js_tree-help',
                            'data'             => $items,
                            'size'             => TreeView::SIZE_SMALL,
                            'template'         => TreeView::TEMPLATE_SIMPLE,
                            'containerOptions' => [
                                'class' => 'pj_canvas',
                            ],
                            /* 'searchOptions' => [
                              'inputOptions' => [
                              'placeholder' => 'Search category...'
                              ],
                              ], */
                            'clientOptions'    => [
                                //'onNodeSelected' => $onSelect,
                                //'onNodeUnselected' => $unSelect,
                                'selectedBackColor' => 'rgb(40, 153, 57)',
                                'showBorder'        => false,
                                'enableLinks'       => true,
                            ],
                        ]);
                        ?>
                    <?php endif ?>

                </p>
            </div>
        </div>
        <div class="col-md-9" id="article">


            <?php if ($model): ?>
                <?=
                $this->render($view, [
                    'type'  => $type,
                    'model' => $model,
                ]);
                ?>
            <?php endif; ?>

        </div>
    </div>

</div>
