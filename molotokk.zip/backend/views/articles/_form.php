<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\helpers\ArrayHelper;
use common\models\auktaModels\Articles;
use mihaildev\ckeditor\CKEditor;
use mihaildev\elfinder\ElFinder;

/* @var $this yii\web\View */
/* @var $model common\models\auktaModels\Articles */
/* @var $form yii\widgets\ActiveForm */
$parent = ArrayHelper::map(Articles::find()->where(['type' => $type])->orderBy('position')->all(), 'id', 'title', 'parent.title');
?>

<div class="articles-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'type')->hiddenInput()->label(FALSE) ?>

    <?= $form->field($model, 'title')->textInput(['maxlength' => true]) ?>

    <?=
    $form->field($model, 'parent_id')->dropDownList($parent, [
        'prompt' => 'Нет родительской',
    ])
    ?>

    <?=
    $form->field($model, 'body')->widget(CKEditor::className(), [

        'editorOptions' => ElFinder::ckeditorOptions('elfinder', ['baseUrl' => \Yii::$app->urlManager->baseUrl], [
            'language' => 'ru',
            //'filebrowserBrowseUrl' => '/trest',
            'preset'   => 'standart', //разработанны стандартные настройки basic, standard, full данную возможность не обязательно использовать
            'inline'   => false, //по умолчанию false])
        ]),
    ]);
    ?>


    <div class="form-group">
        <?=
        Html::submitButton($model->isNewRecord ? 'Создать' : 'Сохранить', ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary'])
        ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
