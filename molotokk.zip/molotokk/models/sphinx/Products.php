<?php

namespace molotokk\models\sphinx;

use yii\sphinx\Query;
use common\models\auktaModels\CategoryProperties;
use common\models\auktaModels\enumModels\PropertyType;

/**
 * This is the model class for index "idx_products".
 *
 * @property integer $id
 * @property string $name
 * @property string $description
 * @property string $parent_name
 * @property string $price_stop
 * @property string $tag
 * @property string $property
 * @property integer $user_id
 * @property integer $category_id
 * @property integer $parent_id
 * @property integer $state_id
 * @property double $price
 * @property boolean $is_multilot
 * @property integer $quality
 * @property integer $buyer_id
 * @property boolean $is_auction
 * @property string $time_start
 * @property string $time_stop
 * @property integer $conditional
 * @property string $complete_at
 * @property string $created_at
 * @property string $updated_at
 */
class Products extends \yii\sphinx\ActiveRecord {

    /**
     * @inheritdoc
     */
    public static function indexName() {
        if (YII_ENV == 'prod')
        {
            return 'idx_products';
        }

        return 'idx_products_dev';
    }

    /**
     * @inheritdoc
     */
    public function rules() {
        return [
            [['id'], 'required'],
            [['id'], 'unique'],
            [['id', 'user_id', 'category_id', 'parent_id', 'state_id', 'quality', 'buyer_id', 'conditional', 'region_id'], 'integer'],
            [['name', 'description', 'parent_name', 'price_stop', 'tag', 'property'], 'string'],
            [['price'], 'number'],
            [['is_multilot', 'is_auction'], 'boolean'],
            [['time_start', 'time_stop', 'time_end', 'complete_at', 'created_at', 'updated_at', 'referrence_id'], 'safe']
        ];
    }

    /**
     * @inheritdoc
     */
    public function attributeLabels() {
        return [
            'id'          => 'ID',
            'name'        => 'Name',
            'description' => 'Description',
            'parent_name' => 'Parent Name',
            'price_stop'  => 'Price Stop',
            'tag'         => 'Tag',
            'property'    => 'Property',
            'user_id'     => 'User ID',
            'category_id' => 'Category ID',
            'parent_id'   => 'Parent ID',
            'state_id'    => 'State ID',
            'price'       => 'Price',
            'is_multilot' => 'Is Multilot',
            'quality'     => 'Quality',
            'buyer_id'    => 'Buyer ID',
            'is_auction'  => 'Is Auction',
            'region_id'   => 'Region',
            'time_start'  => 'Time Start',
            'time_stop'   => 'Time Stop',
            'time_end'    => 'Time end',
            'conditional' => 'Conditional',
            'complete_at' => 'Complete At',
            'created_at'  => 'Created At',
            'updated_at'  => 'Updated At',
        ];
    }

    public static function createQuery($get) {
        $query = new Query();
        $query->from('idx_products');

        if ($get['searchCategory'])
        {
            $query->andWhere(['parent_id' => $get['searchCategory']]);
        }
        if (isset($get['subCategory']) && $get['subCategory'])
        {
            $query->andWhere(['category_id' => $get['subCategory']]);
        }
        if (isset($get['region_id']) && !empty($get['region_id']))
        {
            $query->andWhere(['region_id' => $get['region_id']]);
        }
        if (isset($get['price_min']) && !empty($get['price_min']))
        {
            $query->andWhere(['>=', 'price', (int) $get['price_min']]);
        }
        if (isset($get['price_max']) && !empty(($get['price_max'])))
        {
            $query->andWhere(['<=', 'price', (int) $get['price_max']]);
        }
        if (isset($get['start_of']) && !empty($get['start_of']))
        {
            $query->andWhere(['>=', 'time_start', time() - $get['start_of']]);
        }
        if (isset($get['stop_of']) && !empty($get['stop_of']))
        {
            $query->andWhere(['<=', 'time_end', time() - $get['stop_of']]);
        }
        if (!empty($get['properties']))
        {
            // var_dump($get['properties']);
            // die();

            foreach ($get['properties'] as $property_id => $value)
            {
                if (!empty($value))
                {
                    $property = CategoryProperties::findOne($property_id);
                    switch ($property->type_id)
                    {
                        case PropertyType::TYPE_LIST:
                            $query->andWhere(['referrence_id' => $value]);
                            break;
                        case PropertyType::TYPE_INT:
                            if (isset($value['min']) && !empty($value['min']))
                            {
                                $query->andWhere($condition);
                            }
                    }
                }
            }
        }

        return $query;
    }

}
