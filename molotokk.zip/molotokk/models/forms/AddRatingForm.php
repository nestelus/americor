<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace molotokk\models\forms;

use yii\base\Model;

/**
 * Description of AddRatingForm
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class AddRatingForm extends Model
{
      public $products = [];
      public $Ratings  = [];

      public function init()
      {

      }

      public function formName()
      {
            return 'add-ratings';
      }

      public function rules()
      {
            return [
            ];
      }
}