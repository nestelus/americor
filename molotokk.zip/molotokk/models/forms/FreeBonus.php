<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace molotokk\models\forms;

use yii\base\Model;

/**
 * Description of FreeBonus
 *
 * @author Vladimir
 */
class FreeBonus extends Model {

    public $nic;
    public $num_lots;
    public $comment;

    public function formName() {
        return 'free-bonus';
    }

    public function rules() {
        return [
            [['nic', 'num_lots'], 'required'],
        ];
    }

}
