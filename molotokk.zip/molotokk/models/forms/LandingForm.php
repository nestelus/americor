<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace molotokk\models\forms;

use Yii;
use yii\base\Model;
use common\models\User;

/**
 * Description of LandingForm
 *
 * @author Vladimir
 */
class LandingForm extends Model {

    const SCENARIO_BONUS_SYSTEM = 'bonus-system';
    const SCENARIO_FREE_DELIVERY = 'free-delivery';
    const SCENARIO_IMPORT = 'import';

    public $name;
    public $num_lots;
    public $comment;
    public $phone;
    public $direction;
    public $bonuses;

    public function scenarios() {
        return [
            self::SCENARIO_BONUS_SYSTEM  => ['comment', 'name', 'bonuses', 'num_lots'],
            self::SCENARIO_FREE_DELIVERY => ['comment', 'name', 'phone', 'num_lots', 'direction'],
            self::SCENARIO_IMPORT        => ['comment', 'name'],
        ];
    }

    public function rules() {
        return [
            [['name', 'comment'], 'string'],
            [['direction', 'num_lots'], 'required', 'on' => self::SCENARIO_FREE_DELIVERY],
            [ 'place', 'string'],
            ['bonuses', 'required', 'on' => self::SCENARIO_BONUS_SYSTEM],
        ];
    }

    public function attributeLabels() {
        return [
            'name'      => 'Ваше имя',
            'comment'   => 'Комментарии',
            'num_lots'  => 'Лоты',
            'phone'     => 'Ваш телефон',
            'direction' => 'Направление доставки',
            'bonuses'   => 'Бонус',
        ];
    }

    public function sendEmail($user_id) {
        $user = User::findOne($user_id);
        switch ($this->scenario)
        {
            case self::SCENARIO_BONUS_SYSTEM:
                $from = 'Заявка на Бонус №' . $this->bonuses;
                $body = 'Пользователь ' . $user->username . '<br>'
                        . 'ID: ' . $user->id . '<br>'
                        . 'e-mail: ' . $user->email . '<br><br>'
                        . 'Имя: ' . $this->name . '<br>'
                        . 'Бонус №: ' . $this->bonuses . '<br>'
                        . 'Лот №: ' . $this->num_lots . '<br>'
                        . 'Комментарии:<br>' . $this->comment;
                break;
            case self::SCENARIO_FREE_DELIVERY;
                $from = 'Заявка на доставку';
                $lots = 'Лоты: <br>';

                foreach ($this->num_lots as $lot)
                {
                    $lots .= 'Лот №' . $lot . '<br>';
                }
                $body = 'Пользователь ' . $user->username . '<br>'
                        . 'ID: ' . $user->id . '<br>'
                        . 'e-mail: ' . $user->email . '<br><br>'
                        . 'Имя: ' . $this->name . '<br>'
                        . 'Телефон:' . $this->phone . '<br>'
                        . 'Направление доставки: ' . $this->direction . '<br>'
                        . $lots
                        . 'Комментарии: <br>' . $this->comment;
                break;
            case self::SCENARIO_IMPORT:
                $from = 'Заявка на импорт';
                $body = 'Пользователь ' . $user->username . '<br>'
                        . 'ID: ' . $user->id . '<br>'
                        . 'e-mail: ' . $user->email . '<br><br>'
                        . 'Имя: ' . $this->name . '<br>'
                        . 'Комментарии: <br>' . $this->comment;
                break;
        }
        return Yii::$app->mailer->compose()
                        ->setTo(Yii::$app->params['supportEmail'])
                        ->setFrom(Yii::$app->params['noreplyEmail'])
                        ->setReplyTo([$user->email => $user->username])
                        ->setSubject($from)
                        ->setHtmlBody($body)
                        ->send();
    }

}
