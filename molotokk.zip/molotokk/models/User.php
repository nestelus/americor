<?php

namespace molotokk\models;

use common\models\User as commonUser;

/**
 * Override  of User
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class User extends commonUser {

      public function rules() {
            $rules = parent::rules();
            // let's add some rules for field
            // suppose, it is required and have max length with 10 symbols:


            return $rules;
      }

}
