<?php

namespace molotokk\models;

use common\models\auktaModels\CategoryProperties as CommonCategoryProperties;

/**
 * Description of CategoryProperties
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class CategoryProperties extends CommonCategoryProperties {

}
