<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace molotokk\models;

use common\models\auktaModels\ProductPhotos as CommonProductPhotos;

/**
 * Description of ProductPhotos
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class ProductPhotos extends CommonProductPhotos {
  //put your code here
}
