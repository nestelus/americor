<?php

namespace molotokk\models;

use common\models\auktaModels\Products as commonProduct;
use Yii;
use common\models\auktaModels\enumModels\StateProduct;

/**
 * Description of Products
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class Products extends commonProduct
{

    public $subcat;

    public static function myProducts()
    {
        $user_id = Yii::$app->getUser()->id;

        return self::findAll(['user_id' => $user_id]);
    }

    public static function myConfirmProducts()
    {
        return Products::findAll(
            [
                'user_id' => Yii::$app->getUser()->id,
                'state_id' => StateProduct::STATE_ON_SALE,
            ]
        );
    }

    public function init()
    {
        parent::init();
        $this->subcat = $this->category_id ? $this->category->parent->id : null;
    }

    public function getFullRegion()
    {
        $region = 'Не указано';
        if (!empty($this->region)) {
            if (!empty($this->city)) {
                $region = $this->region->name == $this->city ? $this->region->name : $this->region->name . ', ' . $this->city;
            } else {
                $region = $this->region->name;
            }
        }
        return $region;
    }

}
