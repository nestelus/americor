<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace molotokk\models;

use common\models\auktaModels\ProductProperties as CommonProductPropertyes;
use Yii;

/**
 * Description of ProductProperty
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class ProductProperties extends CommonProductPropertyes {

}
