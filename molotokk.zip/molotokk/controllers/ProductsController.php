<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace molotokk\controllers;

use molotokk\models\Profile;
use Yii;
use common\controllers\AuktaController;
use molotokk\models\AuctionStakes;
use common\models\auktaModels\Tags;
use molotokk\models\Products;
use common\models\auktaModels\enumModels\StateProduct;
use common\models\auktaModels\Categories;
use common\models\auktaModels\DeliveryAddresses;
use yii\web\Response;
use molotokk\models\Sales;
use common\models\User;
use common\components\searchFilter\searchFilter;
use yii\web\NotFoundHttpException;
use yii\helpers\Url;
use common\models\MailMessages;
use common\models\auktaModels\enumModels\MailType;

/**
 * Description of ProductsController
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class ProductsController extends AuktaController
{
    public $modelClass = 'molotokk\models\Products';

    /**
     *
     * карточка товара
     */
    public function actionView($id, $slug = null)
    {
        //die($slug);
        if (!is_null($slug)) {
            $model = Products::findOne(
                    [
                        'id' => $id,
                        'slug' => $slug,
                    ]
            );
            // return $this->redirect($model->getUrl());
        } else {
            $model = Products::findOne($id);
            if (!empty($model->slug)) {
                return $this->redirect($model->getUrl());
            }
        }
        if (empty($model)) {
            throw new NotFoundHttpException('Такой страницы не существует');
        }
        $model->endAuction();

        if (in_array(
                $model->state_id,
                [
                StateProduct::STATE_ON_CREATE,
                StateProduct::STATE_ON_MODERATE,
                StateProduct::STATE_ON_ARHIVE,
                ]
            )) {
            $this->canAccess($model->user_id);
        }
        $model->updateAttributes(
            [
                'count_views' => $model->count_views + 1,
            ]
        );
        $user       = $model->user;
        $properties = $model->productProperties;
        $photos     = $model->getProductPhotos()->orderBy('order')->all();

        return $this->render(
                'view',
                [
                'model' => $model,
                'properties' => $properties,
                'photos' => $photos,
                'user' => $user,
                ]
        );
    }

    /**
     * Покупка товара
     *
     * @param int $id // id товара
     * @return type
     */
    public function actionBuy($id)
    {
        $product = Products::findOne($id);
        if (Yii::$app->user->isGuest) {
            $url = $product->getUrl();
            Yii::$app->getUser()->setReturnUrl($url);

            return $this->redirect(Url::to(['/user/security/login']));
        }
        $user    = User::findOne(Yii::$app->user->id);
        $profile = $user->profile;


        $post = Yii::$app->request->post();

        /* @var $sales Sales */
        $sales = new Sales();
        if ($sales->load($post)) {
            $sales->buyer_id    = $user->id;
            $sales->product_id  = $id;
            $sales->seller_id   = $product->user_id;
            $sales->amount      = $product->price;
            $sales->description = $post['description'];


            $delivery_addresses = DeliveryAddresses::findOne($post['delivery_address']);
            if ($delivery_addresses) {
                $sales->region_id = $delivery_addresses->region_id;
                $sales->phone     = $delivery_addresses->phone;
                $sales->city      = $delivery_addresses->city;
                $sales->zip       = $delivery_addresses->zip;
                $sales->address   = $delivery_addresses->address;
                $sales->fio       = $delivery_addresses->fio;
            } else {
                $sales->region_id = $profile->region_id;
                $sales->phone     = $profile->phone;
                $sales->city      = $profile->city;
                $sales->zip       = $profile->zip;
                $sales->address   = $profile->address;
                $sales->fio       = $profile->first_name.' '.$profile->last_name;
            }
            if (Yii::$app->request->isAjax) {
                Yii::$app->response->format = Response::FORMAT_JSON;
                $result                     = $sales->validate();
                if (empty($result)) {
                    return false;
                }

                return $result;
            }
            $sales->save();
            $id = $sales->onBuy();
        }
        $url = Products::findOne($id)->getUrl();

        return $this->redirect($url);
    }

    /**
     * Сделана ставка
     * @param int $id id товара
     * @return type
     */
    public function actionStake($id)
    {
        $product = Products::findOne($id);
        if (Yii::$app->user->isGuest) {
            $url = $product->getUrl();
            Yii::$app->getUser()->setReturnUrl($url);

            return $this->redirect(Url::to(['/user/security/login']));
        }
        $request = Yii::$app->request;
        if ($request->isPjax && $request->post()['stake']) {
            $stake = new AuctionStakes();

            $stake->load($request->post());
            $stake->user_id = Yii::$app->user->id;
            $current_stake  = $product->maxStake;
            $popup          = false;
            if ($stake->save()) {
                //Если сменился лидер отправляем письмо
                if ($current_stake && $current_stake->user_id != $stake->current_leader) {


                    $mail_ower = new MailMessages([
                        'type' => MailType::MAIL_LOT_OWER_BID,
                        'model' => $current_stake,
                    ]);
                    $mail_ower->send();
                    $stake     = new AuctionStakes();
                } elseif ($stake->user_id != $stake->current_leader) {
                    $popup = true;
                    // return $popup;
                }
            }

            return $this->renderAjax(
                    '_form_auction',
                    [
                    'product' => Products::findOne($id),
                    'stake' => $stake,
                    'popup' => $popup,
                    ]
            );
        }
        $url = Products::findOne($id)->getUrl();

        return $this->redirect($url);
    }

    /**
     * Отображение списка товаров по тегу
     * @param int $id // id тега
     * @return type
     */
    public function actionTag($id)
    {
        $tag          = Tags::findOne($id);
        $query        = $tag->getProducts();
        $searchFilter = new searchFilter(
            [
            'query' => $query,
            'action' => $this->action->id,
            'states' => [
                -1 => 'Все',
                StateProduct::STATE_ON_SALE => 'Купить сейчас',
                StateProduct::STATE_ON_AUCTION => 'Аукцион',
                StateProduct::STATE_ON_SOLD => 'Проданные',
            ],
            ]
        );

        $title = Yii::t(
                'products', 'Товары с тегом "{tagname}"',
                [
                'tagname' => $tag->name,
                ]
        );
        if (Yii::$app->request->isPjax) {
            return $this->renderAjax(
                    'products-list',
                    [
                    'searchFilter' => $searchFilter,
                    'title' => $title,
                    ]
            );
        } else {
            return $this->render(
                    'products-list',
                    [
                    'searchFilter' => $searchFilter,
                    'title' => $title,
                    ]
            );
        }
    }

    /**
     * Отображение списка категории
     * @param int $id //id категории
     * @return type
     */
    public function actionCategories($id)
    {
        $category     = Categories::findOne($id);
        $query        = Products::find()->where(['category_id' => $category->categoryWithChildren()]);
        $title        = Yii::t('products', 'Товары категории {category}',
                [
                'category' => $category->getCategoryPath(),
        ]);
        $searchFilter = new searchFilter(
            [
            'query' => $query,
            'action' => $this->action->id,
            'states' => [
                //  -1                             => 'Все',
                StateProduct::STATE_ON_SALE => 'Купить сейчас',
                StateProduct::STATE_ON_AUCTION => 'Аукцион',
            //  StateProduct::STATE_ON_SOLD    => 'Проданные'
            ],
            'params' => [
                searchFilter::VAR_SEARCH_PRICE,
                searchFilter::VAR_SEARCH_TIME_START,
                searchFilter::VAR_SEARCH_TIME_END,
                searchFilter::VAR_SEARCH_REGION,
            ],
            ]
        );
        if (Yii::$app->request->isPjax) {
            return $this->renderAjax(
                    'category',
                    [
                    'category' => $category,
                    'searchFilter' => $searchFilter,
                    'title' => $title,
                    ]
            );
        } else {
            return $this->render(
                    'category',
                    [
                    'category' => $category,
                    'searchFilter' => $searchFilter,
                    'title' => $title,
                    ]
            );
        }
    }

    public function actionFreshLots()
    {
        $query        = Products::find()
            ->orderBy(['time_start' => SORT_DESC])
            ->limit(100);
        $title        = 'Свежие лоты';
        $searchFilter = new searchFilter(
            [
            'query' => $query,
            'action' => $this->action->id,
            'states' => [
                -1 => 'Все',
                StateProduct::STATE_ON_SALE => 'Купить сейчас',
                StateProduct::STATE_ON_AUCTION => 'Аукцион',
            ],
            'arraySort' => false,
            'sort' => false,
            'params' => [
                searchFilter::VAR_SEARCH_PRICE,
                searchFilter::VAR_SEARCH_TIME_START,
                searchFilter::VAR_SEARCH_TIME_END,
                searchFilter::VAR_SEARCH_REGION,
            ],
            ]
        );
        if (Yii::$app->request->isPjax) {
            return $this->renderAjax(
                    'products-list',
                    [
                    'searchFilter' => $searchFilter,
                    'title' => $title,
                    ]
            );
        } else {
            return $this->render(
                    'products-list',
                    [
                    'searchFilter' => $searchFilter,
                    'title' => $title,
                    ]
            );
        }
    }

    /**
     * Принимает сигнал на обновление аукциона
     *
     * @param int $id //id товара
     * @return json
     */
    public function actionUpdateAuction($id)
    {

        if (Yii::$app->request->isAjax) {
            $product              = Products::findOne($id);
            $data['currentStake'] = number_format($product->price, 0, '.', ' ').'  '.Yii::$app->params['currency'];
            $data['numberStake']  = count($product->auctionStakes);
            $data['nextStakes']   = $product->getMyNextStake();
            if ($product->isStaker(Yii::$app->user->id)):
                if ($product->maxStake->user_id == Yii::$app->user->id):
                    $data['resultStakes'] = '<div class="col-md-12"><div class="stake-alert  stake-win">Ваша ставка наибольшая</div></div>';
                else:
                    $data['resultStakes'] = '<div class="col-md-12"><div class="stake-alert  stake-loos">Ваша ставка перебита</div> </div>';
                endif;
            else:
                $data['resultStakes'] = '';
            endif;

            $data['allStakes'] = $this->renderPartial(
                '_stakes',
                [
                'model' => $product,
                ]
            );

            return json_encode($data);
        }

        return false;
    }

    public function actionEndAuction($id)
    {
        if (Yii::$app->request->isAjax) {
            $product = Products::findOne($id);

            return $product->endAuction();
        }

        return false;
    }

    public function actionEndForse($id)
    {
        $product = Products::findOne($id);
        $product->endAuction(true);
        $url     = $product->getUrl();

        return $this->redirect($url);
    }

    public function actionLoadAddress()
    {
        if (Yii::$app->request->isAjax && $post = Yii::$app->request->post()) {
            $address                    = DeliveryAddresses::findOne($post['address_id']);
            Yii::$app->response->format = Response::FORMAT_JSON;

            return $address;
        }

        return false;
    }

    public function actionOneRouble()
    {
        $queryStakes = AuctionStakes::find()->select(
                [
                    'product_id',
                    'COUNT(id) AS stakes',
                ]
            )->groupBy(['product_id']);

        $query = Products::find()->where(
                [
                    'price_start' => 1,
                    'state_id' => StateProduct::STATE_ON_AUCTION,
                ]
            )
            ->select(['*'])
            ->leftJoin(['stak' => $queryStakes], 'id = stak.product_id');

        $title        = 'Аукционы от 1 рубля';
        $searchFilter = new searchFilter(
            [
            'query' => $query,
            'action' => $this->action->id,
            'params' => [
                searchFilter::VAR_SEARCH_PRICE,
                searchFilter::VAR_SEARCH_TIME_START,
                searchFilter::VAR_SEARCH_TIME_END,
                searchFilter::VAR_SEARCH_REGION,
            ],
            'arraySort' => [
                'stak.stakes DESC' => 'По популярности',
                'time_start DESC' => 'Сначала новые',
                'time_end ASC' => 'Скоро завершатся',
                'price ASC' => 'По цене - от меньшей к большей',
                'price DESC' => 'По цене - от большей к меньшей',
            ],
            'mode' => 'mini',
            ]
        );
        if (Yii::$app->request->isPjax) {
            return $this->renderAjax(
                    'products-list',
                    [
                    'searchFilter' => $searchFilter,
                    'title' => $title,
                    ]
            );
        } else {
            return $this->render(
                    'products-list',
                    [
                    'searchFilter' => $searchFilter,
                    'title' => $title,
                    ]
            );
        }
    }

    public function actionRemembePay($id)
    {
        $product = Products::findOne($id);
        $this->canAccess($product->user_id);
        if (Yii::$app->mailer->compose(
                    'lot-remembe-pay',
                    [
                    'lot' => $product,
                    ]
                )
                ->setTo($product->buyer->email)
                ->setFrom([Yii::$app->params['noreplyEmail'] => 'Интернет-аукцион "AUKTA"'])
                ->setSubject('Напоминание о покупке лота на Aukta.ru')
                ->send()
        ) {
            Yii::$app->session->addFlash(
                'sendRemembe', 'Ваше письмо успешно отправлено покупателю'
            );
        } else {
            Yii::$app->session->addFlash(
                'sendRemembe', 'Письмо отправить не удалось. Попробуйте позже.'
            );
        }

        return $this->redirect('/profile/view/'.$product->buyer_id.'/');
    }

    public function actionDeliveryAdressAdd()
    {
        $model = new DeliveryAddresses();
        $model->load(Yii::$app->request->post());

        $model->user_id = Yii::$app->user->id;

        $model->save();
        $profile = Profile::findOne($model->user_id);

        return $this->renderPartial(
                '@molotokk/widgets/views/_delivery_address',
                [
                'profile' => $profile,
                ]
        );
    }
}
