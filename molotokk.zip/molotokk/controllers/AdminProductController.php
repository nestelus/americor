<?php

namespace molotokk\controllers;

use Yii;
use common\controllers\AuktaController;
use molotokk\models\Products;
use molotokk\models\ProductPhotos;
use yii\web\UploadedFile;
use common\models\auktaModels\enumModels\StateProduct;
use common\models\auktaModels\Categories;
use common\models\auktaModels\enumModels\SaveLot;
use common\widgets\PropertyFieldWidget;
use molotokk\widgets\CategoryChangeWidget;
use yii\filters\VerbFilter;
use yii\helpers\Json;
use yii\helpers\Url;
use molotokk\widgets\UploadPhotoWidget;

/**
 * Description of ProductController
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class AdminProductController extends AuktaController
{
    public $modelClass = 'molotokk\models\Products';

    //public $layout     = 'product';

    public function behaviors()
    {
        return [
            'verbs' => [
                'class' => VerbFilter::className(),
                'actions' => [
                    'delete' => ['POST'],
                ],
            ],
        ];
    }

    public function beforeAction($action)
    {
        if (Yii::$app->user->isGuest) {
            $request = Yii::$app->getRequest();
            Yii::$app->getUser()->setReturnUrl($request->getUrl());

            return !($this->redirect('/user/security/login/'));
        }
        return parent::beforeAction($action);
    }
    /*
     * Создание лота
     */

    public function actionCreate()
    {
        $model          = new Products();
        $model->user_id = Yii::$app->user->id;
        $get            = Yii::$app->request->get();

        if (isset($get['category_id'])) {
            $model->category_id = $get['category_id'];
        }
        $model->save(false);
        return $this->redirect(Url::to(['admin-product/update', 'id' => $model->id]));
    }

    /**
     * Редактирование лота
     * @param type $id
     * @return type
     */
    public function actionUpdate($id)
    {
        $model = Products::findOne($id);

        $this->canAccess($model->user_id);
        if ($post = Yii::$app->request->post()) {

            $model->load($post);
            $model->save(false);

            if (isset($post['properties'])) {
                $model->updateProperties($post['properties']);
            }
            if (isset($post['deliveryProduct'])) {
                $model->updateDeliveryProduct($post['deliveryProduct']);
            }
            if (isset($post['paymentProduct'])) {
                $model->updatePaymentMethods($post['paymentProduct']);
            }


            if ($post['moderate']) {
                switch ($post['moderate']) {
                    case SaveLot::SAVE_LOT_NOW:
                        if ($model->moderateProduct()) {
                            return $this->redirect("/admin-product/moderate/$model->id/");
                        }
                        break;
                    case SaveLot::SAVE_LOT_DRAFT:

                        return $this->redirect("/admin-product/admin-view/$model->id/");
                }
            }
        }

        return $this->render('update',
                [
                'model' => $model,
                'properties' => $model->productProperties,
        ]);
    }

    public function actionCategoryExpand($id)
    {
        $model = Products::findOne($id);
        $this->canAccess($model->user_id);
        return CategoryChangeWidget::widget([
                'model' => $model,
                'change' => true,
        ]);
    }

    /** Смена категории * */
    public function actionChangeCategory()
    {

        if ($post = Yii::$app->request->post()) {
            $model = Products::findOne($post['id']);
            $this->canAccess($model->user_id);
            if ($model->category_id != $post['category_id']) {
                $model->category_id = $post['category_id'];
                $model->save(false);
                $model->refreshProperties();
            }
            $data['categories'] = CategoryChangeWidget::widget([
                    'model' => $model,
            ]);

            $data['properties'] = PropertyFieldWidget::widget([
                    'model' => $model,
                    'attribute' => 'productProperties',
                    'properties' => $model->getProductProperties()->all(),
            ]);
            return json_encode($data);
        }
        return false;
    }

    /**
     * Предпросмотр лота в ЛК
     * @param type $id
     * @return type
     */
    public function actionAdminView($id)
    {
        $this->layout = 'product';
        $model        = Products::findOne($id);

        $this->canAccess($model->user_id);

        $photos     = $model->getProductPhotos()->orderBy('order')->all();
        $properties = $model->productProperties;
        $deliveries = $model->deliveryTypes;
        $user       = $model->user;
        return $this->render('admin',
                [
                'model' => $model,
                'properties' => $properties,
                'photos' => $photos,
                'deliveries' => $deliveries,
                'user' => $user,
        ]);
    }

    /**
     * Удаление  лота
     * @param type $id
     */
    public function actionDelete($id)
    {
        $model = Products::findOne($id);
        $this->canAccess($model->user_id);

        $model->delete();

        $this->redirect('/profile/sales/draft/');
    }
    /*
     * Загрузка фото
     */

    public function actionUploadPhotos($id)
    {
        $model = Products::findOne($id);
        $this->canAccess($model->user_id);
        if (Yii::$app->request->isPost) {
            $model->uploadImages = UploadedFile::getInstances($model,
                    'uploadImages');
            $model->uploadPhoto();
        }
        return true;
    }

    /**
     * Вывод фото аяксом на страницу редактирования
     * @param type $id
     * @return boolean
     */
    public function actionRenderPhotos($id)
    {
        if (Yii::$app->request->isAjax) {
            $model = Products::findOne($id);
            $this->canAccess($model->user_id);

            return UploadPhotoWidget::widget(
                    [
                        'product' => $model,
                        'modal' => FALSE,
            ]);
        }
        return $this->redirect(Url::to(['admin-product/update', 'id' => $id]));
    }

    public function actionMainPhoto($id)
    {
        $photo = ProductPhotos::findOne($id);
        $photo->setMain();
        return true;
    }
    /*
     * Удаление фото
     */

    public function actionDeletePhoto($id)
    {
        if ($Photo = ProductPhotos::findOne($id)) {

            $product = $Photo->product;
            $this->canAccess($product->user_id);

            $Photo->delete();
        }

        return UploadPhotoWidget::widget(
                [
                    'product' => $product,
                    'modal' => FALSE,
        ]);
    }
    /*
     * Удаление всех фото
     */

    public function actionDeleteAllPhotos($id)
    {
        $product = Products::findOne($id);
        $this->canAccess($product->user_id);
        foreach ($product->productPhotos as $Photo) {
            if ($Photo->order != 1) {
                $Photo->delete();
            }
        }
        return UploadPhotoWidget::widget(
                [
                    'product' => $product,
                    'modal' => FALSE,
        ]);
    }
    /*
     * Отправка на модерацию (подтверждение)
     */

    public function actionModerate($id)
    {
        $model = Products::findOne($id);
        $this->canAccess($model->user_id);



        /** TODO ввести модерацию * */
        // $model->state_id = StateProduct::STATE_ON_MODERATE;

        $photos     = $model->getProductPhotos()->orderBy('order')->all();
        $properties = $model->productProperties;
        $deliveries = $model->deliveryTypes;
        $user       = $model->user;

        return $this->render('confirm',
                [
                'model' => $model,
                'properties' => $properties,
                'photos' => $photos,
                'deliveries' => $deliveries,
                'user' => $user,
        ]);
    }

    /**
     * Подтверждение
     * @param type $id
     * @return type
     */
    public function actionConfirm($id)
    {
        $model = Products::findOne($id);
        $this->canAccess($model->user_id);

        if (Yii::$app->request->post()['confirm']) {

            if ($model->publicProduct()) {
                return $this->redirect($model->getUrl());
            }
        }
        return $this->redirect(Url::to(['admin-product/admin-view', 'id' => $id]));
    }
    /*
     *  Возврат с модерации (не используется)
     */

    public function actionOutsale($id)
    {
        $model = Products::findOne($id);

        if ($model && ($model->state_id == StateProduct::STATE_ON_SALE or $model->state_id
            == StateProduct::STATE_ON_AUCTION)) {
            if ($model->state_id == StateProduct::STATE_ON_AUCTION && count($model->auctionStakes)
                > 0) {
                Yii::$app->session->setFlash('is_staked', 'Уже есть ставки');
            } else {
                $model->updateAttributes([
                    'state_id' => StateProduct::STATE_ON_HIDE,
                    'time_end' => null,
                    'complete_at' => time(),
                    'time_stop' => time() - $model->time_start,
                ]);
            }
        }
        return $this->redirect("/admin-product/admin-view/$model->id/");
    }

    /**
     * Дублирование лота
     * @param type $id
     * @return type
     */
    public function actionClone($id)
    {
        $model = Products::findOne($id);
        $this->canAccess($model->user_id);

        if ($clone_model = $model->cloneProduct()) {
            $id = $clone_model->id;
            return $this->redirect("/admin-product/update/$id/");
        }
        return $this->redirect("/admin-product/admin-view/$id/");
    }

    public function actionSubcat($id)
    {
        $out  = [];
        $post = Yii::$app->request->post();
        //var_dump($post);
        if (isset($post['depdrop_parents'])) {
            $parents = $post['depdrop_parents'];
            if ($parents != null) {
                $cat_id = $parents[$id];
                foreach (Categories::findAll(['parent_id' => $cat_id]) as $category) {
                    $out[] = ['id' => $category->id, 'name' => $category->name];
                }
                // the getSubCatList function will query the database based on the
                // cat_id and return an array like below:
                // [
                //    ['id'=>'<sub-cat-id-1>', 'name'=>'<sub-cat-name1>'],
                //    ['id'=>'<sub-cat_id_2>', 'name'=>'<sub-cat-name2>']
                // ]
                return Json::encode(['output' => $out, 'selected' => '']);
            }
        }
        echo Json::encode(['output' => '', 'selected' => '']);
    }
}
