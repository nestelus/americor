<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace molotokk\controllers;

use dektrium\user\controllers\SettingsController as DektriumSettingsController;
use Yii;
use yii\filters\AccessControl;
use common\models\SettingsForm;
use molotokk\models\DeliveryTypes;
use yii\data\ActiveDataProvider;
use molotokk\widgets\UserMenuWidget;
use yii\helpers\ArrayHelper;
use molotokk\models\PaymentTypes;
use molotokk\models\PaymentSystems;
use molotokk\models\DeliveryAddresses;

/**
 * Description of SettingsController
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class SettingsController extends DektriumSettingsController
{

    public function behaviors()
    {
        return array_merge(parent::behaviors(),
            [
            'access' => [
                'class' => AccessControl::className(),
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@'],
                    ],
                ],
            ],
        ]);
    }

    /**
     * Shows profile settings form.
     *
     * @return string|\yii\web\Response
     */
    public function actionProfile()
    {
        $model = $this->finder->findProfileById(Yii::$app->user->identity->getId());

        $this->performAjaxValidation($model);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            Yii::$app->getSession()->setFlash('success',
                Yii::t('user', 'Your profile has been updated'));

            return $this->refresh();
        }
        return $this->render('view',
                [
                'view' => '_cabinet_settings',
                'view_params' => [
                    'view_setting' => 'profile',
                    'setting_params' => [
                        'model' => $model,
                    ],
                ],
                'profile' => $model,
                'user' => $model->user,
        ]);
    }

    /**
     * Displays page where user can update account settings (username, email or password).
     *
     * @return string|\yii\web\Response
     */
    public function actionAccount()
    {

        $user = Yii::$app->user->identity;
        $this->canAccess($user->id);

        /** @var SettingsForm $model */
        $model = Yii::createObject(SettingsForm::className());

        $this->performAjaxValidation($model);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            Yii::$app->session->setFlash('success',
                Yii::t('user', 'Your account details have been updated'));

            return $this->refresh();
        }

        return $this->render('view',
                [

                'view' => '_cabinet_settings',
                'view_params' => [
                    'view_setting' => 'account',
                    'setting_params' => [
                        'model' => $model,
                    ],
                ],
                'profile' => $user->profile,
                'user' => $user,
        ]);
    }

    /**
     * Displays list of connected network accounts.
     *
     * @return string
     */
    public function actionNetworks()
    {
        $user = Yii::$app->user->identity;
        $this->canAccess($user->id);
        return $this->render('view',
                [
                'view' => '_cabinet_settings',
                'view_params' => [
                    'view_setting' => 'networks',
                    'setting_params' => [
                        'user' => $user,
                    ],
                ],
                'profile' => $user->profile,
                'user' => $user,
        ]);
    }

    /**
     * Lists all DeliveryTypes models.
     * @return mixed
     */
    public function actionDeliveryType()
    {
        $user_id      = Yii::$app->getUser()->id;
        $dataProvider = new ActiveDataProvider([
            'query' => DeliveryTypes::find()->andWhere(['user_id' => $user_id]),
        ]);

        return $this->render('view',
                [

                'view' => 'delivery-types',
                'params' => [
                    'dataProvider' => $dataProvider,
                ]
        ]);
    }

    /**
     * Creates a new DeliveryTypes model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionDeliveryTypeCreate()
    {
        $model          = new DeliveryTypes();
        $model->load(Yii::$app->request->post());
        $model->user_id = Yii::$app->user_id;
        if ($model->save()) {
            return $this->redirect("/user/settings/delivery-type/");
        } else {
            return $this->render('//default/user_sidebar',
                    [
                    'current' => UserMenuWidget::ITEMS_PROFILE,
                    'view' => 'delivery-type-create',
                    'params' => [
                        'model' => $model,
                    ]
            ]);
        }
    }

    public function actionNewDeliveryType()
    {
        $model = new DeliveryTypes();

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            if (Yii::$app->request->isAjax) {
                return '<div class="checkbox">'.\yii\helpers\Html::checkbox('Products[deliveryTypes][]',
                        true,
                        [
                        'label' => $model->name,
                        'value' => $model->id,
                    ]).'</div>';
            }
        }
    }

    /**
     * Updates an existing DeliveryTypes model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDeliveryTypeUpdate($id)
    {
        $model = DeliveryTypes::findOne($id);
        $this->canAccess($model->user_id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect("/user/settings/delivery-type/");
        } else {
            return $this->render('//default/user_sidebar',
                    [
                    'current' => UserMenuWidget::ITEMS_PROFILE,
                    'view' => 'delivery-type-update',
                    'params' => [
                        'model' => $model,
                    ]
            ]);
        }
    }

    /**
     * Deletes an existing DeliveryTypes model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDeliveryTypeDelete($id)
    {
        $model = DeliveryTypes::findOne($id);
        $this->canAccess($model->user_id);
        $model->delete();

        return $this->redirect("/user/settings/delivery-type/");
    }

    public function actionPaymentType()
    {

        $user_id       = Yii::$app->getUser()->id;
        $payment_types = ArrayHelper::map(PaymentTypes::find()->where(['user_id' => $user_id])->all(),
                'systems_id', 'systems_id');

        $payment_systems = PaymentSystems::find()->all();
        return $this->render('//default/user_sidebar',
                [
                'current' => UserMenuWidget::ITEMS_PROFILE,
                'view' => 'payment-type',
                'params' => [
                    'payment_systems' => $payment_systems,
                    'payment_types' => $payment_types,
                ]
        ]);
    }

    /**
     * Updates an existing PaymentTypes model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionPaymentTypeUpdate()
    {
        $post          = Yii::$app->request->post();
        $user_id       = Yii::$app->getUser()->id;
        if ($payment_types = $post['Pay_sys']) {
            PaymentTypes::updatePaymentSystem($user_id, $payment_types);
        } else {
            $payment_types = ArrayHelper::map(PaymentTypes::find()->where(['user_id' => $user_id])->all(),
                    'systems_id', 'systems_id');
        }
        $payment_systems = PaymentSystems::find()->all();
        return $this->renderAjax('payment-type',
                [
                'payment_systems' => $payment_systems,
                'payment_types' => $payment_types,
        ]);
    }

    public function actionDeliveryAdresses()
    {
        $user         = Yii::$app->user->identity;
        $this->canAccess($user->id);
        $dataProvider = new ActiveDataProvider([
            'query' => DeliveryAddresses::find()->where(['user_id' => $user->id]),
        ]);
        return $this->render('view',
                [
                'view' => '_cabinet_settings',
                'view_params' => [
                    'view_setting' => 'delivery-adresses',
                    'setting_params' => [
                        'dataProvider' => $dataProvider,
                    ],
                ],
                'profile' => $user->profile,
                'user' => $user,
        ]);
    }

    /**
     * Creates a new DeliveryAddresses model.
     * If creation is successful, the browser will be redirected to the 'view' page.
     * @return mixed
     */
    public function actionDeliveryAdressesCreate()
    {

        $user           = Yii::$app->user->identity;
        $model          = new DeliveryAddresses();
        $model->load(Yii::$app->request->post());
        $model->user_id = $user->id;
        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect('/user/settings/delivery-adresses/');
        } else {
            return $this->render('view',
                    [
                    'view' => '_cabinet_settings',
                    'view_params' => [
                        'view_setting' => 'delivery-adresses-create',
                        'setting_params' => [
                            'model' => $model,
                        ],
                    ],
                    'profile' => $user->profile,
                    'user' => $user,
            ]);
        }
    }

    /**
     * Updates an existing DeliveryAddresses model.
     * If update is successful, the browser will be redirected to the 'view' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDeliveryAdressesUpdate($id)
    {
        $user  = Yii::$app->user->identity;
        $model = DeliveryAddresses::findOne($id);
        $this->canAccess($model->user_id);

        if ($model->load(Yii::$app->request->post()) && $model->save()) {
            return $this->redirect('/user/settings/delivery-adresses/');
        } else {
            return $this->render('view',
                    [
                    'view' => '_cabinet_settings',
                    'view_params' => [
                        'view_setting' => 'delivery-adresses-update',
                        'setting_params' => [
                            'model' => $model,
                        ],
                    ],
                    'profile' => $user->profile,
                    'user' => $user,
            ]);
        }
    }

    /**
     * Deletes an existing DeliveryAddresses model.
     * If deletion is successful, the browser will be redirected to the 'index' page.
     * @param integer $id
     * @return mixed
     */
    public function actionDeliveryAdressesDelete($id)
    {
        $model = DeliveryAddresses::findOne($id);
        $this->canAccess($model->user_id);
        $model->delete();

        return $this->redirect('/user/settings/delivery-adresses/');
    }

    protected function canAccess($user_id)
    {
        if ($user_id != Yii::$app->user->id) {
            throw new AssumedPageException('У Вас нет доступа к этой странице');
        } else {
            return true;
        }
    }
}
