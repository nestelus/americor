<?php
/**
 * Controller for search by Sphinx
 */

namespace molotokk\controllers;

use Yii;
use common\controllers\AuktaController;
use molotokk\models\sphinx\Products;
use yii\db\Expression;
use common\models\auktaModels\Categories;
use common\models\User;
use yii\helpers\Url;
use common\components\searchFilter\SphinxFilter;
use common\models\auktaModels\enumModels\StateProduct;

/**
 * Description of SphinxController
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class SphinxController extends AuktaController
{

    public function actionSearch()
    {
        $get    = Yii::$app->request->get();
        $query  = Products::find();
        $states = [
            StateProduct::STATE_ON_SALE => 'Купить сейчас',
            StateProduct::STATE_ON_AUCTION => 'Аукцион',
        ];
        if (isset($get['category_id'])) {
            $category_id = $get['category_id'];
        } elseif (isset($get['searchCategory'])) {
            $category_id = $get['searchCategory'];
        } else {
            $category_id = null;
        }
        if ($category_id > 0) {
            $category = Categories::findOne($category_id);
            $query->where(['category_id' => $category->categoryWithChildren(),
                'state_id' => [
                    StateProduct::STATE_ON_SALE,
                    StateProduct::STATE_ON_AUCTION,
                ]
            ]);
        }
        if ($category_id == -1) {
            $query->where(['state_id' => [
                    StateProduct::STATE_ON_SOLD,
                    StateProduct::STATE_ON_HIDE,
                ]
            ]);
            $states = [
                StateProduct::STATE_ON_SOLD => 'Проданные',
                StateProduct::STATE_ON_HIDE => 'Не проданные',
            ];
        }
        if ($category_id == -2) {
            if (!empty($get['searchText'])) {
                $user = User::findOne(['username' => $get['searchText']]);
                if ($user) {
                    return $this->redirect(Url::to(['profile/view', 'id' => $user->id]));
                }
            }
        }
        $title = 'Результаты поиска';

        if (isset($get['searchText'])) {

            $title = $get['searchText'] ? 'Результаты поиска по "'.$get['searchText'].'"'
                    : 'Результаты поиска';
        }
        $searchFilter = new SphinxFilter([
            'query' => $query,
            'action' => $this->action->id,
            'states' => $states,
            'params' => [
                sphinxFilter::VAR_SEARCH_PRICE,
                sphinxFilter::VAR_SEARCH_TIME_START,
                sphinxFilter::VAR_SEARCH_TIME_END,
                sphinxFilter::VAR_SEARCH_REGION,
            ],
        ]);


        if (Yii::$app->request->isPjax):
            return $this->renderAjax('products-list',
                    [
                    'searchFilter' => $searchFilter,
                    'title' => $title,
            ]);
        else :
            return $this->render('products-list',
                    [
                    'searchFilter' => $searchFilter,
                    'title' => $title,
            ]);
        endif;
    }

    /**
     * Отображение списка категории
     * @param int $id //id категории
     * @return type
     */
    public function actionCategories($id)
    {

        $category    = Categories::findOne($id);
        $query       = Products::find();
        $query->where(['category_id' => $category->categoryWithChildren()])
            ->facets(['category_id', 'parent_id']);
        $title       = Yii::t('products', 'Товары категории {category}',
                [
                'category' => $category->getCategoryPath(),
        ]);
        $sphixFilter = new SphinxFilter([
            'query' => $query,
            'action' => $this->action->id,
            'states' => [
                -1 => 'Все',
                StateProduct::STATE_ON_SALE => 'Купить сейчас',
                StateProduct::STATE_ON_AUCTION => 'Аукцион',
                StateProduct::STATE_ON_SOLD => 'Проданные'
            ],
            'params' => [
                SphinxFilter::VAR_SEARCH_PRICE,
                SphinxFilter::VAR_SEARCH_TIME_START,
                SphinxFilter::VAR_SEARCH_TIME_END,
                SphinxFilter::VAR_SEARCH_REGION,
            ]
        ]);



        if (Yii::$app->request->isPjax) {
            return $this->renderAjax('category',
                    [
                    'category' => $category,
                    'searchFilter' => $sphixFilter,
                    'title' => $title,
            ]);
        } else {
            return $this->render('category',
                    [
                    'category' => $category,
                    'searchFilter' => $sphixFilter,
                    'title' => $title,
            ]);
        }
    }
}
