<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace molotokk\assets;
use yii\web\AssetBundle;

/**
 * Description of AdminProductAsset
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class AdminProductAsset extends AssetBundle
{
      public $sourcePath = '@molotokk/assets';
      public $js = [
          'js/admin-product.js',
      ];
}