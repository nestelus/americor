$('#js_change_category').click(function () {
    $.ajax({
        url: '',
        data: {
            id: '',
            category_id: $('#js_category-change-id').val()
        },
        dataType: 'json',
        success: function (data) {
            $("#current-stake").html(data.currentStake);
            $(".number-stake").html(data.numberStake);
            $("#result-stakes").html(data.resultStakes);
            $("#next-stake").html(data.nextStakes);
            $("#all-stake").html(data.allStakes);
        }
    });
});



