/*
 *
 */


$("#is_stop_price").click(function () {
    if ($(this).prop('checked')) {
        $('#stop_price').show('slow');
    } else {
        $("#products-price_stop").val('');
        $('#stop_price').hide('slow');
    }
});
$("#js_is-multilot").click(function () {
    if ($(this).prop('checked')) {
        $('#js_quality').show('slow');
    } else {
        $("#products-quality").val(1);
        $('#js_quality').hide('slow');
    }
});
$('#btn-moderate').click(function () {
    $('#on-moderate').val(1);
});
$("#is-republic").click(function () {
    if ($(this).prop('checked')) {
        $("#products-num_public").val(3);
        $('#num-public').show('slow');
    } else {
        $("#products-num_public").val(0);
        $('#num-public').hide('slow');
    }
});
$("#new-delivery").click(function () {
    $.ajax({
        url: '/admin-product/new-delivery-type/',
        type: "POST",
        dataType: "html",
        data: $("#form-new-delivery-type").serialize(),
        success: function (result) {
            //alert(result);
            $("#ndt").append(result);
        }
    });
    $("#add-delivery").modal('hide');
    //  return false;
});
$("#return-edit").click(function () {
    $("#modal-confirm").modal("hide");
});
$('#js_time-start').click(function () {
    if ($(this).prop('checked')) {
        $('#js_field-time-start').val(null);
        $('#js_field-time-start').show('slow');
    } else {
        $('#js_field-time-start').val(null);
        $('#js_field-time-start').hide('slow');
    }
});
$('#js_products-create-block')
        .on('click', '#js_categories_user_cancel', function () {
            $('#admin-product-category-change-block').remove();
            $("#js_categories_user_change").removeClass('hidden');

        })
        .on('click', '#js_change_category', function () {
            // console.log($('#categories-id').val());
            var selectedCategory = $('#categories-id').val();
            if (selectedCategory) {
                $.ajax({
                    url: '/admin-product/change-category/',
                    method: 'POST',
                    data: {
                        id: $('#js_product_id').val(),
                        category_id: selectedCategory
                    },
                    dataType: 'json',
                    success: function (data) {
                        $('#js_categories').html(data.categories);
                        if (data.properties) {
                            $("#js_properties_values").html(data.properties);
                            $("#js_properties").show("slow");
                        } else {
                            $("#js_properties").hide("slow");
                            $("#js_properties_values").html('');
                        }

                    }
                });
            }
        })
        .on('change', '#js_change_category-form', function () {
            // console.log($('#categories-id').val());
            if ($.isNumeric($('#categories-id').val())) {
                $('#js_change_category').prop('disabled', false);
            } else {
                $('#js_change_category').prop('disabled', true);
            }
        })
        .on('change', '#auction', isAuction)
        .on('click', '#js_is_stop_price', function () {
            if ($(this).is(':checked')) {
                $('#js_price_stop').show('slow');
            } else {
                $('#js_price_stop').hide('slow');
                $("#products-price_stop").val('');
            }
        });
$('#products-name').on('keyup paste cut', function () {
    // console.log($(this).val().length);
    $('#leght_name').text(64 - $(this).val().length);
});

$(document).ready(function () {

    isAuction();
});
function isAuction() {

    if ($('#auction :selected').val() === '1') {
        $('.js_no-auction').hide('slow');
        $('.js_auction').show('slow');
        $("#products-quality").val(1);
        $("#products-num_public").val(0);
        $('label[for="products-price"]').text('Стартовая цена');
        $('#js_quality').hide();
        $('input[name="Products[is_multilot]"]').prop('checked', false);
    } else {
        $('.js_auction').hide('slow');
        $('.js_no-auction').show('slow');
        $('label[for="products-price"]').text('Цена');
    }
}
