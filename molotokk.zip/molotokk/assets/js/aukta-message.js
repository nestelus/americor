//Работа с окном сообщением
function checkMessages() {
    var readDeff = readMessages();
    // console.log(readDeff);
    readDeff.done(function () {
        setTimeout(countMessages(), 3000);
    });

}


function readMessages() {
    var deffrs = [];
    $('.js_message-new').filter(function (index) {

        return (($(this).offset().top > $("#js_message-dialog").offset().top)
                && ($(this).offset().top < $("#js_message-dialog").offset().top + $("#js_message-dialog").height()));
    }).each(function (index, bell) {
        deffrs[index] = new $.Deferred();
        $message = $(bell).attr('message_id');
        $.ajax({
            url: '/messages/read/',
            data: {
                'id': $message
            },
            success: function () {
                $(bell).children().first().hide('slow');
                $(bell).remove();
                deffrs[index].resolve();
            },
            error: function () {
                deffrs[index].resolve();
            }
        });
    });
    var whendeff = $.when(deffrs);
    //console.log(whendeff);
    return whendeff;
}


function countMessages() {

    $.ajax({
        url: '/messages/count-new-messages/',
        success: function (data) {
            var count_arr = $.parseJSON(data).count_new;
            $('.js_count-messages').each(function (indx, element) {
                var direction = $(element).attr('direction');
                var lot = $(element).attr('lot');
                var from = $(element).attr('from');
                var count = 0;
                for (var dir in count_arr) {
                    for (var lt in count_arr[dir]) {
                        for (var fr in count_arr[dir][lt]) {
                            for (var stat in count_arr[dir][lt][fr]) {
                                if (
                                        (direction == 0 || dir == direction)
                                        && (lot == 0 || lot == lt)
                                        && (from == 0 || from == fr)
                                        && (stat == 1)
                                        ) {
                                    count = count + parseInt(count_arr[dir][lt][fr][stat]);
                                }
                            }
                        }

                    }
                }
                if (count == 0) {
                    $(element).fadeOut('slow');
                } else {
                    $(element).html(count);
                    $(element).fadeIn('slow');
                }
            });
        }
    });
}
