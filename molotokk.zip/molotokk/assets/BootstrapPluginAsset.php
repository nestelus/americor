<?php
/**
 * Подключение Bootstrap к проекту
 */

namespace molotokk\assets;

use yii\web\AssetBundle;

class BootstrapPluginAsset extends AssetBundle
{
    public $sourcePath = '@static';
    public $css = [
        'css/bootstrap.css',
    ];
    public $js = [
        'js/app.js'
    ];
    public $depends = [
        'yii\web\JqueryAsset',
    ];
}