<?php

/**
 * @var yii\web\View 			$this
 * @var dektrium\user\Module 	$module
 */
use yii\helpers\Html;

$this->title = $title;
?>


<?php if ($module->enableFlashMessages): ?>
      <div class="row">
        <div class="col-xs-12">
          <?php foreach (Yii::$app->session->getAllFlashes() as $type => $message): ?>
                  <?php if (in_array($type, ['success', 'danger', 'warning', 'info'])): ?>
                      <div class="alert alert-<?= $type ?>">
                      <?= $message ?>
                      </div>
                <?php endif ?>
      <?php endforeach ?>

          На Ваш электронный адрес <?= $email ?>  было отправлено письмо, с помощью которого Вы сможете завершить регистрацию.
          Прочитайте письмо от Aukta и нажмите на ссылку, указанную в нем.

            <?php if ($module->enableConfirmation): ?>
                <p class="text-center">
                <?= Html::a(Yii::t('user', 'Didn\'t receive confirmation message?'), ['/user/registration/resend']) ?>
                </p>
      <?php endif ?>

        </div>
      </div>
<?php endif ?>

