<?php

/**
 * @var yii\web\View 			$this
 * @var dektrium\user\Module 	$module
 */
use yii\helpers\Html;

$this->title = $title;
?>

<h1>Регистрация успешно завершена!</h1>
<?php if ($module->enableFlashMessages): ?>
      <div class="row">
        <div class="col-xs-12">
          <?php foreach (Yii::$app->session->getAllFlashes() as $type => $message): ?>
                <?php if (in_array($type, ['success', 'danger', 'warning', 'info'])): ?>
                      <div class="alert alert-<?= $type ?>">
                        <?= $message ?>
                      </div>
                <?php endif ?>
          <?php endforeach ?>


          "<p>&nbsp;</p>
          <h3 style="text-align: justify;">Благодарим, что выбрали Aukta.ru, мы рады видеть Вас в рядах наших друзей!</h3>
          <h3 style="text-align: justify;">Узнать подробнее об Aukta.ru и ознакомится с особенностями площадки Вы можете в разделе <a href="/#" target="_blank">Помощь</a>.</h3>
          <h3 style="text-align: justify;">Если Вы уже опытный пользователь, предлагаем перейти к выставлению своего первого лота на <a href="/admin-product/create/">Aukta.ru</a> или перейти к <a href="/">покупкам</a>.</h3>
        </div>
      </div>
<?php endif ?>

