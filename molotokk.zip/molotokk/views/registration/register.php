<?php
/* @var $this yii\web\View */

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use yii\bootstrap\Modal;
use dektrium\user\widgets\Connect;

/**
 * @var yii\web\View              $this
 * @var dektrium\user\models\User $user
 * @var dektrium\user\Module      $module
 */
$this->title                   = Yii::t('user', 'Sign up');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="row">
    <div class="col-md-6 col-md-offset-3">
        <div class="panel panel-default">
            <div class="panel-heading">
                <h3 class="panel-title"><?= Html::encode($this->title) ?></h3>
            </div>
            <div class="panel-body">
                <?php
                $form                          = ActiveForm::begin([
                        'id' => 'registration-form',
                        'enableAjaxValidation' => true,
                        'enableClientValidation' => true,
                ]);
                ?>

                <?= $form->field($model, 'email') ?>

                <?= $form->field($model, 'username') ?>

                <?php if ($module->enableGeneratingPassword == false): ?>
                    <?= $form->field($model, 'password')->passwordInput() ?>
                    <?= $form->field($model,
                        'password_repeat')->passwordInput()
                    ?>
                <?php endif ?>
                <?=
                Html::checkbox('confirm', FALSE,
                    [
                    'id' => 'confirm_offerta',
                    'label' => Yii::t('users', 'Я согласен с {link}.',
                        [
                        'link' => Html::a(Yii::t('users',
                                'правилами пользования'), ['#'],
                            [
                            'data-toggle' => 'modal',
                            'data-target' => '#offerta',
                        ])
                    ])
                ])
                ?>

                <?=
                Html::submitButton(Yii::t('user', 'Sign up'),
                    [
                    'class' => 'btn btn-success btn-block',
                    'id' => 'btn-regis',
                    'disabled' => 'disabled',
                    'onClick' => "ga('send', 'event', 'Регистрация', 'Отправка запроса')",
                ])
                ?>

<?php ActiveForm::end(); ?>
            </div>
        </div>
        <p class="text-center">
            <?=
            Html::a(Yii::t('user', 'Already registered? Sign in!'),
                ['/user/security/login'])
            ?>
        </p>
        <p class="text-center">
            <?=
            Connect::widget([
                'options' => [
                    'class' => 'text-center',
                ],
                'baseAuthUrl' => ['/user/security/auth'],
            ])
            ?>
        </p>
    </div>
</div>
<?php
Modal::begin([
    'size' => 'modal-lg',
    'options' => [
        'id' => 'offerta',
    ],
    'header' => '<h2>Правила пользования сервисом "АУКТА"</h2>',
])
?>
<?= $this->render('oferta') ?>

<?php Modal::end() ?>

<?php
$js = <<< JS
    $('#confirm_offerta').click(function(){
        if($(this).prop('checked') ){
        $('#btn-regis').prop('disabled',false);
        }
        else{
        $('#btn-regis').prop('disabled',true);
        };
          });

JS;
$this->registerJs($js);
