<?php

/**
 * @var yii\web\View                   $this
 *
 */
use molotokk\models\Products;
use yii\helpers\Html;
?>

<?php
foreach ($products as $lot_id => $users):

    $lot   = Products::findOne($lot_id);
    $photo = $lot->getProductPhotos()->one();
    ?>

    <div class="dialog-list-lot" id="list-lot-<?= $lot->id ?>">
        <span class="product-img">
            <?=
            Html::img($photo ? $photo->getUrlPhoto(50, 50) : '',
                [
                'width' => 50,
                'hieght' => 50,
            ]);
            ?>
        </span>
        <span class="product-name">Лот №<?= $lot->id ?></span>
    </div>

    <ul class="list_users message-user-list">

        <?php foreach ($users as $usr): ?>
            <li class="contact" data-user="<?= $usr->id ?>"  data-product="<?= $lot_id ?>" data-direction="<?= $direction ?>">
                <span class="glyphicon glyphicon-user"></span>
                <a href="#">
                    <span class="user-title"><?= $usr->username ?>
                        <span class="cnt"></span>
                    </span>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
<?php endforeach; ?>
