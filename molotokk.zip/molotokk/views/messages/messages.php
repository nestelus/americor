<?php

use molotokk\widgets\AuktaMessanger;
use yii\bootstrap\Nav;
use yii\widgets\Pjax;

Pjax::begin();
echo Nav::widget([
    'options'      => [
        'class' => 'nav nav-tabs',
    ],
    'encodeLabels' => false,
    'items'        => [
        [
            'label' => 'Диалоги с продавцами' . '<span id="new_my_messages"></span>',
            'url'   => '/messages/my-messages/',
        // 'visible' => Yii::$app->user->can('viewOwnPayDew'),
        ],
        [
            'label' => 'Диалоги с покупателями' . '<span id="new_me_messages"></span>',
            'url'   => '/messages/me-messages/',
        // 'visible' => Yii::$app->user->can('viewOwnPayDew'),
        ],
        [
            'label' => 'Системные сообщения' . '<span id="new_sys_messages"></span>',
            'url'   => '/messages/system-messages/',
        // 'visible' => Yii::$app->user->can('viewOwnPayDew'),
        ],
    ],
]);

echo $this->render('aukta-messenger', [
    'products'  => $products,
    'user'      => $user,
    'direction' => $direction,
    'uniq_id'   => $uniq_id,
]);

Pjax::end();
