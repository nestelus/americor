<?php
/* @var $this yii\web\View */
/* @var $model molotokk\models\Products */
/* @var $properties molotokk\models\ProductProperties[] */
/* @var $photos molotokk\models\ProductPhotos[] */
/* @var $deliveries molotokk\models\DeliveryTypes[] */
/* @var $views string */

use yii\bootstrap\Html;
use Yii;
use common\models\auktaModels\enumModels\StateProduct;

$this->title = $model->name;
//$this->params['breadcrumbs'][] = ['label' => Yii::t('products', 'My Products'), 'url' => ['index']];
?>
<div class="products-admin-view">




  <h1><?= StateProduct::getLabel($model->state_id) ?></h1>

  <?=
  $this->render('/products/view',
      [
      'model' => $model,
      'properties' => $properties,
      'photos' => $photos,
      'deliveries' => $deliveries,
      'user' => $user,
  ]);
  ?>


</div>


