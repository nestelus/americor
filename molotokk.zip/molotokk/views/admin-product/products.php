<?php

use yii\widgets\LinkPager;
use \common\widgets\ShortProductWidget;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title                   = Yii::t('products', 'My Products');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="products-index">
  <?=
  ShortProductWidget::widget([
      'products' => $products,
  ]);
  ?>



  <?=
  LinkPager::widget([
      'pagination' => $pages,
  ]);
  ?>
</div>
