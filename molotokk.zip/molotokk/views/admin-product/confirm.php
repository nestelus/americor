<?php
/* @var $this yii\web\View */
/* @var $model molotokk\models\Products */
/* @var $properties molotokk\models\ProductProperties[] */
/* @var $photos molotokk\models\ProductPhotos[] */
/* @var $deliveries molotokk\models\DeliveryTypes[] */
/* @var $views string */

use yii\bootstrap\Html;
use Yii;
use yii\widgets\ActiveForm;

$this->title = $model->name;
//$this->params['breadcrumbs'][] = ['label' => Yii::t('products', 'My Products'), 'url' => ['index']];
?>
<div class="products-admin-view">
  <p>
    <?=
    kartik\widgets\Alert::widget([
        'body' => 'Пожалуйста, проверьте правильность введенной Вами информации. Для подтверждения нажмите кнопку внизу страницы.',
    ])
    ?>
  </p>
  <p>
    <?php
    $form        = ActiveForm::begin([
            'action' => ['confirm', 'id' => $model->id],
            'options' => [
                'class' => 'text-center',
            ],
        ])
    ?>
    <?= Html::hiddenInput('confirm', true) ?>
    <?=
    Html::a('Вернуться к редактированию', ['update', 'id' => $model->id], ['class' => 'btn btn-primary'])
    ?>
    <?=
    Html::submitButton(Yii::t('general', 'Подтвердить и разместить'),
        [
        'id' => 'btn-moderate',
        'class' => 'btn btn-danger',
        'onClick' => "ga('send', 'event', 'Выставить лот', 'Подтвердить и разместить')",
    ]);
    ?>

    <?php ActiveForm::end() ?>
  </p>
  <p>
    <?=
    $this->render('/products/view',
        [
        'model' => $model,
        'properties' => $properties,
        'photos' => $photos,
        'deliveries' => $deliveries,
        'user' => $user,
    ]);
    ?>
  </p>


</div>


