<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model molotokk\models\Products */

$this->title = Yii::t('products', 'Размещение нового лота {name}', ['name' => $model->name]);
//$this->params['breadcrumbs'][] = ['label' => Yii::t('products', 'My Products'), 'url' => ['my-products']];
//$this->params['breadcrumbs'][] = $this->title;
?>
<div class="products-create" id="js_products-create-block">

    <h2><?= Html::encode($this->title) ?></h2>

    <?=
    $this->render('_form', [
        'model'      => $model,
        'properties' => $properties,
    ])
    ?>

</div>
