<?php

use molotokk\widgets\PropertyFieldWidget;

/* @var $this yii\web\View */
/* @var $model molotokk\models\Products */
/* @var $properties molotokk\models\ProductProperties[] */

/* @var $form common\components\NCActiveForm */
?>

<?php
foreach ($properties as $key => $property):

    /* @var $property molotokk\models\ProductProperties */
    // echo $property->renderField($key);//
    ?>
    <?= $form->field($property, 'category_properties_id')->hiddenInput(['value' => $property->category_properties_id]) ?>

    <?=
    $form->field($property, 'data')->widget(PropertyFieldWidget::className(),
        [
        'type_id' => $property->categoryProperties->type_id,
        'name' => 'data',
        'value' => $property->data,
        'data' => $property->categoryProperties->data,
    ])->label($property->categoryProperties->name);
    ?>

<?php endforeach; ?>


