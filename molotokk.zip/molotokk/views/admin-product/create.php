<?php

use yii\helpers\Html;
use kartik\widgets\DepDrop;
use yii\helpers\ArrayHelper;
use molotokk\models\Categories;
use yii\bootstrap\ActiveForm;
use yii\widgets\Pjax;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model molotokk\models\Products */


$this->title                   = Yii::t('products', 'Разместить лот');
$this->params['breadcrumbs'][] = Yii::t('products', 'Продажи');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="products-create">
    <h1><?= Html::encode($this->title) ?></h1>
    <?php
    Pjax::begin([
        'id' => 'pj_create-lot',
        'formSelector' => '.pj_admin-product-form',
        'timeout' => 0,
    ]);
    ?>
    <?php
    $form                          = ActiveForm::begin([
            'id' => 'admin-product-create',
            'options' => [
                'class' => 'pj_admin-product-form',
                'data-pjax' => 1,
            ],
    ]);
    ?>


    <div class ="border-block">
        <!-- Название -->
        <?= $form->field($model, 'name')->textInput(['maxlength' => 200]) ?>
        <div class="row">

            <label class="control-label" ><?= Yii::t('products',
            'Выберите категорию') ?></label><br/>
            <div class="col-md-4 ">
                <?=
                Html::dropDownList('parent', null,
                    ArrayHelper::map(Categories::findAll(['parent_id' => null]),
                        'id', 'name'),
                    [
                    'id' => 'cat-id',
                    'size' => 6,
                    'class' => 'form-control',
                    'prompt' => 'Выберите...',
                ]);
                ?>
            </div>
            <div class="col-md-4 ">
                <?=
                $form->field($model, 'subcat')->widget(DepDrop::classname(),
                    [
                    'options' => [
                        'id' => 'subcat-id',
                        'size' => 6,
                    ],
                    'pluginOptions' => [
                        'depends' => ['cat-id'],
                        'placeholder' => 'Выберите...',
                        'url' => Url::to(['/admin-product/subcat/0'])
                    ]
                ])->label(false);
                ?>
            </div>
            <div class="col-md-4">
                <?=
                $form->field($model, 'category_id')->widget(DepDrop::classname(),
                    [
                    'options' => [
                        'size' => 6,
                    ],
                    'pluginOptions' => [
                        'depends' => ['cat-id', 'subcat-id'],
                        'placeholder' => 'Выберите...',
                        'url' => Url::to(['/admin-product/subcat/1'])
                    ]
                ])->label(false);
                ?>
            </div>
        </div>

        <p>
    <?= Html::submitButton('Выбрать', ['class' => 'btn btn-danger']); ?>
        </p>

    </div>

<?php ActiveForm::end(); ?>

<?php Pjax::end(); ?>
</div>

