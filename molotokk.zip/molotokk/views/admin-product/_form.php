<?php

use yii\helpers\Html;
use yii\bootstrap\ActiveForm;
use common\widgets\PropertyFieldWidget;
use molotokk\assets\AdminProductAsset;
use common\widgets\RegionFormWidget;
use common\models\auktaModels\enumModels\DeliveryType;
use common\models\auktaModels\enumModels\PayMethod;
use common\models\auktaModels\enumModels\StateProduct;
use kartik\widgets\Select2;
use yii\web\JsExpression;
use common\models\auktaModels\enumModels\SaveLot;
use yii\helpers\ArrayHelper;
use molotokk\widgets\CategoryChangeWidget;
use molotokk\widgets\UploadPhotoWidget;

/* @var $this yii\web\View */
/* @var $model molotokk\models\Products */
?>
<style>
    div.required label:after {
        content: " *";
        color: red;
    }
</style>
<div class="row">
    <div class="col-md-12">
        <?php if ($model->getErrors()): ?>
            <?php foreach ($model->getFirstErrors() as $error): ?>
                <div class="alert alert-danger">
                    <?= $error ?>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <fieldset>
            <legend>
                Выбор категории
            </legend>
            <div id="js_categories" class="admin-product-fieldset-content">

                <?= CategoryChangeWidget::widget(['model' => $model]) ?>


            </div>
        </fieldset>
    </div>
</div>
<?php
$form = ActiveForm::begin(
        [
            'layout' => 'horizontal',
            'id' => 'admin-product-form',
            'fieldConfig' => [
                'template' => "{label} {beginWrapper} {input} {error} {hint}{endWrapper} ",
                'horizontalCssClasses' => [
                    'label' => 'col-md-3 col-lg-2',
                    'wrapper' => 'col-md-8 col-lg-9',
                    'error' => '',
                    'hint' => 'text-right',
                ],
            ],
        ]
);
?>
<?=
Html::hiddenInput('moderate', SaveLot::SAVE_LOT_DRAFT, ['id' => 'on-moderate'])
?>
<div class="row">
    <div class="col-md-12">
        <fieldset>
            <legend>
                Описание лота
            </legend>
            <div class="admin-product-fieldset-content ">
                <div class="row">
                    <div class="col-md-12">
                        <?=
                            $form->field($model, 'name')->textInput(['maxlength' => 64])
                            ->hint('Максимум 64 символа. Осталось <span id="leght_name">'.(64
                                - mb_strlen($model->name)).'</span> ')
                        ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <?=
                        $form->field($model, 'description')->textarea(['rows' => 4])
                        ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <?=
                        $form->field($model, 'tagNames')->widget(
                            Select2::className(),
                            [
                            'language' => 'ru',
                            'showToggleAll' => false,
                            'options' => [
                                'placeholder' => Yii::t('products',
                                    'Начните ввод тега'),
                                'multiple' => true,
                            ],
                            'pluginOptions' => [
                                'tokenSeparators' => [',', ';'],
                                'allowClear' => true,
                                'tags' => true,
                                'minimumInputLength' => 3,
                                'maximumInputLength' => 30,
                                'ajax' => [
                                    'url' => '/tags/list/',
                                    'dataType' => 'json',
                                    'data' => new JsExpression('function(params) { return {q:params.term}; }'),
                                ],
                            ],
                            ]
                        )
                        ?>
                    </div>
                </div>
            </div>
        </fieldset>
    </div>
</div>
<div class="row" id="js_properties" <?=
(empty($properties) ? 'style="display:none"' : '')
?>>
    <div class="col-md-12">
        <fieldset class="lot-characteristics">
            <legend>
                Характеристики товара
            </legend>
            <div class="admin-product-fieldset-content">
                <div class="row">
                    <div class="col-md-12" id="js_properties_values">
                        <?php
                        if (!empty($properties)) {
                            echo $form->field(
                                $model, 'productProperties',
                                [
                                'template' => "{beginWrapper} {input} {error} {endWrapper} {hint}",
                                'horizontalCssClasses' => ['wrapper' => 'col-md-12'],
                                ]
                            )->widget(
                                PropertyFieldWidget::className(),
                                [
                                'properties' => $properties,
                                ]
                            );
                        }
                        ?>
                    </div>
                </div>
            </div>
        </fieldset>
    </div>
</div>
<div class="row">
    <div class="col-md-12">
        <fieldset>
            <legend>
                Изображения
            </legend>
            <div class="admin-product-fieldset-content">
                <div class="row">
                    <div class="col-md-12">
                        <?=
                        UploadPhotoWidget::widget([
                            'product' => $model,
                            'modal' => false,
                        ])
                        ?>
                    </div>
                </div>
            </div>
        </fieldset>
    </div>
</div>
<?php if ($model->state_id == StateProduct::STATE_ON_CREATE) : ?>
    <div class="row">
        <div class="col-md-12">
            <fieldset>
                <legend>
                    Условия продажи
                </legend>
                <div class="admin-product-fieldset-content">
                    <div class="row">
                        <div class="col-md-12">

                            <?=
                            $form->field(
                                $model, 'is_auction',
                                ['horizontalCssClasses' => ['wrapper' => 'col-md-3']]
                            )->dropDownList(
                                [
                                1 => 'Аукцион',
                                0 => 'Купить сейчас',
                                ],
                                [
                                'id' => 'auction',
                                ]
                            )
                            ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <?=
                            $form->field(
                                $model, 'price',
                                [
                                'horizontalCssClasses' => ['wrapper' => 'col-xs-11 col-sm-11 col-md-2 col-lg-2'],
                                'inputOptions' => ['class' => 'form-control numberOnly'],
                                ]
                            )->hint(
                                Yii::$app->params['currency']
                            )
                            ?>
                        </div>
                    </div>
                    <div class="row js_auction" <?=
                    !$model->is_auction ? 'style="display: none"' : ''
                    ?>>
                        <div class="col-md-12">
                            <div class="row padding-bottom-15">
                                <div class="col-md-offset-3 col-lg-offset-2 col-md-6 checkbox">
                                    <?php
                                    echo Html::checkbox(
                                        'is_stop_price', $model->price_stop,
                                        [
                                        'label' => Yii::t('products',
                                            'Указать цену "Купить сейчас"'),
                                        'id' => 'js_is_stop_price',
                                        ]
                                    )
                                    ?>
                                </div>
                            </div>
                            <div class="row" id="js_price_stop" <?=
                            !$model->price_stop ? 'style="display: none"' : ''
                            ?>>
                                <div class="col-md-12">
                                    <?=
                                    $form->field(
                                        $model, 'price_stop',
                                        ['horizontalCssClasses' => ['wrapper' => 'col-xs-11 col-sm-11 col-md-2 col-lg-2']]
                                    )->hint(Yii::$app->params['currency'])
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row js_no-auction" <?=
                    $model->is_auction ? 'style="display: none"' : ''
                    ?>>
                        <div class="col-md-12">
                            <div class="row">
                                <div class="col-md-12">
                                    <?=
                                        $form->field(
                                            $model, 'is_multilot',
                                            ['horizontalCssClasses' => ['wrapper' => 'col-md-6',
                                                'offset' => 'col-md-offset-3 col-lg-offset-2']]
                                        )
                                        ->checkbox(['id' => 'js_is-multilot']);
                                    ?>
                                </div>
                            </div>
                            <div id="js_quality" class="row" <?=
                            !$model->is_multilot ? 'style="display: none"' : ''
                            ?>>
                                <div class="col-md-12" >
                                    <?=
                                    $form->field(
                                        $model, 'quality',
                                        [
                                        'horizontalCssClasses' => ['wrapper' => 'col-md-3'],
                                        'inputOptions' => ['class' => 'form-control numberOnly'],
                                        ]
                                    );
                                    ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <?=
                            $form->field(
                                $model, 'time_stop',
                                ['horizontalCssClasses' => ['wrapper' => 'col-md-2']]
                            )->dropDownList(
                                [
                                259200 => '3 дня',
                                604800 => '7 Дней',
                                1209600 => '14 Дней',
                                1814400 => '21 День',
                                ], ['class' => 'form-control']
                            )
                            ?>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-offset-3 col-lg-offset-2 col-md-6 checkbox">
                            <?=
                            Html::checkbox(
                                'republic', (bool) $model->num_public,
                                [
                                'id' => 'is-republic',
                                'label' => "Перевыставить после окончания",
                                ]
                            )
                            ?>
                        </div>
                    </div>
                </div>
            </fieldset>
        </div>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-md-12">
        <fieldset>
            <legend>
                Оплата и доставка
            </legend>
            <div class="admin-product-fieldset-content">
                <div class="row">
                    <div class="col-md-12">
                        <?=
                        $form->field($model, 'is_prepay', ['inline' => true])->radioList(
                            [1 => 'Требуется', 0 => 'Не требуется']
                        )
                        ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="control-label col-md-3 col-lg-2">
                                Способы оплаты
                            </label>
                            <div class="col-md-8 col-lg-9 checkbox">
                                <?=
                                Html::checkboxList(
                                    'paymentProduct',
                                    ArrayHelper::map($model->paymentProduct,
                                        'pay_method_id', 'pay_method_id'),
                                    PayMethod::getLabels(),
                                    ['itemOptions' => ['labelOptions' => ['class' => 'padding-right-35']]]
                                )
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <?=
                        $form->field(
                            $model, 'is_deliverypay',
                            [
                            'inline' => true,
                            ]
                        )->radioList(
                            [0 => 'Покупатель', 1 => 'Продавец']
                        )
                        ?>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label class="control-label col-md-3 col-lg-2">
                                Способы доставки
                            </label>
                            <div class="col-md-8 col-lg-9 checkbox">
                                <?=
                                Html::checkboxList(
                                    'deliveryProduct',
                                    ArrayHelper::map($model->deliveryProduct,
                                        'delivery_type_id', 'delivery_type_id'),
                                    DeliveryType::getLabels(),
                                    ['itemOptions' => ['labelOptions' => ['class' => 'padding-right-35']]]
                                )
                                ?>
                                <div class="help-block help-block-error "></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <label class="control-label col-md-3 col-lg-2">
                        Местоположение
                    </label>
                    <div class="col-md-9 col-lg-9">
                        <?=
                        RegionFormWidget::widget(
                            [
                                'model' => $model,
                                'form' => $form,
                                'inline' => true,
                            ]
                        )
                        ?>
                    </div>
                </div>
            </div>
        </fieldset>
    </div>
</div>
<div class="row">
    <?php if ($model->state_id == StateProduct::STATE_ON_CREATE) : ?>

        <?php
        echo Html::submitButton(
            Yii::t('general', 'Выставить лот'),
            [
            'id' => 'btn-moderate',
            'class' => 'btn btn-bg-orange-red btn-submit-lot',
            'form' => 'admin-product-form',
            'onClick' => "ga('send', 'event', 'Выставить лот', 'Опубликовать')",
            ]
        );
        ?>

        <?php
        echo Html::submitButton(
            Yii::t('general', 'Сохранить как черновик'),
            [
            'class' => 'btn btn-bg-grey btn-submit-lot',
            ]
        );
        ?>
    <?php else: ?>

        <?php
        echo Html::submitButton(
            Yii::t('general', 'Сохранить'),
            [
            'id' => 'btn-moderate',
            'class' => 'btn btn-danger',
            'form' => 'admin-product-form',
            ]
        );
        ?>

    <?php endif; ?>
</div>
<?php ActiveForm::end() ?>
<?=
UploadPhotoWidget::widget([
    'product' => $model,
    'galery' => false,
])
?>

<?php AdminProductAsset::register($this); ?>
