<?php

use yii\helpers\Html;
use common\widgets\ShortProductWidget;
use yii\widgets\LinkPager;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title                   = Yii::t('products', 'My Products');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="products-index">

  <h1><?= Html::encode($this->title) ?></h1>

  <?php if (Yii::$app->user->can('createProduct')) : ?>
        <p>
          <?= Html::a(Yii::t('products', 'Add Product'), ['create'], ['class' => 'btn btn-success']) ?>
        </p>
  <?php endif; ?>

  <div class="products-index">
    <?=
    ShortProductWidget::widget([
        'products' => $products,
    ]);
    ?>
    <?=
    LinkPager::widget([
        'pagination' => $pages,
    ]);
    ?>
  </div>
