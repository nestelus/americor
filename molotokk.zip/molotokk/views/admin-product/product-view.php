<?php
/* @var $this yii\web\View */
/* @var $model molotokk\models\Products */
/* @var $properties molotokk\models\ProductProperties[] */
/* @var $photos molotokk\models\ProductPhotos[] */
/* @var $deliveries molotokk\models\DeliveryTypes[] */
/* @var $payments molotokk\models\PaymentTypes[] */

use Yii;
use yii\helpers\Html;
use yii\widgets\DetailView;
use common\models\auktaModels\enumModels\StateProduct;
?>



<div class="panel panel-default">
  <div class="panel-heading"><?= Yii::t('products', 'General Properties') ?></div>
  <div class="panel-body">

    <?=
    DetailView::widget([
        'model'      => $model,
        'attributes' => [
            'id',
            'name',
            [
                'attribute' => 'user.username',
                'label'     => Yii::t('products', 'Owner')
            ],
            'description:ntext',
            [
                'attribute' => 'category.name',
                'label'     => Yii::t('categories', 'Category'),
            ],
            'price',
            [

                'attribute' => 'state_id',
                'value'     => StateProduct::getLabel($model->state_id),
            ],
            'created_at:datetime',
            'updated_at:datetime',
        ],
    ])
    ?>

  </div>
</div>
