<?php

use Yii;
use yii\bootstrap\Html;
use yii\widgets\DetailView;
use yii\helpers\ArrayHelper;
?>

<div class="panel panel-default">
  <div class="panel-heading"><?= Yii::t('products', 'Payment and Delivery') ?></div>
  <div class="panel-body">
    <?php if (!empty($deliveries)): ?>
          <h3><?= Yii::t('products', 'Delivery Types'); ?></h3>
          <?php foreach ($deliveries as $delivery): ?>
                <?=
                DetailView::widget([
                    'model'      => $delivery,
                    'attributes' => [
                        'name',
                        'cost',
                        'term',
                        'conditional'
                    ],
                ])
                ?>
          <?php endforeach; ?>
    <?php endif; ?>

    <?php if (!empty($payments)): ?>
          <h3><?= Yii::t('products', 'Payment Types'); ?></h3>
          <?php foreach ($payments as $payment): ?>
                <?=
                DetailView::widget([
                    'model'      => $payment,
                    'attributes' => [
                        'name',
                        'requisite'
                    ],
                ])
                ?>
          <?php endforeach; ?>
    <?php endif; ?>


  </div>
</div>
