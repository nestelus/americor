<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use Yii;
?>
<div class="panel panel-default">
  <div class="panel-heading"><?= Yii::t('products', 'Additional Properties') ?></div>
  <div class="panel-body">
    <?php if (!empty($properties)): ?>
          <table class="table table-striped table-responsive">
            <?php foreach ($properties as $property) : ?>
                  <tr><th><?= $property->categoryProperties->name ?></th><td><?= $property->data ?></td></tr>
            <?php endforeach; ?>

          </table>
    <?php endif; ?>

  </div>
</div>
