<?php

use yii\widgets\ActiveForm;
use Yii;
?>
<div class="visual-form clearfix">
    <?php
    // Фильтр
    $form = ActiveForm::begin([
        'method' => 'get',
        'action' => Yii::$app->request->getPathInfo(),
        'options' => [
            'id' => 'form-state_id',
            'class' => 'form-filter',
        ],
    ]);
    ?>
    <div class="pull-left padding-top-15">
        Сортировать по
    </div>
    <div class="pull-left" style="padding:9px 0 0 7px;">
        <?= $searchFilter->getFilterSorts() ?>
    </div>
    <div class="pull-right">
        <?= $searchFilter->getFilterMode() ?>
    </div>
    <?php ActiveForm::end(); ?>
</div>
<?php
$js = <<< JS
  $("#form-state_id").change(function(e) {
       $(this).submit();
   });

JS;
$this->registerJs($js);
?>

