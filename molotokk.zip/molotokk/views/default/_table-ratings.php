<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use molotokk\models\UserRating;
?>
<?php if (!empty($ratings)) : ?>
    <table class="profile-recall-table">
        <thead>
            <tr>
                <th>от</th>
                <th class="text-center">тип отзыва</th>
                <th class="text-center">дата</th>
                <th class="text-center">номер лота</th>
            </tr>
        </thead>
        <tbody>
            <?php
            foreach ($ratings as $key => $rating) :
                $author          = $rating->author;
                $backgroundColor = $key % 2 ? 'white' : 'grey';
                ?>
                <tr class="<?= $backgroundColor ?>">
                    <td>
                        <span class="uname">
                            <a href="/profile/view/<?= $rating->author_id ?>/"><?= $author->username ?></a>
                        </span> <span class="user-rating">(<?= $author->profile->rating ?>)</span>

                        <?php
                        switch ($rating->direction):
                            case UserRating::DIRECTION_FROM_BUYER:
                                echo '(Покупaтель)';
                                break;
                            case UserRating::DIRECTION_FROM_SELLER:
                                echo '(Продавец)';
                        endswitch;
                        ?>
                    </td>
                    <td class="text-center">
                        <?php
                        switch ($rating->rating_type):
                            case UserRating::RATING_POSITIVE:
                                ?><span class="text-success">Положительный</span> <?php
                                break;
                            case UserRating::RATING_NEUTRAL:
                                ?><span>Нейтральный</span> <?php
                                break;
                            case UserRating::RATING_NEGATIVE:
                                ?><span class="text-danger">Отрицательный</span> <?php
                                break;
                        endswitch;
                        ?>

                    </td>
                    <td class="text-center"><?=
                        Yii::t('user', '{0, date, dd.MM.YYYY}',
                            [$rating->created_at])
                        ?></td>
                    <td class="text-center">
                        <a href="<?= $rating->product->getUrl() ?>"><?= $rating->product_id ?></a>
                    </td>
                </tr>
                <tr class="<?= $backgroundColor ?>">
                    <td colspan="4">
        <?= $rating->rating_text ?>
                    </td>
                </tr>
    <?php endforeach; ?>
        </tbody>
    </table>
<?php else : ?>
    <div class="profile-recall-table"> Отзывов пока нет </div>
<?php endif; ?>
