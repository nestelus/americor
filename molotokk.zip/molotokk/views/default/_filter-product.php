<?php
/* @var $searchFilter common\components\searchFilter\searchFilter */

use common\models\auktaModels\enumModels\PropertyType;
use kartik\widgets\ActiveForm;
use yii\bootstrap\Html;

$fields = $searchFilter->getSearchFields();
?>

<?php
$form   = ActiveForm::begin(
        [
            'method' => 'get',
            'action' => Yii::$app->request->getPathInfo(),
            'options' => [
                'id' => 'form-search_filter',
                'class' => 'form-filter',
            ],
        ]
);
?>
<div class="search-filter-block">
    <div class="search-filter-header">
        <span class="search-filter-header-name">
            Параметры
        </span>
        <span id="js_reset-search" class="search-filter-header-reset">
            очистить
        </span>
    </div>
    <div>
        <?= $searchFilter->getFilterButtons() ?>
    </div>
    <?php
    foreach ($fields as $field) {
        echo $field;
    }
    ?>
    <?php
    if (!empty($properties)):
        foreach ($properties as $property) :
            if ($property->type_id == PropertyType::TYPE_LIST):
                ?>
                <div>
                    <label class="control-label for">
                        <?= $property->name ?>
                    </label>
                    <?= $property->renderSearchField(); ?>
                </div>
                <?php
            endif;
        endforeach;
    endif;
    ?>
    <p>
    <div class="form-group">
        <?=
        Html::submitButton(
            'Искать',
            [
            'class' => 'btn btn-bg-orange-red color-white',
            ]
        )
        ?>

    </div>
</div>
<?php
ActiveForm::end();


$js = <<< JS

    $("#js_reset-search").on('click',function(e) {
    $("#form-search_filter").trigger( 'reset' );
    $("#form-search_filter").submit();
   });
JS;
$this->registerJs($js);
?>

