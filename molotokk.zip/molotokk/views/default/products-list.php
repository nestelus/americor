<?php

/**
 * @var $searchFilter common\components\searchFilter\searchFilter
 * @var $products  molotokk\models\Products[]
 * @var $this yii\web\View
 */
use molotokk\widgets\CategoryFacetWidget;

$products = $searchFilter->getResult();
?>

<?php
//if (!empty($searchFilter->getFacet('category_id'))):
//    $this->beginBlock('facet');
//    echo CategoryFacetWidget::widget([
//        'category' => $category,
//    ]);
//    $this->endBlock();
//endif;
?>

<?php if (!empty($searchFilter->params)): ?>

    <?php
    $this->beginBlock('filter');
    ?>
    <?=
    $this->render(
        '_filter-product', [
        'searchFilter' => $searchFilter,
        ]
    )
    ?>
    <?php
    $this->endBlock();
    ?>
<?php endif; ?>

<?php
$this->params['breadcrumbs'][] = $title;
?>
<?=
$this->render(
    '_visual-form', [
    'searchFilter' => $searchFilter,
    ]
);
?>
<?=
$this->render('_products-block',
    [
    'products' => $products,
    'searchFilter' => $searchFilter,
])
?>

