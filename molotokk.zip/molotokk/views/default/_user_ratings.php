<?php

/**
 * @var $this yii\web\View
 * @var $profile common\models\Profile
 * @var $ratings common\models\auktaModels\UserRatings
 */
use molotokk\models\UserRating;
use yii\widgets\Pjax;
?>
<div class="profile-block">

    <div class="row">
        <div class="col-md-9">

            <?php
            // if (!empty($profile->getRatings()->all())) {
            $ratingsPositive = $profile->getRatings()->andWhere(['rating_type' => UserRating::RATING_POSITIVE])->all();
            $authors         = [];
            foreach ($ratingsPositive as $rating) {
                if (!in_array($rating->author_id, $authors)) {
                    $authors[] = $rating->author_id;
                }
                break;
            }
            $totalRating = ($profile->selectRatings() == 0) ? 0 : round(
                    $profile->selectRatings(UserRating::RATING_POSITIVE) / $profile->selectRatings()
                    * 100, 1
            );
            ?>
            <div
                class="user-rating-summary <?=
                ($totalRating >= 50 ? 'user-rating-summary-green' : 'user-rating-summary-red')
                ?>">
                <span><?= $totalRating ?>% Положительных отзывов</span> (<?=
                $profile->selectRatings(
                    UserRating::RATING_POSITIVE
                )
                ?> от <?=
                count(
                    $authors
                )
                ?> пользователей)
            </div>
            <table class="user-rating-table">
                <tr>
                    <th>
                        Тип отзыва
                    </th>
                    <th>
                        За последние 7 дней
                    </th>
                    <th>
                        За последние 30 дней
                    </th>
                    <th>
                        Все
                    </th>
                    <th>
                        Купил/Продал
                    </th>
                </tr>
                <tr class="good">
                    <td>
                        Положительно
                    </td>
                    <td><?=
                        $profile->selectRatings(UserRating::RATING_POSITIVE,
                            604800)
                        ?></td>
                    <td><?=
                        $profile->selectRatings(UserRating::RATING_POSITIVE,
                            2592000)
                        ?></td>
                    <td><?= $profile->selectRatings(UserRating::RATING_POSITIVE) ?></td>
                    <td>
                        <?=
                        $profile->selectRatings(
                            UserRating::RATING_POSITIVE, null,
                            UserRating::DIRECTION_FROM_BUYER
                        )
                        ?>
                        / <?=
                        $profile->selectRatings(
                            UserRating::RATING_POSITIVE, null,
                            UserRating::DIRECTION_FROM_SELLER
                        )
                        ?>
                    </td>
                </tr>
                <tr class="neutral">
                    <td>
                        Нейтрально
                    </td>
                    <td><?=
                        $profile->selectRatings(UserRating::RATING_NEUTRAL,
                            604800)
                        ?></td>
                    <td><?=
                        $profile->selectRatings(UserRating::RATING_NEUTRAL,
                            2592000)
                        ?></td>
                    <td><?= $profile->selectRatings(UserRating::RATING_NEUTRAL) ?></td>
                    <td>
                        <?=
                        $profile->selectRatings(
                            UserRating::RATING_NEUTRAL, null,
                            UserRating::DIRECTION_FROM_BUYER
                        )
                        ?>
                        / <?=
                        $profile->selectRatings(
                            UserRating::RATING_NEUTRAL, null,
                            UserRating::DIRECTION_FROM_SELLER
                        )
                        ?>
                    </td>
                </tr>
                <tr class="bad">
                    <td>
                        Отрицательно
                    </td>
                    <td><?=
                        $profile->selectRatings(UserRating::RATING_NEGATIVE,
                            604800)
                        ?></td>
                    <td><?=
                        $profile->selectRatings(UserRating::RATING_NEGATIVE,
                            2592000)
                        ?></td>
                    <td><?= $profile->selectRatings(UserRating::RATING_NEGATIVE) ?></td>
                    <td>
                        <?=
                        $profile->selectRatings(
                            UserRating::RATING_NEGATIVE, null,
                            UserRating::DIRECTION_FROM_BUYER
                        )
                        ?>
                        / <?=
                        $profile->selectRatings(
                            UserRating::RATING_NEGATIVE, null,
                            UserRating::DIRECTION_FROM_SELLER
                        )
                        ?>
                    </td>
                </tr>
            </table>

        </div>
        <!--        <div class="col-md-3 text-right">
                    <span id="js_user-message" class="profile-user-message">Отправить сообщение пользователю</span>
                </div>-->
    </div>


    <?php
    Pjax::begin(
        [
            'enablePushState' => false,
            'id' => 'pj_ratings_list',
            'timeout' => 0,
        ]
    );
    ?>
    <?=
    $this->render('ratings',
        [
        'profile' => $profile,
        'ratings' => $ratings,
        'pages' => $pages,
    ]);
    ?>
    <?php Pjax::end(); ?>

</div>
