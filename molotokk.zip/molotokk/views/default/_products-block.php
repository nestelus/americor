<?php

use common\widgets\ShortProductWidget;
use molotokk\widgets\LinkPagerWidget;
use yii\widgets\Pjax;

/**
 * @var $searchFilter common\components\searchFilter\searchFilter
 * @var $products  molotokk\models\Products[]
 * @var $this yii\web\View
 */
Pjax::begin(
    [
        'id' => 'product-list',
        'formSelector' => '.form-filter',
        'linkSelector' => '.pj_products-block',
        'timeout' => 0,
    ]
);
?>

<?php //var_dump($searchFilter->query->createCommand()->rawSql);           ?>
<?php if (empty($products)) : ?>
    <p></p>
    <p class="text-center">
        По Вашему запросу ничего не найдено.
    </p>
<?php else : ?>
    <div class="row">
        <div class="col-md-5">
            <?= $searchFilter->getFilterCount() ?>
        </div>
        <div class="col-md-4 col-md-offset-3">
            <?=
            LinkPagerWidget::widget(
                [
                    'pagination' => $searchFilter->getPagination(),
                    'firstPageLabel' => false,
                    'lastPageLabel' => true,
                    'nextPageLabel' => '&gt;',
                    'prevPageLabel' => '&lt;',
                    'maxButtonCount' => 3,
                ]
            );
            ?>
        </div>
    </div>
    <?=
    ShortProductWidget::widget(
        [
            'products' => $products,
            'mode' => $searchFilter->mode,
        ]
    );
    ?>
    <div class="row">
        <div class="col-md-5">
            <?= $searchFilter->getFilterCount() ?>
        </div>
        <div class="col-md-4 col-md-offset-3">
            <?=
            LinkPagerWidget::widget(
                [
                    'pagination' => $searchFilter->getPagination(),
                    'firstPageLabel' => false,
                    'lastPageLabel' => true,
                    'nextPageLabel' => '&gt;',
                    'prevPageLabel' => '&lt;',
                    'maxButtonCount' => 3,
                ]
            );
            ?>
        </div>
    </div>
<?php endif; ?>
<?php Pjax::end(); ?>
<?php
$js = <<< JS
  $("form.form-filter").on('submit',function(e) {
        $.pjax(
        {
            url:  "?" + $("form.form-filter, form.sphinx-search" ).serialize(),
            container: "#product-list"
        });
        return false;
   });
JS;
$this->registerJs($js);
