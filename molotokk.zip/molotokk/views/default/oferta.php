<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<p style="text-align: center;"><strong><span style="color:rgb(34, 34, 34); font-family:helvetica neue,helvetica,arial,liberation sans,freesans,sans-serif; font-size:15px">Принятием условий настоящего Соглашения считается факт использования сайта Пользователем и наступает в момент начала такого использования.</span></strong></p>

<p style="text-align: justify;"><br />
    <span style="color:rgb(34, 34, 34); font-family:helvetica neue,helvetica,arial,liberation sans,freesans,sans-serif; font-size:15px">Продавец обязуется не выставлять на продажу товары (а также не предлагать в качестве бесплатного дополнения к лотам на каких-либо условиях), реализация которых нарушает действующее законодательство РФ или права третьих лиц (включая авторские и иные права на интеллектуальную собственность) и самостоятельно несет ответственность за такие действия.</span><br />
    <br />
    <span style="color:rgb(34, 34, 34); font-family:helvetica neue,helvetica,arial,liberation sans,freesans,sans-serif; font-size:15px">Администрация торговой площадки имеет право блокировать, удалять, редактировать любую информацию на сайте Aukta.ru, включая учетные записи пользователей, по причине нарушения пользователем пунктов настоящего Соглашения или в иных ситуациях по собственному усмотрению администрации торговой площадки.</span><br />
    <br />
    <span style="color:rgb(34, 34, 34); font-family:helvetica neue,helvetica,arial,liberation sans,freesans,sans-serif; font-size:15px">Торговая площадка не является стороной сделки между Продавцом и Покупателем, не участвует в правоотношениях между ними и не несет ответственности за их действия либо бездействие.</span><br />
    <br />
    <span style="color:rgb(34, 34, 34); font-family:helvetica neue,helvetica,arial,liberation sans,freesans,sans-serif; font-size:15px">Торговая площадка не несет ответственность за достоверность информации, размещаемой Пользователями на Aukta.ru, а также за правомерность ее размещения.</span><br />
    <br />
    <span style="color:rgb(34, 34, 34); font-family:helvetica neue,helvetica,arial,liberation sans,freesans,sans-serif; font-size:15px">Всю ответственность за правомерность публикацию фото, названия и описания лота несет непосредственно продавец.</span></p>
