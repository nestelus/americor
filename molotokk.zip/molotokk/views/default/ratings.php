<?php

/**
 * @var $profile common\models\Profile
 * @var $ratings common\models\auktaModels\UserRatings
 */
use yii\bootstrap\ActiveForm;
use yii\helpers\Html;
use yii\widgets\LinkPager;

$rating_directions = [
    'all' => 'Все',
    'from_seller' => 'От продавцов',
    'from_buyer' => 'От покупателей',
    'from_author' => 'Отзывы от '.$profile->user->username,
];
$rating_types      = [
    null => 'Все',
    1 => 'Положительные',
    0 => 'Нейтральные',
    -1 => 'Отрицательные',
];
?>
<div class="visual-form recall-block">
    <div class="recall-bookmarks-block fb clearfix">
        <?php
        $form              = ActiveForm::begin(
                [
                    'action' => '/profile/ratings/',
                    'id' => 'rating-form',
                    'options' => [
                        'data-pjax' => 1,
                    ],
                ]
        );
        ?>
        <?=
        Html::radioList(
            'rating_direction',
            isset($selection['rating_direction']) ? $selection['rating_direction']
                    : 'all', $rating_directions,
            [
            'id' => 'change-state_id',
            'class' => 'feedbacks-button pull-left',
            'data-toggle' => 'buttons',
            'item' => function ($index, $label, $name, $checked, $value) {
                unset($index);

                return '<label class="btn btn-default'.($checked ? ' active' : '').'">'.
                    Html::radio(
                        $name, $checked,
                        ['value' => $value, 'class' => 'project-status-btn']
                    ).$label.'</label>';
            },
                ]
            );
            ?>
            <div class="pull-right" style="width:155px;margin-right:20px;">

                <?=
                Html::dropDownList('rating_type',
                    isset($selection['rating_type']) ? $selection['rating_type']
                            : null, $rating_types,
                    [
                    'class' => 'form-control',
                    'id' => 'feedback-type',
                    ]
                );
                ?>
                <?=
                Html::hiddenInput('user_id', $profile->user->id);
                ?>
            </div>
            <div id="feedback" class="pull-right" style="padding-top:7px;margin-right:10px;">
                <label for="feedback-type">Тип отзывов</label>
            </div>
            <?php ActiveForm::end(); ?>
        </div>
        <?php
        $js = <<< JS
        $("#rating-form").change(function(){
              $(this).submit();
        });
JS;
        $this->registerJs($js);
        ?>

    </div>
    <?=
    $this->render('_table-ratings', [
        'ratings' => $ratings,
    ])
    ?>
    <?=
    LinkPager::widget([
        'pagination' => $pages,
    ]);
    ?>

