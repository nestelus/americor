<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\Url;
use common\models\auktaModels\UserRatings;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */


$this->params['breadcrumbs'][] = $title;
?>
<div class="delivery-types-index">

  <h1><?= Html::encode($title) ?></h1>
  <?=
  GridView::widget([
      'dataProvider' => $dataProvider,
      'summary' => false,
      'columns' => [
          [
              'label' => 'Лот',
              'enableSorting' => false,
              'content' => function ($model, $key, $index, $column)
              {
                    return Html::a($model->name, $model->getUrl());
              },
          ],
          [
              'attribute' => 'complete_at',
              'format' => ['date', 'php:d/m/Y H:i'],
              'enableSorting' => false,
          ],
          [
              'label' => 'Цена продажи',
              'content' => function ($model, $key, $index, $column)
              {
                    return number_format($model->price, 0, '.', ' ').'  '.Yii::$app->params['currency'];
              }
          ],
          [
              'label' => 'Продавец',
              'content' => function ($model, $key, $index, $column)
              {
                    return Html::a($model->user->username, Url::to(['@web/profile/view', 'id' => $model->user_id]));
              },
              ],
          ],
          ]
      )
      ?>




</div>
