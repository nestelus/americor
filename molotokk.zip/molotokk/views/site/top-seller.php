<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\helpers\Url;
use common\models\auktaModels\UserRatings;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title                   = Yii::t('user', 'Toп Продавцов');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="delivery-types-index">

  <h1><?= Html::encode($this->title) ?></h1>
  <?=
  GridView::widget([
      'dataProvider' => $dataProvider,
      'columns' => [
          [
              'label' => 'Пользователь',
              'attribute' => 'username',
              'enableSorting' => false,
              'content' => function ($model, $key, $index, $column)
              {
                    return Html::a($model['username'], Url::to(['/profile/view', 'id' => $model['id']]));
              }
              ],
              [
                  'label' => 'Рейтинг продавца',
                  'enableSorting' => false,
                  'content' => function ($model, $key, $index, $column)
                  {
                        return $model->profile->selectRatings(null, null, $direction = UserRatings::DIRECTION_FROM_BUYER, $result    = 'sum');
                  }
              ],
              [
                  'label' => 'За неделю',
                  'enableSorting' => false,
                  'content' => function ($model, $key, $index, $column)
                  {
                        $delta     = $model->profile->selectRatings(null, 608400, $direction = UserRatings::DIRECTION_FROM_BUYER, $result    = 'sum')? : 0;
                        if ($delta > 0)
                        {
                              return '<span class = "feedbacks pos">+'.$delta.'</span><span class = "glyphicon glyphicon-arrow-up"></span>';
                        }
                        if ($delta < 0)
                        {
                              return '<span class = "feedbacks neg">'.$delta.'</span><span class = "glyphicon glyphicon-arrow-down"></span>';
                        }
                        return '<span class = "feedbacks neu">'.$delta.'</span>';
                  }
              ]
          ]
      ])
      ?>




</div>
