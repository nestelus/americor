<?php

use yii\helpers\Html;
use himiklab\colorbox\Colorbox;

/* @var $this yii\web\View */
$this->title                   = 'About';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="site-about">
  <h1><?= Html::encode($this->title) ?></h1>

  <p class="colorbox">This is the About page. You may modify the following file to customize its content:</p>

  <?=
  Colorbox::widget([
      'targets'   => [
          '.colorbox' => [
              'maxWidth'  => 800,
              'maxHeight' => 600,
          ],
      ],
      'coreStyle' => 2
  ])
  ?>
</div>
