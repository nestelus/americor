<?php
/* @var $this yii\web\View */
/* @var $products molotokk/models/Products[] */

use yii\helpers\Html;
use yii\bootstrap\Carousel;
use evgeniyrru\yii2slick\Slick;

$this->title = 'AUKTA.RU';


// хранилище банеров 1

$baners1[] = Html::a(Html::img('@static/img/one-rouble.jpg'),
        '/products/one-rouble/');
$baners2[] = Html::a(Html::img('@static/img/baner2.jpg'), '/landing/import/');
$baners3[] = Html::a(Html::img('@static/img/baner3.jpg'),
        '/landing/free-delivery/');


/*
 * Получаем элементы для слайдера
 */
foreach ($slider1 as $slide) {
    $photo = $slide->getProductPhotos()->one();
    if ($photo) {
        $slide1_items[] = Html::a(Html::img($photo->getUrlPhoto(null, 100),
                    [
                    'class' => 'product-image-preview',
                ]), $slide->getUrl());
    }
}
foreach ($slider2 as $slide) {
    $photo = $slide->getProductPhotos()->one();
    if ($photo) {
        $slide2_items[] = Html::a(Html::img($photo->getUrlPhoto(null, 100),
                    [
                    'class' => 'product-image-preview',
                ]), $slide->getUrl());
    }
}
?>

<div class = "row">
    <div class="col-lg-12">
        <?=
        Carousel::widget([
            'id' => 'baner-main',
            'items' => $baners1,
            'controls' => false,
            'showIndicators' => false,
        ]);
        ?>
    </div>
</div>

<div class="row">

    <div class = "col-lg-12">
        <?php if (!empty($slide1_items)) : ?>
            <h3>Популярные лоты</h3>


            <?=
            Slick::widget([

                // HTML tag for container. Div is default.
                'itemContainer' => 'div',
                // HTML attributes for widget container
                'containerOptions' => ['class' => 'carousel'],
                // Items for carousel. Empty array not allowed, exception will be throw, if empty
                'items' => $slide1_items,
                // HTML attribute for every carousel item
                'itemOptions' => ['class' => 'cat-image'],
                // settings for js plugin
                // @see http://kenwheeler.github.io/slick/#settings
                'clientOptions' => [
                    'lazyLoad' => 'ondemand',
                    'autoplay' => true,
                    'adaptiveHeight' => true,
                    'variableWidth' => true,
//                    'responsive' => [
//                        [
//                            'breakpoint' => 1200,
//                            'settings' => [
//                                'slidesToShow' => 6,
//                                'slidesToScroll' => 3,
//                            ],
//                        ],
//                        [
//                            'breakpoint' => 920,
//                            'settings' => [
//                                'slidesToShow' => 5,
//                                'slidesToScroll' => 2,
//                            ],
//                        ],
//                        [
//                            'breakpoint' => 768,
//                            'settings' => [
//                                'slidesToShow' => 4,
//                                'slidesToScroll' => 1,
//                            ],
//                        ],
//                    ],
                    'arrows' => false,
                    'dots' => true,
                    'speed' => 300,
                    'autoplay' => true,
                    'infinite' => true,
                    'respondTo' => 'slider',
                    'centerMode' => true,
                ],
            ]);
            ?>
        <?php endif; ?>
    </div>


</div>
<div class="row">
    <div class="col-lg-7 col-md-7 col-sm-7 col-xs-7">
        <?=
        Carousel::widget([
            'id' => 'baner-right',
            'items' => $baners2,
            'controls' => false,
            'showIndicators' => false,
        ]);
        ?>
    </div>
    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-5">
        <?=
        Carousel::widget([
            'id' => 'baner-left',
            'items' => $baners3,
            'controls' => false,
            'showIndicators' => false,
        ]);
        ?>
    </div>
</div>
<div class="row">
    <?php if (!empty($slide2_items)) : ?>
        <div class = "col-lg-12">
            <h3>Скоро завершатся</h3>
            <?=
            Slick::widget([
                // HTML tag for container. Div is default.
                'itemContainer' => 'div',
                // HTML attributes for widget container
                'containerOptions' => ['class' => 'carousel'],
                // Items for carousel. Empty array not allowed, exception will be throw, if empty
                'items' => $slide2_items,
                // HTML attribute for every carousel item
                'itemOptions' => ['class' => 'cat-image'],
                // settings for js plugin
                // @see http://kenwheeler.github.io/slick/#settings
                'clientOptions' => [
                    'lazyLoad' => 'ondemand',
                    'autoplay' => true,
                    'adaptiveHeight' => true,
                    'variableWidth' => true,
                    'dots' => true,
                    'speed' => 300,
                    'autoplay' => true,
                    'infinite' => true,
//                    'responsive' => [
//                        [
//                            'breakpoint' => 1200,
//                            'settings' => [
//                                'slidesToShow' => 6,
//                                'slidesToScroll' => 3,
//                            ],
//                        ],
//                        [
//                            'breakpoint' => 920,
//                            'settings' => [
//                                'slidesToShow' => 5,
//                                'slidesToScroll' => 2,
//                            ],
//                        ],
//                        [
//                            'breakpoint' => 768,
//                            'settings' => [
//                                'slidesToShow' => 4,
//                                'slidesToScroll' => 1,
//                            ],
//                        ],
//                    ],
                    'arrows' => false,
                    'respondTo' => 'slider',
                    'centerMode' => true,
                ],
            ]);
            ?>

        </div>
    <?php endif; ?>
