<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $name string */
/* @var $message string */
/* @var $exception Exception */

$this->title = $name;
?>
<div class="site-error">

  <h1>Ой! Кажется ошибка :-(</h1>

  <div class="alert alert-danger">
    <?= nl2br(Html::encode($message)) ?>
  </div>

  <p>
    Данная страница не может быть отображена. Наши специалисты уже работают над этой проблемой.
    Благодарим за понимание
  </p>


</div>
