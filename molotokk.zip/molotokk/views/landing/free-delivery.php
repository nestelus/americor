<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use yii\bootstrap\Html;
use yii\widgets\ActiveForm;
use kartik\widgets\Select2;
use common\models\auktaModels\enumModels\StateProduct;
use molotokk\models\Products;
use yii\helpers\ArrayHelper;
use yii\widgets\MaskedInput;

$this->title = "Бесплатная доставка";
?>

<h1><?= $this->title ?></h1>
<div class="row">
    <p><?= Html::img('http://static.aukta.ru/img/free-delivery.jpg') ?></p>
</div>

<div class="row">
    <p>Пользователям из Москвы и Санкт-Петербурга мы предлагаем специальную услугу - бесплатная доставка!</p>
    <p>
        Мы бережно перевезем проданные на Aukta лоты из одного города в другой. Вы просто привозите лот в наш 
        пункт самовывоза и через несколько дней покупатель вашего лота сможет забрать его в пункте самовывоза уже в 
        своем городе.
    </p>
    <p>Для отправки лота необходимо выполнение следующих условий:</p>
    <ul>
        <li>
            Лот был продан на Aukta.ru
        </li>
        <li>
            Вы самостоятельно упаковали лот в картонную коробку со всеми мерами предосторожности, то есть в пункт 
            самовывоза вы привозите готовую к отправке посылку.
        </li>
    </ul>
    <p>Для получения лота необходимо будет предъявить паспорт.</p>
    <p>Отправка из Санкт-Петербурга производится по понедельникам, во вторник товар будет в Москве. Во вторник товары 
        из Москвы отправляются в Санкт-Петербург. Что бы во вторник ваш товар был в Москве, необходимо привезти его в 
        пункт самовывоза в Санкт-Петербурге не позднее пятницы 19:00. Соответственно что бы ваш товар был в 
        Санкт-Петербурге в среду, необходимо привезти его в пункт самовывоза в Москве не позднее 19:00
    </p>
    <p>Важно: Адреса пунктов самовывоза:</p>
    <ul>
        <li>Москва:<em> Волгоградский пр., 32, корпус 36</em></li>
        <li>Санкт-Петербург: <em>пр. Мориса Тореза, 35 корпус 3</em></li>
    </ul>
</div>

<?php if ($user->isGuest): ?>
    <p class="lead">
        Чтобы воспользоваться данным предложением <?= Html::a('Войдите',
        '/user/security/login/') ?>
        или <?= Html::a('Зарегистрируйтесь', '/user/registration/register/') ?>
    </p>
<?php else: ?>
    <p class="lead">
        Заполните эту форму, чтобы получить бесплатную доставку между Москвой и Санкт-Петербургом.
    </p>
    <div class="row">
        <?php
        $lots = ArrayHelper::map(Products::find()->where(['user_id' => $user->id])
                    ->andWhere(['state_id' => StateProduct::STATE_ON_SOLD])->all(),
                'id', 'name');
        $form = ActiveForm::begin([
                'options' => ['class' => 'form-horizontal'],
                'fieldConfig' => [
                    'template' => "{label}\n<div class=\"col-sm-6\">{input}<div>{error}\n{hint}</div></div>\n",
                    'labelOptions' => ['class' => 'col-sm-2 control-label'],
                ],
            ])
        ?>
        <?= $form->field($model, 'name') ?>
        <?=
        $form->field($model, 'phone')->widget(MaskedInput::className(),
            [
            'mask' => '+9 (999) 999-99-99',
        ])
        ?>
        <?=
        $form->field($model, 'direction')->dropDownList([
            'Из Москвы в Санкт-Петербург' => 'Из Москвы в Санкт-Петербург',
            'Из Санкт-Петербурга в Москву' => 'Из Санкт-Петербурга в Москву',
            ], ['prompt' => 'Укажите направление доставки...'])
        ?>
        <?=
        $form->field($model, 'num_lots')->widget(Select2::className(),
            [
            'data' => $lots,
            'options' => [],
            'pluginOptions' => [
                'allowClear' => true,
                'multiple' => true,
            ],
        ])
        ?>

            <?= $form->field($model, 'comment')->textarea(); ?>
        <div class="clearfix"></div>
        <div class="col-sm-offset-2">
    <?= Html::submitButton('Отправить',
        ['class' => 'btn btn-danger']) ?>
        </div>
    <?php ActiveForm::end() ?>
    </div>

    <p>&nbsp;</p>
<?php endif; ?>
