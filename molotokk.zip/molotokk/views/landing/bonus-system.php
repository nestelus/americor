<?php
/* @var $this yii\web\View */

use yii\bootstrap\Html;
use yii\widgets\ActiveForm;
use kartik\widgets\Select2;
use common\models\auktaModels\enumModels\StateProduct;
use molotokk\models\Products;
use yii\helpers\ArrayHelper;
use yii\widgets\MaskedInput;

$this->title = "Дарим бонусы активным";
?>
<h1><?= $this->title ?></h1>

<p><?= Html::img('http://static.aukta.ru/img/bonus-system.jpg') ?></p>

<p>
    Мы уверены, все необходимое для покупки и продажи должно быть доступным! Мы любим активны пользователей и 
    специально для них запускаем новую акцию - "Дарим бонусы активным". Здесь только полезные и нужные вознаграждения:
</p>
<ul>
    <li>
        <p>
            <b>Бонус №1</b> - Подключим рекламные опции для одного вашего лота за <b>25</b> выставленных на продажу 
            лотов. В состав рекламной опции входит: выделение лота подсветкой, выделение названия лота, лот поднят 
            вверх списка.
        </p>
    </li>
    <li>
        <p>
            <b>Бонус №2</b> - Подарим 10%-ую скидку на покупку в магазине нашего партнера ScaleCar.ru за <b>100</b> 
            выставленных на продажу лотов.
        </p>
    </li>
    <li>
        <p>
            <b>Бонус №3</b> - Добавим от 1 до 3 ваших лотов в рекламную рассылку по базе наших подписчиков за 
            <b>150</b> выставленных на продажу лотов.
        </p>
    </li>
</ul>
<p>
    Важно: каждый лот может быть использован для получения бонуса только 1 раз.
</p>

<?php if ($user->isGuest): ?>
    <p class="lead">
        Чтобы воспользоваться данным предложением <?= Html::a('Войдите', '/user/security/login/') ?>
        или <?= Html::a('Зарегистрируйтесь', '/user/registration/register/') ?>
    </p>
<?php else: ?>
    <p class="lead">
        Для того, что бы принять участие в акции, отправьте заявку. Заявка распространяется на один бонус.
    </p>
    <p>
        Если Вы хотите получить несколько бонусов, отправьте на каждый бонус отдельную заявку.
    </p>
    <div class="row">
        <?php
            $lots = ArrayHelper::map(Products::find()->where(['user_id' => $user->id])->andWhere(['state_id' => [StateProduct::STATE_ON_SALE, StateProduct::STATE_ON_AUCTION]])->all(), 'id', 'name');
            $form = ActiveForm::begin([
                'options'     => ['class' => 'form-horizontal'],
                'fieldConfig' => [
                    'template'     => "{label}\n<div class=\"col-sm-6\">{input}<div>{error}\n{hint}</div></div>\n",
                    'labelOptions' => ['class' => 'col-sm-2 control-label'],
                ],
            ])
        ?>
        <?= $form->field($model, 'name') ?>
        <?=
        $form->field($model, 'bonuses')->dropDownList([
                '1' => 'Выделение лота и поднятие вверх списка (за 10 лотов)',
                '2' => '10% скидка на ScaleCar.ru (за 20 лотов)',
                '3' => 'Рассылка лота в рекламной рассылке (за 30 лотов)'
                //'4' => 'Контекстная/таргетрованная реклама лота (за 40 лотов)',
            ], [
            'prompt' => 'Укажите желаемый бонус...',
        ]);
        ?>
        <?=
        $form->field($model, 'num_lots')->widget(Select2::className(), [
            'data'          => $lots,
            'options'       => [
                'prompt' => 'Укажите лот для акции...',
            ],
            'pluginOptions' => [
                'allowClear' => true,
            ],
        ])
        ?>
        <?= $form->field($model, 'comment')->textarea(); ?>
        
        <div class="clearfix"></div>
        <div class="col-sm-offset-2">
            <?= Html::submitButton('Отправить', ['class' => 'btn btn-danger ']) ?>
        </div>
        <?php ActiveForm::end() ?>
    </div>
    
    <p>&nbsp;</p>
<?php endif; ?>

<?php
$js = <<<JS
$("#landingform-bonuses").change(function(){
    if($(this).val() == 2){
        $(".field-landingform-num_lots").hide();
    } else {
        $(".field-landingform-num_lots").show();
    }
});
JS;
$this->registerJs($js);
?>