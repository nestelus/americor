<?php
/* @var $this yii\web\View */

use yii\bootstrap\Html;
use yii\widgets\ActiveForm;
$this->title = "Перенесем ваши лоты на Aukta.ru с других торговых площадок";
?>
<h1>Лучшие условия</h1>
<p><?= Html::img('http://static.aukta.ru/img/import.jpg') ?></p>

<p>
    Мы уделяем большое внимание удобству покупок на Aukta.
</p>
<p>
    Это значит, что у нас нет ограничений на покупку и продажу, нет комиссии,
    нет платной рекламы, а на любой ваш вопрос мы ответим в день обращения.
    Мы сделали торговую площадку доступной и теперь помогаем с размещением,
    доставкой и даже продвижением. Это сложнее, но дает интересный результат.
</p>

<?php if ($user->isGuest): ?>
    <p class="lead">
        Чтобы воспользоваться данным предложением <?= Html::a('Войдите', '/user/security/login/') ?>
        или <?= Html::a('Зарегистрируйтесь', '/user/registration/register/') ?>
    </p>
<?php else: ?>
    <p class="lead">
        Просто заполните форму и мы перенесем ваши лоты без всяких дополнительных вопросов!
    </p>

    <div class="row">
        <?php
            $form = ActiveForm::begin([
                'options'     => ['class' => 'form-horizontal'],
                'fieldConfig' => [
                    'template'     => "{label}\n<div class=\"col-sm-6\">{input}<div>{error}\n{hint}</div></div>\n",
                    'labelOptions' => ['class' => 'col-sm-2 control-label'],
                ],
            ])
        ?>
        <?= $form->field($model, 'name') ?>
        <?= $form->field($model, 'comment')->textarea()->hint('В сообщении укажите площадку, с которой вы хотите перенести лоты и ваш псевдоним на этой площадке'); ?>
        
        <div class="clearfix"></div>
        <div class="col-sm-offset-2">
            <?= Html::submitButton('Отправить', ['class' => 'btn btn-danger']) ?>
        </div>
        <?php ActiveForm::end() ?>
    </div>
    
    <p>&nbsp;</p>
<?php endif; ?>
