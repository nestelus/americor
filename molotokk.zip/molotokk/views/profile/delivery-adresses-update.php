<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model molotokk\models\DeliveryAdresses */

$this->title = 'Редактировать адрес доставки:'.' '.$model->name;
?>
<div class="delivery-adresses-update">

    <h1><?= Html::encode($this->title) ?></h1>



    <?=
    $this->render('delivery-adresses_form', [
        'model' => $model,
    ])
    ?>


</div>
