<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title                   = Yii::t('products', 'Payment Types');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="payment-types-index">
  <div class="panel panel-default">
    <div class="panel-heading">
      <?= Html::encode($this->title) ?>
    </div>
    <div class="panel-body">
      <?php
      $form                          = ActiveForm::begin([
              'action' => '/user/settings/payment-type-update/',
              'options' => [
                  'id' => 'js_pay-system-form',
              ]
          ])
      ?>
      <?php
      foreach ($payment_systems as $system) :
            $checked = in_array($system->id, $payment_types);
            ?>
            <div class="row">
              <div class="col-md-1">
                <?=
                Html::checkbox('Pay_sys[]', $checked, [
                    'class' => 'js_paysys',
                    'value' => $system->id,
                ])
                ?>
              </div>
              <div class="col-md-5">
                <?= $system->name ?>
              </div>
              <div class="col-md-5">
                <?=
                Html::img('/img/payments/'.$system->logo, [
                    'width' => '100',
                    'height' => '50',
                ]);
                ?>
              </div>
            </div>

      <?php endforeach; ?>
      <?php ActiveForm::end(); ?>
    </div>
  </div>
</div>
<?php
$js = <<< JS

 $(".js_paysys").change(function(){
        var form = $('#js_pay-system-form');
        var m_method=form.attr('method');
            //получаем адрес скрипта на сервере, куда нужно отправить форму
      var m_action=form.attr('action');
            //получаем данные, введенные пользователем в формате input1=value1&input2=value2...,
            //то есть в стандартном формате передачи данных формы
      var m_data=form.serialize();
            $.ajax({
                  type: m_method,
                  url: m_action,
                  data: m_data,
                  success: function(result){
                  $('#test_form').html(result);
            }
      });
      });

JS;
$this->registerJs($js);
