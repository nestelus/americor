<?php

use yii\helpers\Html;
use common\components\NCActiveForm as ActiveForm;
use Yii;
use common\models\auktaModels\enumModels\DeliveryType;

/* @var $this yii\web\View */
/* @var $model molotokk\models\DeliveryTypes */
/* @var $form yii\widgets\ActiveForm */
?>
<style>
    div.required label:after {
        content: " *";
        color: red;
    }
</style>
<div class="delivery-types-form">

    <?php
    $form = ActiveForm::begin([
                'options' => [
                    'id' => 'form-new-delivery-type',
                ]
    ]);
    ?>




    <?= $form->field($model, 'name')->textInput(['maxlength' => 255]) ?>

    <?= $form->field($model, 'type_id')->dropDownList(DeliveryType::getLabels()) ?>

    <?= $form->field($model, 'cost') ?>

    <?= $form->field($model, 'term') ?>

    <?= $form->field($model, 'conditional')->textarea(['rows' => 6]) ?>

    <?= $form->field($model, 'is_default')->checkbox() ?>

    <div class="form-group">
        <?=
        Html::submitButton($model->isNewRecord ? Yii::t('general', 'Добавить') : Yii::t('general', 'Сохранить'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary'])
        ?>
    </div>

<?php ActiveForm::end(); ?>

</div>
