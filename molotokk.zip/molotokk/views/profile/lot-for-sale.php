<?php

/**
 * @var $searchFilter common\components\searchFilter\searchFilter
 * @var $products molotokk\models\Products[]
 * @var $this yii\web\View
 * @var $profile common\models\Profile
 */
use common\models\auktaModels\Categories;
use common\models\auktaModels\enumModels\StateProduct;
use molotokk\widgets\CategoryFacetWidget;

$products     = $searchFilter->getResult();
?>

<div class="profile-block">
    <div class="panel panel-body">
        <div class="row">
            <div class="col-md-3">
                <?php
                $categoriesId = [];
                //$categories   = [];
                $categories   = Categories::find()->joinWith(
                        [
                            'products' => function (\yii\db\ActiveQuery $query) use ($profile) {
                                $query->andWhere(
                                    [
                                        'user_id' => $profile->user_id,
                                        'state_id' => [StateProduct::STATE_ON_AUCTION,
                                            StateProduct::STATE_ON_SALE],
                                    ]
                                );
                            },
                            ]
                        )->all();
                    ?>
                    <?=
                    CategoryFacetWidget::widget(
                        [
                            'category' => $categories,
                            'dataAsIs' => true,
                        ]
                    )
                    ?>
                    <?=
                    $this->render(
                        '_filter-product',
                        [
                        'searchFilter' => $searchFilter,
                        ]
                    )
                    ?>
                </div>
                <div class="col-md-9">
                    <?=
                    $this->render(
                        '_visual-form',
                        [
                        'searchFilter' => $searchFilter,
                        ]
                    );
                    ?>
                    <?=
                    $this->render(
                        '_products-block',
                        [
                        'products' => $products,
                        'searchFilter' => $searchFilter,
                        ]
                    )
                    ?>
            </div>
        </div>
    </div>
</div>


