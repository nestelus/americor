<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model molotokk\models\DeliveryAdresses */

$this->title = 'Добавить адрес доставки';
?>
<div class="delivery-adresses-create">

    <h1><?= Html::encode($this->title) ?></h1>

    <?=
    $this->render('delivery-adresses_form', [
        'model' => $model,
    ])
    ?>


</div>
