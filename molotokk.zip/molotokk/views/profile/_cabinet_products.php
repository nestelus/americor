<?php

/**
 * @var \molotokk\models\Profile $profile
 * @var array $settings
 * @var yii\web\View $this
 */
use yii\bootstrap\Nav;
use yii\widgets\Pjax;

$controller = $this->context;
foreach ($tabs as $url => $label) {
    $sections[] = [
        'label' => $label,
        'url' => [$controller->id.'/'.$controller->action->id, 'tab' => $url],
        'options' => [
            'class' => 'list-group-item ',
        ],
        'linkOptions' => [
            'class' => 'pj_products-block',
        ],
        'active' => ($tab == $url),
    ];
}
?>
<div class="profile-block">
    <div class="panel panel-body">
        <div class="row">
            <div class="col-md-3 col-lg-3 col-sm-4">

                <?=
                Nav::widget([
                    'items' => $sections,
                    'options' => [
                        'class' => 'list-group category_facet_ul',
                    ],
                ])
                ?>
                <?php if (!empty($searchFilter->params)): ?>
                    <?=
                    $this->render(
                        '_filter-product',
                        [
                        'searchFilter' => $searchFilter,
                        ]
                    )
                    ?>

                <?php endif; ?>
            </div>
            <?php
//            Pjax::begin(
//                [
//                    'id' => 'pj_cabinet',
//                    'linkSelector' => '.pj_products-block',
//                    'timeout' => 0,
//                ]
//            );
            ?>
            <div class="col-md-9 col-lg-9 col-sm-8">
                <?=
                $this->render(
                    '_visual-form',
                    [
                    'searchFilter' => $searchFilter,
                    ]
                );
                ?>
                <?=
                $this->render(
                    '_products-block',
                    [
                    'products' => $searchFilter->getResult(),
                    'searchFilter' => $searchFilter,
                    ]
                )
                ?>
            </div>
            <?php
//            Pjax::end();
            ?>
        </div>
    </div>
</div>
