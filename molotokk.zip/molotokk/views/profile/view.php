<?php
/* @var $this yii\web\View */

/**
 * @var $profile common\models\Profile
 * @var $user common\models\User
 * @var $ratings common\models\auktaModels\UserRatings[]
 * @var $searchFilter common\components\searchFilter\searchFilter
 */
use yii\bootstrap\Nav;
use yii\helpers\Html;

$this->params['breadcrumbs'] = '';
$this->title                 = empty($profile->name) ? Html::encode($profile->user->username)
        : Html::encode($profile->name);


$tab_items[] = [
    'label' => 'Мои покупки',
    'url' => ['/profile/buys'],
    'linkOptions' => [
        'class' => 'pjax-cabinet',
    ],
    'visible' => Yii::$app->user->id == $profile->user_id,
];
$tab_items[] = [
    'label' => 'Мои продажи',
    'url' => ['/profile/sales'],
    'linkOptions' => [
        'class' => 'pjax-cabinet',
    ],
    'visible' => Yii::$app->user->id == $profile->user_id,
];
$tab_items[] = [
    'label' => 'Мои настройки',
    'url' => ['/user/settings'],
    'linkOptions' => [
        'class' => 'pjax-cabinet',
    ],
    'visible' => Yii::$app->user->id == $profile->user_id,
];
$tab_items[] = [
    'label' => 'Сообщения',
    'url' => ['/messages/messages'],
    'linkOptions' => [
        'class' => 'pjax-cabinet',
    ],
    'visible' => Yii::$app->user->id == $profile->user_id,
];


$tab_items[] = [
    'label' => 'Отзывы',
    'url' => [
        '/profile/view',
        'id' => $profile->user_id,
    ],
];
$tab_items[] = [
    'label' => 'Лоты в продаже',
    'encode' => false,
    'url' => [
        '/profile/products-list',
        'id' => $profile->user_id,
    ],
];
$tab_items[] = [
    'label' => 'Страница "Обо мне"',
    'url' => [
        '/profile/about',
        'id' => $profile->user_id,
    ],
];
?>
<div class="profile-block">
    <div class="row">
        <div class="profile-username col-lg-6 col-md-6 col-sm-6">
            <?= $user->username ?>
            <span>(<?= $profile->rating ?> | <span class="m-rating"><?=
                    $profile->m_rating ? : 0
                    ?></span>)</span>
        </div>
        <div class="col-lg-6 col-md-6 col-sm-6 profile-dates">
            <div class="text-right">
                Зарегистрирован:
                <span>
                    <?=
                    Yii::t('user', '{0, date, dd.MM.YYYY HH:mm}',
                        [$user->created_at])
                    ?>
                </span>
            </div>
            <div class="text-right">
                Последнее посещение:
                <span>
                    <?=
                    $user->last_at ? Yii::t(
                            'user', '{0, date, dd.MM.YYYY HH:mm}',
                            [$user->last_at]
                        ) : 'никогда'
                    ?>
                </span>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12">
            <?=
            Nav::widget(
                [
                    'id' => 'tabs-profile',
                    'options' => [
                        'class' => 'nav nav-tabs',
                    ],
                    'items' => $tab_items,
                ]
            )
            ?>
        </div>
    </div>
</div>
<?= $this->render($view, $view_params) ?>
