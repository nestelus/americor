<?php

use yii\helpers\Html;
use yii\grid\GridView;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Адреса доставки';
?>
<div class="delivery-adresses">
    <h1><?= Html::encode($this->title) ?></h1>

    <div class="panel panel-default">



        <div class="panel-body">
            <p>
                <?=
                Html::a('Добавить адрес доставки', ['delivery-adresses-create'],
                    ['class' => 'btn btn-success'])
                ?>
            </p>
            <?=
            GridView::widget([
                'dataProvider' => $dataProvider,
                'columns' => [
                    ['class' => 'yii\grid\SerialColumn'],
                    [
                        'class' => 'yii\grid\ActionColumn',
                        'template' => '{update} {delete}',
                        'urlCreator' => function($action, $model, $key, $index) {
                            return "/user/settings/delivery-adresses-$action/$model->id/";
                        },
                    ],
                    'name',
                    'fio',
                    [
                        'label' => 'Регион',
                        'attribute' => 'region.name',
                        'enableSorting' => true,
                    ],
                    'city',
                    'address',
                    'zip',
                    'phone',
                    [
                        'label' => 'По умолчанию',
                        'attribute' => 'is_default',
                        'value' => function ($model, $key, $index, $column) {
                            return $model->is_default ? 'Да' : 'Нет';
                        },
                    ]
                ],
            ]);
            ?>

        </div>
    </div>
</div>
