<?php

use yii\helpers\Html;
use common\components\NCActiveForm as ActiveForm;
use common\models\auktaModels\enumModels\PaymentType;

/* @var $this yii\web\View */
/* @var $model molotokk\models\PaymentTypes */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="payment-types-form">

  <?php $form = ActiveForm::begin(); ?>

  <?php if (empty($model->user_id)): ?>
        <?= $form->field($model, 'user_id')->hiddenInput(['value' => Yii::$app->getUser()->id]) ?>
  <?php endif; ?>

  <?= $form->field($model, 'name')->textInput(['maxlength' => 255]) ?>

  <?= $form->field($model, 'type_id')->dropDownList(PaymentType::getLabels()) ?>

  <?= $form->field($model, 'requisite')->textarea(['rows' => 6]) ?>

  <?= $form->field($model, 'is_default')->checkbox(['checked' => true]) ?>

  <div class="form-group">
    <?= Html::submitButton($model->isNewRecord ? Yii::t('general', 'Create') : Yii::t('general', 'Update'), ['class' => $model->isNewRecord ? 'btn btn-success' : 'btn btn-primary']) ?>
  </div>

  <?php ActiveForm::end(); ?>

</div>

