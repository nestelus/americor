<?php
/* @var $this yii\web\View */

/**
 * @var $profile common\models\Profile
 * @var $user common\models\User
 * @var $ratings common\models\auktaModels\UserRatings[]
 */
?>



<div class="profile-block">
    <?=
    $this->render('_user_ratings',
        [
        'profile' => $profile,
        'ratings' => $ratings
    ]);
    ?>

</div>
