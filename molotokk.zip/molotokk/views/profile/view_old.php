<?php
/** @var $profile common\models\Profile */
use yii\helpers\Html;
use molotokk\models\UserRating;

$this->title                   = empty($profile->name) ? Html::encode($profile->user->username)
          : Html::encode($profile->name);
$this->params['breadcrumbs'] = '';
?>
<div class="main-user">
  <div class="main-title">
    <h1>
      <span class="user">
        <span class="uname"><?= $user->username ?></span>
        <span class="user-rating">(<?= $profile->rating ?>)</span>

        <!-- a class="unAbout" href="#"><img src="/img/omnie.gif" border="0"></a -->
      </span>
    </h1>
  </div>
  <div class="main-adress">
    <?=
    !empty($profile->region_id) ? $profile->region->name : Yii::t('nc_users',
            'Регион не указан');
    ?>
    <?=
    !empty($profile->city) ? $profile->city : Yii::t('nc_users',
            'Город не указан');
    ?></div>
  <div class="main-reg-data">Дата регистрации:<?=
    date('d-m-Y', $profile->user->created_at)
    ?></div>
  <?php if (!is_null($user->last_at)): ?>
        <?php if (time() - $user->last_at > 300): ?>
              <div class="main-enter-data">Последнее посещение: <?=
                date('d-m-Y H:i', $profile->user->last_at)
                ?></div>
        <?php else : ?>
              <div class="main-enter-data"><span class="star"></span>Сейчас на сайте</div>
        <?php endif; ?>
  <?php endif; ?>
</div>
<div class="feedbacks">
  <div class="feedbacksSummary roundCornerWhiteBG corAll5">
    <table cellspacing="0">
      <thead>
        <tr>
          <td>Тип отзыва</td>
          <td>За последние <br />7 дней</td>
          <td>За последние <br />30 дней</td>
          <td>Все</td>
          <td>Купил/Продал</td>
        </tr>
      </thead>
      <tbody>
        <tr class="pos">
          <td class="rowName">Положительно</td>
          <td><?= $profile->selectRatings(UserRating::RATING_POSITIVE, 604800) ?></td>
          <td><?= $profile->selectRatings(UserRating::RATING_POSITIVE, 2592000) ?></td>
          <td><?= $profile->selectRatings(UserRating::RATING_POSITIVE) ?></td>
          <td><?=
            $profile->selectRatings(UserRating::RATING_POSITIVE, null,
                UserRating::DIRECTION_FROM_SELLER)
            ?> / <?=
            $profile->selectRatings(UserRating::RATING_POSITIVE, null,
                UserRating::DIRECTION_FROM_BUYER)
            ?></td>
        </tr>
        <tr class="neu">
          <td class="rowName">Нейтрально</td>
          <td><?= $profile->selectRatings(UserRating::RATING_NEUTRAL, 604800) ?></td>
          <td><?= $profile->selectRatings(UserRating::RATING_NEUTRAL, 2592000) ?></td>
          <td><?= $profile->selectRatings(UserRating::RATING_NEUTRAL) ?></td>
          <td><?=
            $profile->selectRatings(UserRating::RATING_NEUTRAL, null,
                UserRating::DIRECTION_FROM_SELLER)
            ?> / <?=
            $profile->selectRatings(UserRating::RATING_NEUTRAL, null,
                UserRating::DIRECTION_FROM_BUYER)
            ?></td>

        </tr>
        <tr class="neg">
          <td class="rowName">Отрицательно</td>
          <td><?= $profile->selectRatings(UserRating::RATING_NEGATIVE, 604800) ?></td>
          <td><?= $profile->selectRatings(UserRating::RATING_NEGATIVE, 2592000) ?></td>
          <td><?= $profile->selectRatings(UserRating::RATING_NEGATIVE) ?></td>
          <td><?=
            $profile->selectRatings(UserRating::RATING_NEGATIVE, null,
                UserRating::DIRECTION_FROM_SELLER)
            ?> / <?=
            $profile->selectRatings(UserRating::RATING_NEGATIVE, null,
                UserRating::DIRECTION_FROM_BUYER)
            ?></td>
        </tr>
      </tbody>
    </table>
  </div>
  <br />
  <!-- a href="#" class="main-button">Добавить продавца в избранное</a -->
  <a href="/profile/products-list/<?= $user->id ?>/" class="main-button">Все лоты продавца</a>
</div>
<div style="clear: both;"></div>



<?=
$this->render('ratings',
    [
    'profile' => $profile,
    'user' => $user,
])
?>

