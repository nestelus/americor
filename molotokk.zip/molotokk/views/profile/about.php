<?php

/** @var $profile common\models\Profile */
use yii\bootstrap\ActiveForm;
use mihaildev\ckeditor\CKEditor;
use yii\bootstrap\Html;
?>
<div class="profile-block">
    <div class="panel panel-body">
        <?= $profile->bio ?>

    </div>
    <?php if (Yii::$app->user->id == $profile->user_id): ?>
        <span class="btn-profile-block-edit" data-toggle="collapse" data-target="#profile-about-edit">
            Редактировать
        </span>

        <div id="profile-about-edit" class="collapse">
            <?php $form = ActiveForm::begin() ?>
            <?=
            $form->field($profile, 'bio')->widget(CKEditor::className(),
                [
                'editorOptions' => [
                    'language' => 'ru',
                    //'filebrowserBrowseUrl' => '/trest',
                    'preset' => 'basic', //разработанны стандартные настройки basic, standard, full данную возможность не обязательно использовать
                    'inline' => false, //по умолчанию false])
                ],
            ])
            ?>
            <?=
            Html::submitButton('Сохранить', ['class' => 'btn btn-default'])
            ?>
        </div>
        <?php ActiveForm::end() ?>
    <?php endif; ?>

</div>
