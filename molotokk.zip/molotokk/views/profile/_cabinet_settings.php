<?php

use yii\bootstrap\Nav;

$controller      = $this->context;
$networksVisible = count(Yii::$app->authClientCollection->clients) > 0;
$sections        = [
    [
        'label' => Yii::t('user', 'Profile'),
        'url' => ['/user/settings/profile'],
        'options' => [
            'class' => 'list-group-item ',
        ],
        'linkOptions' => [
            'class' => 'pj_products-block',
        ],
    ],
    [
        'label' => Yii::t('user', 'Account'),
        'url' => ['/user/settings/account'],
        'options' => [
            'class' => 'list-group-item ',
        ],
        'linkOptions' => [
            'class' => 'pj_products-block',
        ],
    ],
    [
        'label' => Yii::t('user', 'Networks'),
        'url' => ['/user/settings/networks'],
        'options' => [
            'class' => 'list-group-item ',
        ],
        'visible' => $networksVisible,
        'linkOptions' => [
            'class' => 'pj_products-block',
        ],
    ],
    [
        'label' => 'Адреса доставки',
        'url' => ['/user/settings/delivery-adresses'],
        'options' => [
            'class' => 'list-group-item ',
        ],
        'visible' => $networksVisible,
        'linkOptions' => [
            'class' => 'pj_products-block',
        ],
        'active' => strpos($controller->action->id, '-adresses'),
    ],
];
?>
<div class="profile-block">
    <div class="panel panel-body">
        <div class="row">
            <div class="col-md-3">
                <?=
                Nav::widget([
                    'items' => $sections,
                    'options' => [
                        'class' => 'list-group category_facet_ul',
                    ],
                ])
                ?>
            </div>
            <div class="col-md-9">
                <?=
                $this->render($view_setting, $setting_params)
                ?>
            </div>
        </div>
    </div>
</div>


