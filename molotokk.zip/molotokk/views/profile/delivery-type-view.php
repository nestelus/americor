<?php

use yii\helpers\Html;
use yii\widgets\DetailView;

/* @var $this yii\web\View */
/* @var $model molotokk\models\DeliveryTypes */

$this->title                   = $model->name;
$this->params['breadcrumbs'][] = ['label' => Yii::t('products', 'Delivery Types'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="delivery-types-view">

  <h1><?= Html::encode($this->title) ?></h1>

  <p>
    <?= Html::a(Yii::t('general', 'Update'), ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
    <?=
    Html::a(Yii::t('general', 'Delete'), ['delete', 'id' => $model->id], [
        'class' => 'btn btn-danger',
        'data'  => [
            'confirm' => Yii::t('sales', 'Are you sure you want to delete this delivery type?'),
            'method'  => 'post',
        ],
    ])
    ?>
  </p>

  <?=
  DetailView::widget([
      'model'      => $model,
      'attributes' => [
          'name',
          'type_id',
          'cost',
          'term',
          'conditional:ntext',
      ],
  ])
  ?>

</div>
