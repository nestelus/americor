<?php
/* @var $this yii\web\View */
/* @var $messager common\components\messager\AuktaMessager */

use yii\widgets\Pjax;
?>
<div class="profile-block">
    <?= $messager->renderFilter() ?>

    <div class="panel panel-body">
        <div class="row profile-message">
            <?php
            Pjax::begin(
                [
                    //'enableReplaceState' => true,
                    'enablePushState' => false,
                    'id' => 'pj_user_list',
                    'linkSelector' => '.pj-message-user-list',
                    'formSelector' => '#message-filtr-form',
                    'scrollTo' => true,
                    'timeout' => null,
                ]
            );
            ?>
            <?= $messager->renderMenu(); ?>

            <?php Pjax::end() ?>

        </div>
    </div>
</div>

