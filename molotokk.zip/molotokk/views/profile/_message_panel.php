<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
?>
<div class="messages-block">
    <div class="panel panel-body">
        <div class="row">
            <div class="col-md-3 col-lg-3 col-sm-4">

            </div>
        </div>
    </div>
</div>
