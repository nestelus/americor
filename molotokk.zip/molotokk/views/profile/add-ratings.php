<?php
/* @var $this yii\web\View */

/* @var $products molotokk\models\Products[] */

use yii\bootstrap\ActiveForm;
use yii\bootstrap\Html;
use yii\widgets\LinkPager;
use molotokk\models\UserRating;
use yii\widgets\Pjax;
use molotokk\widgets\Alert;

$rating_default = 'Сделка завершена успешно. Рекомендую.';
$types          = [

    1 => Yii::t('nc_users', 'Положительный'),
    0 => Yii::t('nc_users', 'Нейтральный'),
    -1 => Yii::t('nc_users', 'Отрицательный'),
];

foreach ($products as $product) {
    $searchSource[] = [
        'label' => $product->name,
        'value' => $product->id,
    ];
}
?>
<div class="panel panel-default"> 
    <div class="panel-body">

        <?php
        Pjax::begin([
            'id' => 'addRating',
            'formSelector' => '.js-rating-form',
            'timeout' => 0,
        ]);
        ?>



        <?= Alert::widget(); ?>

        <?=
        LinkPager::widget([
            'pagination' => $pages,
            'firstPageLabel' => true,
            'lastPageLabel' => true,
        ]);
        ?>

        <?php
        foreach ($products as $product) :
            $photo                = $product->getMainPhoto();
            $rating[$product->id] = new UserRating([
                'rating_type' => 1,
                'rating_text' => $rating_default,
            ]);
            ?>
            <div class="panel panel-default">
                <div class="panel-body">
                    <?php
                    $form                 = ActiveForm::begin([
                            'options' => [
                                'id' => 'rating_'.$product->id,
                                'class' => 'js-rating-form',
                            ]
                    ]);
                    ?>
                    <div class="row">
                        <div class="col-md-4">
                            <?=
                            Html::a(Html::img($photo ? $photo->getUrlPhoto(225,
                                            225) : '',
                                    [
                                    'width' => 225,
                                    'hieght' => 225,
                                ]), $product->getUrl());
                            ?>
                        </div>
                        <div class="col-md-8">
                            <div>
                                <?php
                                if ($product->user_id == Yii::$app->user->id):
                                    ?>
                                    <?php
                                    $user_id = $product->buyer_id
                                    ?>
                                    <p>
                                        Лот №<?= $product->id ?> куплен: <?=
                            Yii::t('user', '{0, date, MMMM dd, YYYY HH:mm}',
                                [$product->complete_at])
                                    ?>
                                        <br />
                                        Покупатель: <?= $product->buyer->username ?>
                                    </p>
    <?php endif; ?>
                                <?php
                                if ($product->buyer_id == Yii::$app->user->id):
                                    ?>
                                    <?php
                                    $user_id = $product->user_id
                                    ?>
                                    <p>
                                        Лот №<?= $product->id ?> продан: <?=
                            Yii::t('user', '{0, date, MMMM dd, YYYY HH:mm}',
                                [$product->complete_at])
                                    ?>
                                        <br />
                                        Продавец: <?= $product->user->username ?>
                                    </p>
    <?php endif; ?>

                            </div>
                            <h3><?= $product->name; ?></h3>

                            <div class="b-rating-form">
    <?=
    $form->field($rating[$product->id], 'product_id')->hiddenInput([ 'value' => $product->id,])->label(false);
    ?>
                                <?=
                                $form->field($rating[$product->id], 'author_id')->hiddenInput([ 'value' => Yii::$app->user->id,])->label(false);
                                ?>
                                <?=
                                $form->field($rating[$product->id], 'user_id')->hiddenInput([ 'value' => $user_id,])->label(false);
                                ?>
                                <?=
                                $form->field($rating[$product->id], 'direction')->hiddenInput([ 'value' => $direction,])->label(false);
                                ?>
                                <?=
                                $form->field($rating[$product->id],
                                    'rating_type',
                                    [
                                    'inline' => true,
                                ])->radioList($types,
                                    [
                                    'class' => 'b-rating-type',
                                    'id' => 'rating-'.$product->id,
                                ])->label(false);
                                ?>
                                <?=
                                $form->field($rating[$product->id],
                                    'rating_text')->textarea([
                                    'rows' => 3,
                                ]);
                                ?>
                                <?=
                                Html::submitButton(Yii::t('nc_users',
                                        'Отправить отзыв'),
                                    [
                                    'class' => 'btn btn-primary pull-right',
                                ])
                                ?>
                            </div>
                        </div>
                    </div>

                </div>
                <?php ActiveForm::end() ?>
            </div>
        <?php endforeach; ?>
        <?=
        LinkPager::widget([
            'pagination' => $pages,
            'firstPageLabel' => true,
            'lastPageLabel' => true,
        ]);
        ?>


        <?php
        $script = <<< JS
  $(".js-rating-form input[type=radio]").change(function(){
  var textarea = $(this).closest(".js-rating-form").find("textarea");
  if ($(this).val() == 1 &&  textarea.val() == '') {
      textarea.val("$rating_default");
    }
    else {
    if(textarea.val() == "$rating_default"){
      textarea.val('');
      }
    };
    });
JS;
//маркер конца строки, обязательно сразу, без пробелов и табуляции
        $this->registerJs($script, yii\web\View::POS_READY);
        ?>
        <?php Pjax::end() ?>
    </div>
</div>



