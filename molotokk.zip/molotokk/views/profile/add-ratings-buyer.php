<?php
/* @var $this yii\web\View */

use yii\bootstrap\Nav;
use molotokk\models\UserRating;
?>

<div class="add-ratings">
  <h1><?= Yii::t('nc_users', 'Оставить отзывы') ?></h1>
  <?=
  Nav::widget([
      'options' => [
          'class' => 'nav nav-tabs',
      ],
      'items' => [
          [
              'label' => Yii::t('products', 'Проданные'),
              'url' => '/profile/add-ratings-buyer/',
              'active' => true,
          ],
          [
              'label' => Yii::t('products', 'Купленные'),
              'url' => '/profile/add-ratings-seller/',
          ]
      ]
  ])
  ?>
  <?php if (!empty($products)): ?>
        <?=
        $this->render('add-ratings',
            [
            'products' => $products,
            'pages' => $pages,
            'direction' => UserRating::DIRECTION_FROM_SELLER,
            ]
        );
        ?>
<?php else: ?>
        <div>
          У вас нет проданных товаров, на которые Вы не отсавили отзывв
        </div>
<?php endif; ?>
</div>

