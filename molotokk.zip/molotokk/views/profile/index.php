<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use common\widgets\ShortProductWidget;
use common\components\NCCollapse;
use yii\bootstrap\Collapse;
use yii\bootstrap\Html;
use yii\helpers\Url;
?>
<?=
NCCollapse::widget([
    'items' => [
        [
            'label' => 'Мои избранные',
            'content' => ShortProductWidget::widget([
                'mode' => 'narrow',
                'products' => $favorite,
            ]).Html::tag('div', Html::a('Смотреть все >> ', Url::to('/profile/my-favorite/'), ['class' => 'pjax-user_menu'])),
            // open its content by default
            'options' => [
                'id' => 'profile-my-favorite'
            ],
            'contentOptions' => [
                'class' => 'in',
            ],
        ],
        [
            'label' => 'Мои текущие ставки',
            'content' => ShortProductWidget::widget([
                'mode' => 'narrow',
                'products' => $active_bids,
            ]).Html::tag('div', Html::a('Смотреть все >> ', Url::to('/profile/my-active-bids/'), ['class' => 'pjax-user_menu'])),
            'options' => [
                'id' => 'profile-my-active-bids'
            ],
        ],
        [
            'label' => 'Мои текущие продажи',
            'content' => ShortProductWidget::widget([
                'mode' => 'narrow',
                'products' => $active_sales,
            ]).Html::tag('div', Html::a('Смотреть все >> ', Url::to('/profile/my-active-sales/'), ['class' => 'pjax-user_menu'])),
            'options' => [
                'id' => 'profile-my-active-sales'
            ],
        ],
        [
            'label' => 'Мои проданные',
            'content' => ShortProductWidget::widget([
                'mode' => 'narrow',
                'products' => $sales,
            ]).Html::tag('div', Html::a('Смотреть все >> ', Url::to('/profile/my-sales/'), ['class' => 'pjax-user_menu'])),
            'options' => [
                'id' => 'profile-my-sales'
            ],
        ],
    ],
]);
?>


