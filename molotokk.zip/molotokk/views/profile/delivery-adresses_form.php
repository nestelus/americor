<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use common\widgets\RegionFormWidget;
use yii\widgets\MaskedInput;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model molotokk\models\DeliveryAdresses */
/* @var $form yii\widgets\ActiveForm */
?>
<style>
    div.required label:after {
        content: " *";
        color: red;
    }
</style>
<?php
$form = ActiveForm::begin([
        // 'action' => Url::to('/user/settings/delivery-adresses-create/'),
        'id' => 'delivery-adresses-form',
    ]);
?>
<?= $form->field($model, 'name')->textInput(['maxlength' => true]) ?>

<?= $form->field($model, 'fio')->textInput() ?>

<?=
RegionFormWidget::widget([
    'model' => $model,
    'form' => $form,
]);
?>
<?= $form->field($model, 'address')->textarea() ?>

<?= $form->field($model, 'zip')->textInput(['maxlength' => true]) ?>

<?=
$form->field($model, 'phone')->widget(MaskedInput::className(),
    [
    'mask' => '+9(999) 999-99-99',
])
?>
<?= $form->field($model, 'is_default')->checkbox(); ?>
<div class="form-group">
    <?= Html::submitButton('Добавить', ['class' => 'btn btn-success'])
    ?>
</div>

<?php ActiveForm::end(); ?>



