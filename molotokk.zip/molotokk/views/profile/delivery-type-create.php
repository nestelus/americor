<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model molotokk\models\DeliveryTypes */

$this->title                   = Yii::t('products', 'Add Delivery Type');
$this->params['breadcrumbs'][] = ['label' => Yii::t('products', 'Delivery Type'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="delivery-types-create">

  <h1><?= Html::encode($this->title) ?></h1>

  <?=
  $this->render('delivery-type_form', [
      'model' => $model,
  ])
  ?>

</div>
