<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use yii\helpers\Html;
use common\models\auktaModels\Products;
use yii\helpers\Url;
use yii\widgets\Pjax;
use common\models\User;
use yii\widgets\ActiveForm;

$user_list = $messager->getUserList();
?>


<div class="profile-block">

    <div class="panel panel-body">
        <div class="row">
            <div class="col-md-3 col-lg-3 col-sm-4 profile-message">
                <ul  class="nav">
                    <?php foreach ($user_list as $direction => $dialogs): ?>
                        <?php
                        foreach ($dialogs as $lot_id => $users):
                            $lot = Products::findOne($lot_id);
                            ?>
                            <li class="list-group-item <?=
                            $messager->lot_id == $lot_id ? 'active' : ''
                            ?> ">
                                <div class="dialog-list-lot" id="list-lot-<?= $lot_id ?>">
                                    <a data-toggle="collapse" data-parent="#accordion" href="#collapse<?= $lot_id ?>">
                                        Лот № <?= $lot->id ?>
                                    </a>
                                    <span> </span>

                                </div>
                                <div id="collapse<?= $lot_id ?>" class="panel-collapse collapse <?=
                                $messager->lot_id == $lot_id ? 'in' : ''
                                ?>">
                                    <ul class="list-group category_facet_ul">
                                        <?php
                                        if ($direction >= 0) :
                                            ?>

                                            <?php
                                            foreach ($users as $usr_id => $count):
                                                $usr = User::findOne($usr_id)
                                                ?>
                                                <li class="contact" >
                                                    <span class="glyphicon glyphicon-user"></span>
                                                    <a href="<?=
                                                    Url::to(['/messages/dialog',
                                                        'id' => $usr_id,
                                                        'lot_id' => $lot_id])
                                                    ?>" class="pj-message-user">
                                                        <span class="user-title"><?= $usr->username ?>
                                                            <span class="cnt"></span>
                                                        </span>
                                                    </a>
                                                </li>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </li>
                        <?php endforeach; ?>
                    <?php endforeach; ?>
                </ul>
            </div>
            <div class="col-md-9 col-lg-9 col-sm-8 profile-message">

                <?php
                Pjax::begin(
                    [
                        'enablePushState' => false,
                        'id' => 'pj_user_list',
                        'linkSelector' => '.pj-message-user',
                        'scrollTo' => true,
                    ]
                );
                ?>
                <?=
                $this->render('_message_dialog',
                    [
                    'messager' => $messager,
                ])
                ?>
                <?php Pjax::end() ?>

                <?php if ($messager->lot_id && $messager->visavi_id): ?>
                    <?php $message = new \common\models\auktaModels\Messages() ?>
                    <?php
                    $form    = ActiveForm::begin([
                            'id' => 'form-singl-send-'.$messager->lot_id,
                            'action' => '#',
                            // 'option' => [],
                    ]);
                    ?>
                    <?= $form->field($message, 'from_id')->hiddenInput(['value' => Yii::$app->user->id])->label(FALSE); ?>
                    <?= $form->field($message, 'whom_id')->hiddenInput(['value' => $messager->visavi_id])->label(FALSE); ?>
                    <?= $form->field($message, 'product_id')->hiddenInput(['value' => $messager->lot_id])->label(FALSE); ?>
                    <?= $form->field($message, 'is_system')->hiddenInput(['value' => 0])->label(FALSE); ?>


                    <?=
                    $form->field($message, 'message')->textarea([
                        'placeholder' => 'Введите сообщение',
                    ]);
                    ?>

                    <?=
                    Html::submitButton('Отправить',
                        [ 'class' => 'btn btn-success']);
                    ?>
                    <?php ActiveForm::end(); ?>
                </div>
            <?php endif; ?>


        </div>
    </div>
</div>
