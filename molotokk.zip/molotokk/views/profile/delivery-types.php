<?php

use yii\helpers\Html;
use yii\grid\GridView;
use common\models\auktaModels\enumModels\DeliveryType;

/* @var $this yii\web\View */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title                   = Yii::t('products', 'Delivery Types');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="delivery-types-index">



  <div class="panel panel-default">
    <div class="panel-heading">
      <?= Html::encode($this->title) ?>
    </div>
    <div class="panel-body">
      <p>
        <?= Html::a(Yii::t('products', 'Add Delivery Type'), ['delivery-type-create'], ['class' => 'btn btn-success'])
        ?>
      </p>

      <?=
      GridView::widget([
          'dataProvider' => $dataProvider,
          'columns' => [
              ['class' => 'yii\grid\SerialColumn'],
              [
                  'class' => 'yii\grid\ActionColumn',
                  'template' => '{update} {delete}',
                  'urlCreator' => function($action, $model, $key, $index)
                  {
                        return "/user/settings/delivery-type-$action/$model->id/";
                  },
              ],
              'name',
              [
                  'attribute' => 'type_id',
                  'content' => function ($model)
                  {
                        return DeliveryType::getLabel($model->type_id);
                  }
              ],
              'cost:ntext',
              'term:ntext',
              'conditional:ntext',
          ],
      ]);
      ?>

    </div>
  </div>
</div>
