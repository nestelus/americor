<?php

use common\models\auktaModels\Articles;
use common\models\auktaModels\enumModels\ArticleTypes;
use yii\widgets\Pjax;
use execut\widget\TreeView;

/* @var $this yii\web\View */
/* @var $model common\models\auktaModels\Articles */
$type                          = ArticleTypes::ARTICLE_HELP;
$this->params['breadcrumbs'][] = ['label' => ArticleTypes::getLabel($type), 'url' => ['index',
        'id' => $type]];

$this->beginBlock('helpMenu');

$items = Articles::treeItems($type);
?>
<p>
    <?php if (!empty($items)): ?>
        <?=
        TreeView::widget([
            'id' => 'js_tree-help',
            'data' => $items,
            'size' => TreeView::SIZE_SMALL,
            'template' => TreeView::TEMPLATE_SIMPLE,
            'containerOptions' => [
                'class' => 'pj_canvas',
            ],
            /* 'searchOptions' => [
              'inputOptions' => [
              'placeholder' => 'Search category...'
              ],
              ], */
            'clientOptions' => [
                //'onNodeSelected' => $onSelect,
                //'onNodeUnselected' => $unSelect,
                'selectedBackColor' => 'rgb(40, 153, 57)',
                'showBorder' => false,
                'enableLinks' => true,
            ],
        ]);
        ?>
<?php endif; ?>
</p>
<?php $this->endBlock() ?>
<div class="articles-view">



    <?php
    Pjax::begin([
        'id' => 'pj_help',
        'linkSelector' => 'li.node-js_tree-help a',
        'enablePushState' => false,
        'timeout' => 0,
    ])
    ?>
    <?=
    $this->render('view-help', [
        'model' => $model,
    ]);
    ?>
<?php Pjax::end() ?>

</div>
