<?php

use common\widgets\FacetWidget;

/* @var $this yii\web\View */
/* @var $products  molotokk\models\Products[] */
?>
<?php if (!empty($searchFilter->getFacet('category_facet'))) : ?>
    <?php $this->beginBlock('facet'); ?>
    <?=

    FacetWidget::widget([
        'header' => 'Категории',
        'facet'  => $category_facet,
            ]
    )
    ?>
    <?php $this->endBlock(); ?>
<?php endif; ?>

<?=

$this->render('products-list', [
    'searchFilter' => $searchFilter,
    'title'        => $title,
]);
?>

