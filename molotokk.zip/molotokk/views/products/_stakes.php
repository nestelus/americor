<?php
/* @var $this yii\web\View */
/* @var $query yii\db\ActiveQuery */

use yii\grid\GridView;
use yii\data\ActiveDataProvider;
use yii\db\Expression;
use yii\db\Query;

$q_start = new Query();

// Стартовая цена
$q_start->select(
    [
        new Expression('"Стартовая цена" as username'),
        new Expression($model->price_start ?: 'null'.' as amount'),
        new Expression($model->created_at.' as created_at'),
        new Expression('-1 as auto'),
    ]
);

//  реальные ставки
$q_stakes = $model->getAuctionStakes()->innerJoinWith('user')->innerJoinWith('profile')
    ->select(
        [
            new Expression('CONCAT({{%user}}.username,"(",{{%profile}}.rating,")") as username'),
            'amount',
            '{{%auction_stakes}}.created_at',
            new Expression('0 as auto'),
        ]
    )
    ->andWhere(['<=', 'amount', $model->price]);

// Автоматические ставки
$query_stake = $model->getAuctionStakes()->innerJoinWith('leader')->innerJoinWith('leaderProfile')
    ->select(
        [
            new Expression('CONCAT({{%user}}.username,"(",{{%profile}}.rating,")") as username'),
            'current_price',
            'MAX({{%auction_stakes}}.created_at) as created_at ',
            new Expression('1 as auto'),
        ]
    )
    ->andWhere('current_price <> amount')
    ->groupBy(['{{%user}}.username', 'current_price', new Expression('auto')]);

// объединяем
$q_stakes->union($query_stake)->union($q_start);

// выводим
$all_stakes = new Query();
$all_stakes->from(['stake' => $q_stakes]);
/* ->select([
  'username', 'amount', 'MAX(created_at) as created_at ', 'MIN(auto) as auto'
  ])
  ->groupBy('username', 'amount'); */

// сортируем
$all_stakes->orderBy(
    [
        'amount' => SORT_DESC,
        'auto' => SORT_DESC,
    ]
);
//var_dump($all_stakes->createCommand()->rawSql);
?>
<div class="lot-stakes">
    <?php
    echo GridView::widget(
        [

            'dataProvider' => new ActiveDataProvider(
                [
                    'query' => $all_stakes,
                    'pagination' => false,
                ]
            ),
            'rowOptions' => function ($model, $key, $index, $grid) {
                if ($index == 0) {
                    return ['style' => 'font-weight:bold'];
                }
                if ($model['auto'] == 1) {
                    {
                        return ['style' => 'color:#aaa'];
                    }
                }
            },
            'tableOptions' => ['class' => 'table table-striped'],
            'columns' => [
                [
                    'label' => 'Пользователь',
                    'attribute' => 'username',
                ],
                [
                    'label' => 'Цена',
                    'attribute' => 'amount',
                    'content' => function ($model, $key, $index, $column) {
                        return number_format($model['amount'], 0, '.', ' ').'  '.Yii::$app->params['currency'];
                    },
                ],
                [
                    'label' => 'Дата',
                    'attribute' => 'created_at',
                    'format' => 'datetime',
                ],
            ],
            'showHeader' => true,
            'layout' => '{items}',
            'options' => [
                'id' => 'all-stake',
            ],
        ]
    );
    ?>
</div>