<?php
/** @var $this yii\web\View */
/** @var $user common\models\User */
/** @var $profile common\models\Profile */

use molotokk\models\UserRating;
/** @var $ratings molotokk\models\UserRating[] Description */
$ratings = $profile->getRatings()->andWhere(['direction' => UserRating::DIRECTION_FROM_BUYER])->limit(10)->all();

?>
 <?=
    $this->render('_user_ratings', [
        'ratings' => $ratings,
    ]);
    ?>

