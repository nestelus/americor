<?php
/* @var $this yii\web\View */

use yii\bootstrap\Modal;
use yii\widgets\ActiveForm;
use yii\helpers\Url;
use yii\helpers\Html;
use common\models\auktaModels\enumModels\StateProduct;

$next_step1 = $stake->product->getNextStake();
$next_step2 = $stake->product->getNextStake($next_step1);
$next_step3 = $stake->product->getNextStake($next_step2);
$next_step4 = $stake->product->getNextStake($next_step3);
$next_step5 = $stake->product->getNextStake($next_step4);

Modal::begin([
    'id' => 'modal_ower_stake',
    'header' => '<div style="color:red; font-weight: bold;" class="col-md-12"><span class="glyphicon glyphicon-exclamation-sign" ></span>
        Ваша ставка перебита пользователем '.$stake->leader->username.'</div>',
    'clientOptions' => [
        'show' => true,
    ],
]);
?>
<div class="row" >
    <div class="col-md-12">
        <h3>  Актуальная цена лота <span style="color:red; font-weight: bold;" class="js_current-stake">
                <?= number_format($stake->current_price, 0, '.',
                    ' ').'  '.Yii::$app->params['currency']
                ?></span>
        </h3>
    </div>
</div>
<p>
<div class="row">
    <div class="col-md-4">
        <?=
        Html::button('Cделать ставку <br>'.$next_step1.' '.Yii::$app->params['currency'],
            [
            'class' => 'btn btn-primary js_btn-quick-stake',
            'data' => $next_step1,
        ])
        ?>
    </div>
    <div class="col-md-4">
        <?=
        Html::button('Cделать ставку <br>'.$next_step2.' '.Yii::$app->params['currency'],
            [
            'class' => 'btn btn-primary js_btn-quick-stake',
            'data' => $next_step2,
        ])
        ?>
    </div>
    <div class="col-md-4">

        <?=
        Html::button('Cделать ставку <br>'.$next_step5.' '.Yii::$app->params['currency'],
            [
            'class' => 'btn btn-primary js_btn-quick-stake',
            'data' => $next_step5,
        ])
        ?>
    </div>

</div>  
<p>

    <?php
    $form = ActiveForm::begin([
            'action' => Url::toRoute(['products/stake', 'id' => $stake->product_id]),
            'method' => 'post',
            'class' => 'form-inline pj_auction_form',
            'options' => [
                'id' => 'ower-auction_form',
                'data-pjax' => 1,
            ],
        ])
    ?>
    <span class="buy-span-center">
        <label> Или введите свою ставку </label>

        <?=
        $form->field($stake, 'amount')->textInput([
            'value' => number_format($stake->product->getMyNextStake(), 0, '.',
                ''),
            'id' => 'js_quick-amount',
        ])->label(FALSE);
        ?>
        <?= $form->field($stake, 'product_id')->hiddenInput(['value' => $stake->product_id])->label(FALSE); ?>
            <?= Html::hiddenInput('stake', true); ?>
        <div style="font-size: 10pt" id="next-stake">
            <?=
            Yii::t('product', 'Введите сумму не менее {amount}',
                [
                'amount' => number_format($stake->product->getMyNextStake(), 0,
                    '.', ' ').'  '.Yii::$app->params['currency']
            ])
            ?>
        </div>
    </span>
<div class="lot-buttons ">
    <br/>
    <?=
    Html::submitButton(Yii::t('products', 'Сделать ставку'),
        [
        'class' => 'btn btn-bg-orange-red color-white',
        'disabled' => !(($stake->product->state_id == StateProduct::STATE_ON_AUCTION)
        &&
        ($stake->product->user_id != Yii::$app->user->id)),
        'onClick' => "ga('send', 'event', 'Покупка', 'Сделать ставку')",
    ]);
    ?>

</div>


<?php ActiveForm::end() ?>
<?php Modal::end(); ?>

<?php
$js   = <<<JS
    $(".js_btn-quick-stake").click(function(){
       
        $("#js_quick-amount").val($(this).attr('data'));
        $("#modal_ower_stake").modal('hide');
        $("form#ower-auction_form").submit();
    });
    $("form#ower-auction_form").submit(function(){
        $("#modal_ower_stake").modal('hide');
    });
    
JS;
$this->registerJs($js);




