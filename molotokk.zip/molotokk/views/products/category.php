<?php

use molotokk\widgets\CategoryFacetWidget;

/* @var $this yii\web\View */
/* @var $products  molotokk\models\Products[] */
/* @var $category \common\models\auktaModels\Categories */
/* @var $searchFilter \common\components\searchFilter */
$this->beginBlock('content_header');
?>
<div class="category-header clearfix">
    <div class="category-header-name pull-left">
        <?= $category->name ?>
    </div>
    <div class="category-header-make-lot pull-right">
        <a href="/admin-product/create?category_id=<?= $category->id ?>">  Выставить лот в этой категории </a>
    </div>
</div>
<?php
$this->endBlock();
$this->beginBlock('facet');
echo CategoryFacetWidget::widget([
    'category' => $category,
    'query' => $searchFilter->query,
]);
$this->endBlock();
echo $this->render('products-list',
    [
    'searchFilter' => $searchFilter,
    'title' => $title,
]);

