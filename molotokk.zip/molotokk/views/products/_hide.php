<?php
/* @var $this yii\web\View */
/* @var $product molotokk\models\Products */

use common\widgets\ModalDataContactWidget;

?>
<p class="bargain-status">
    Торги завершены
</p>
<p class="bargain-result">
    <?php if ($product->is_auction): ?>
        Ставок не было
    <?php else: ?>
        Предложений не было
    <?php endif; ?>
</p>
<?php if ($product->user_id == Yii::$app->user->id): ?>
    <?=
    ModalDataContactWidget::widget(
        [
            'user_id' => $product->buyer_id,
        ]
    );
    ?>
<?php endif; ?>

<?php if ($product->buyer_id == Yii::$app->user->id): ?>
    <?=
    ModalDataContactWidget::widget(
        [
            'user_id' => $product->user_id,
        ]
    );
    ?>
<?php endif; ?>


