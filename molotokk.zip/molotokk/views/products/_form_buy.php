<?php
/* @var $this yii\web\View */
/* @var $product molotokk\models\Products */

use common\models\auktaModels\enumModels\StateProduct;
//use Yii;
use yii\widgets\ActiveForm;
use yii\helpers\Html;
use yii\widgets\MaskedInput;
use molotokk\models\Profile;
use molotokk\models\Sales;
use yii\helpers\Url;
use molotokk\widgets\ModalLotMessages;
?>

<div class="lot-buy">
    <?php
    $user_id    = Yii::$app->user->id;
    $profile    = Profile::findOne($user_id);
    $first_name = $profile ? $profile->first_name : '';
    $last_name  = $profile ? $profile->last_name : '';
    $phone      = $profile ? $profile->phone : '';
    $region_id  = $profile ? $profile->region_id : '';
    $city       = $profile ? $profile->city : '';

    $sales       = new Sales();
    $buy_caption = 'Купить сейчас';
    $form        = ActiveForm::begin(
            [
                'id' => 'buy-form',
                'action' => Url::toRoute(['products/buy', 'id' => $product->id]), //"/products/buy/$product->id/",
                'class' => 'form-horizontal',
            ]
    );
    ?>
    <?php if ($product->state_id == StateProduct::STATE_ON_AUCTION): ?>
        <span class="buy-span-left">
            <div>Фиксированная цена :</div>
        </span>
        <span class="buy-span-center price">
            <?= number_format($product->price_stop, 0, '.', ' ').'  '.Yii::$app->params['currency'] ?>
        </span>
        <?= $form->field($sales, 'quality')->hiddenInput(['value' => 1])->label(false); ?>
    <?php else : ?>
        <?php if ($product->is_multilot) : ?>
            <span class="buy-span-center">
                <?=
                    $form->field(
                        $sales, 'quality',
                        [
                        'enableAjaxValidation' => true,
                        'validateOnType' => true,
                        'validationDelay' => 0,
                        ]
                    )
                    ->widget(
                        MaskedInput::className(),
                        [
                        'options' => [
                            'value' => 1,
                            'class' => 'form-control',
                        ],
                        'mask' => '9',
                        'clientOptions' => [
                            'repeat' => 10,
                            'greedy' => false,
                        ],
                        ]
                    )
                ?>
                В наличии
                <strong><span id="js_have-quality"><?= $product->quality ?></span></strong> шт.
            </span>
        <?php else: ?>
            <?= $form->field($sales, 'quality')->hiddenInput(['value' => 1])->label(false); ?>
        <?php endif; ?>
    <?php endif; ?>
    <?php ActiveForm::end(); ?>
    <div class="lot-buttons ">
        <?php if (Yii::$app->user->isGuest): ?>
            <?=
            Html::a(
                $buy_caption, Url::to(['products/buy', 'id' => $product->id]),
                [
                'class' => 'btn btn-bg-orange-red color-white',
                ]
            )
            ?>
        <?php else : ?>
            <button class="btn btn-bg-orange-red color-white" data-toggle="modal"
                    data-target="#modal_buy-form" onclick="ga('send', 'event', 'Покупка', 'Клик на странице')">
                Купить сейчас
            </button>
        <?php endif; ?>
    </div>
    <?php if (!Yii::$app->user->isGuest): ?>
        <?=
        ModalLotMessages::widget(
            [

                'product' => $product,
                'sales' => $sales,
                'type' => 'purchase_proof',
            ]
        )
        ?>
    <?php endif; ?>
</div>
