<?php

use yii\helpers\Html;
use yii\helpers\Url;
?>
<div class="lot-properties">
    <p>
        Характеристики товара:
    </p>
    <?php foreach ($properties as $property) : ?>
        <p>
            <span class="property-name">
                <?= $property->categoryProperties->name ?>:
            </span>
            <span class="property-value">
                <?= Html::a($property->__toString(),
                    Url::to(['/sphinx/search', 'searchText' => $property->__toString(),
                        'category_id' => ''])) ?>
            </span>
        </p>
<?php endforeach; ?>
</div>
