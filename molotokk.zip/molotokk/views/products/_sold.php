<?php
/* @var $this yii\web\View */
/* @var $product molotokk\models\Products */

use common\widgets\ModalDataContactWidget;
?>
<p class="bargain-status">
    Торги завершены
</p>
<p class="bargain-result">
    Лот был продан
</p>
<?php if ($product->buyer_id == Yii::$app->user->id): ?>
      <?=
      ModalDataContactWidget::widget([
          'user_id' => $product->user_id,
      ]);
      ?>
<?php endif; ?>

