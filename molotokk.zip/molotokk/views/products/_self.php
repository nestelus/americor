<?php
/* @var $this yii\web\View */
/* @var $product molotokk\models\Products */

use common\models\auktaModels\enumModels\StateProduct;
use common\widgets\ModalDataContactWidget;
?>
<div class="lot-self">
  <div class="col-md-12 text-center">
    <?= Yii::t('products', 'Вы являетесь продавцом этого лота'); ?>
  </div>
  <div>
    <span class="buy-span-left text-right">
      <?= Yii::t('products', 'Цена:'); ?>
    </span>
    <span class="buy-span-right price">
      <?= number_format($product->price, 0, '.', ' ').'  '.Yii::$app->params['currency'] ?>
    </span>
  </div>
  <div>
    <span class="buy-span-left text-right">
      <?= Yii::t('products', 'Статус:'); ?>
    </span>
    <span class="buy-span-right price">
      <?= StateProduct::getLabel($product->state_id) ?>
    </span>
  </div>
</div>

<hr>
<?php if ($product->state_id == StateProduct::STATE_ON_SOLD): ?>
      <?=
      ModalDataContactWidget::widget([
          'user_id' => $product->buyer_id,
      ]);
      ?>
<?php endif; ?>
<?php
if ($product->state_id == StateProduct::STATE_ON_AUCTION)
{

      $js = <<< JS
        setInterval(function(){
       $.ajax({
                  url:"/products/update-auction/$product->id/",
                  dataType: 'json',
                  success: function(data){
                        $("#all-stake").html(data.allStakes);
                  }
                  })
   }, 1000);

JS;

      $this->registerJs($js);
}


