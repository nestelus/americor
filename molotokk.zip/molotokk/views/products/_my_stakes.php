<?php
/* @var $this yii\web\View */
/* @var $stakes yii\data\ActiveDataProvider */

use yii\grid\GridView;

echo GridView::widget([
    'dataProvider' => $stakes,
    'columns' => [
        [
            'attribute' => 'amount',
            'content' => function ($model, $key, $index, $column)
            {
                  return number_format($model->amount, 0, '.', ' ').'  '.Yii::$app->params['currency'];
            }
        ],
        'created_at:datetime',
    // ...
    ],
    'options' => [
        'id' => 'my-stakes-table',
    ],
]);

