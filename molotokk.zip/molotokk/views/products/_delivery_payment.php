<?php

/** @var $model molotokk\models\Products */
use common\models\auktaModels\enumModels\PayMethod;
use common\models\auktaModels\enumModels\DeliveryType;

if ($model->is_prepay || $model->is_deliverypay) {
    ?>
    <div class="lot-delivery-payment-item">
        <span>
            Тип сделки:
        </span>
        <?= ($model->is_prepay ? 'Предоплата' : 'Оплата при получении') ?>
    </div>
    <div class="lot-delivery-payment-item">
        <span>
            Доставку оплачивает:
        </span>
        <?= ($model->is_deliverypay ? 'Продавец' : 'Покупатель') ?>
    </div>
    <?php
}
?>
<div class="lot-delivery-payment-item">
    <span>
        Способы оплаты:
    </span>   
    <?php foreach ($model->paymentProduct as $paymentProduct): ?>
        <?=
        PayMethod::getLabel($paymentProduct->pay_method_id).', ';
        ?>
    <?php endforeach; ?>

</div>
<?php
if (!empty($model->deliveryTypes)) {
    ?>
    <div class="lot-delivery-payment-item">
        <span>
            Доставка:
        </span>

        <?php foreach ($model->deliveryProduct as $deliveryProduct): ?>
            <?= DeliveryType::getLabel($deliveryProduct->delivery_type_id).', ' ?>
        <?php endforeach; ?>

    </div>
    <?php
}
