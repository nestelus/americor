<?php
/* @var $this yii\web\View */
/* @var $model molotokk\models\Products */
/* @var $form common\components\NCActiveForm */

use yii\widgets\ActiveForm;
use yii\helpers\Html;
use molotokk\models\Profile;

$user_id    = Yii::$app->user->id;
$profile    = Profile::findOne($user_id);
$first_name = $profile ? $profile->first_name : '';
$last_name  = $profile ? $profile->last_name : '';
$phone      = $profile ? $profile->phone : '';

$form = ActiveForm::begin([
            'action' => "/products/buy/$product->id/",
            'class'  => 'form-horizontal',
        ]);
echo Html::hiddenInput('buyer_id', $user_id);
echo Html::hiddenInput('buy', true);
?>
<div class="form-group">
  <label class = 'control-label'>Ваше имя</label>
  <?= Html::textInput('first-name', $first_name, ['class' => 'form-control']); ?>
</div>
<div class="form-group">
  <label class = 'control-label'>Ваша фамилия</label>
  <?= Html::textInput('last-name', $last_name, ['class' => 'form-control']); ?>
</div>
<div class="form-group">
  <label class = 'control-label'>Телефон для связи</label>
  <?= Html::textInput('phone', $phone, ['class' => 'form-control']); ?>
</div>
<div class="form-group">
  <label class = 'control-label'>Адрес доставки</label>
  <?= Html::textarea('address', '', ['class' => 'form-control']); ?>
</div>

<?=
Html::submitButton(Yii::t('products', 'Купить сейчас'), [
    'class'    => 'btn btn-success',
    'id'       => 'btn-buy',
    'disabled' => 'disabled',
]);
?>

<?php
ActiveForm::end();

