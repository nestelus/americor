<?php
/* @var $this yii\web\View */
/* @var $product molotokk\models\Products */

//use Yii;
use yii\widgets\ActiveForm;
use yii\helpers\Html;
use yii\helpers\Url;
use common\models\auktaModels\enumModels\StateProduct;
?>



<?php
$form = ActiveForm::begin([
        'action' => Url::toRoute(['products/stake', 'id' => $product->id]),
        'method' => 'post',
        'class' => 'form-inline pj_auction_form',
        'options' => [
            'id' => 'auction_form',
            'data-pjax' => 1,
        ]
    ]);
?>
<?= $form->field($stake, 'product_id')->hiddenInput(['value' => $product->id])->label(FALSE); ?>
<?= Html::hiddenInput('stake', true); ?>
<div class="lot-buy">

    <span class="buy-span-left" >
        <div>
            Cтавок: <span class="number-stake"> <?= count($product->auctionStakes); ?></span>
        </div>
    </span>
    <span class="buy-span-center">
        <label> Ваша ставка </label>

        <?=
        $form->field($stake, 'amount')->textInput([
            'value' => number_format($product->getMyNextStake(), 0, '.', ''),
            'disabled' => !(($product->state_id == StateProduct::STATE_ON_AUCTION)
            &&
            ($product->user_id != Yii::$app->user->id)),
            'id' => 'js_next-amount',
        ])->label(FALSE);
        ?>

        <div style="font-size: 10pt" id="next-stake">
            Введите сумму не менее <span class="js_next-stake"><?= $product->getMyNextStake() ?></span> <?= Yii::$app->params['currency'] ?>

        </div>
    </span>
    <div class="lot-buttons ">
        <br/>
        <?=
        Html::submitButton(Yii::t('products', 'Сделать ставку'),
            [
            'class' => 'btn btn-bg-orange-red color-white',
            'disabled' => !(($product->state_id == StateProduct::STATE_ON_AUCTION)
            &&
            ($product->user_id != Yii::$app->user->id)),
            'onClick' => "ga('send', 'event', 'Покупка', 'Сделать ставку')",
        ]);
        ?>

    </div>
</div>

<?php ActiveForm::end() ?>


<div class="lot-stakes">
    <div class="row" id="js_result-stakes">
        <?php if ($product->isStaker(Yii::$app->user->id)): ?>
            <?php if ($product->maxStake->user_id == Yii::$app->user->id): ?>
                <div class="col-md-12">
                    <div class="stake-alert  stake-win">
                        <?=
                        Yii::t('products', 'Ваша ставка наибольшая');
                        ?>
                    </div>
                </div>

            <?php else: ?>
                <div class="col-md-12">
                    <div class="stake-alert  stake-loos">
                        <?=
                        Yii::t('products', 'Ваша ставка перебита');
                        ?>
                    </div>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<hr>
<?php
if (!empty($product->price_stop) && $product->price_stop > $product->price * 0.8):
    ?>
    <?=
    $this->render('_form_buy', [
        'product' => $product,
    ]);
    ?>

<?php endif; ?>

<?php if ($popup): ?>
    <?=
    $this->render('_modalOwerStake', [
        'stake' => $stake,
    ]);
    ?>
<?php endif; ?>
<?php
$js = <<< JS
$.ready(setInterval(function(){
    ctdtime = $("#cdt-$product->id").runner('info').time;
    if(ctdtime > 86400000){  //24 часа
    del = 15;
    } else if(ctdtime > 43200000){ //12 часов
    del = 15;
    } else if(ctdtime > 10800000){ //3 часа
    del = 10;
    } else if(ctdtime > 3600000){
    del = 5;
    } else if(ctdtime > 900000){
     del = 3;
    } else{
    del = 1
    }
 //   console.log(Math.floor(ctdtime / 1000));
 //   console.log(del);
  if((Math.floor(ctdtime / 1000) % del) == 0 ){
    $.ajax({
        url:"/products/update-auction/$product->id/",
        dataType: 'json',
        success: function(data){

        $(".js_current-stake").html(data.currentStake);
        $(".number-stake").html(data.numberStake);
        $("#js_result-stakes").html(data.resultStakes);
        $(".js_next-stake").html(data.nextStakes);
 
        var cur_next = parseInt($("#js_next-amount").val());
        var old_next = parseInt(data.nextStakes);
        if(isNaN(cur_next)){
            $("#js_next-amount").val(old_next);
        }else{
            $("#js_next-amount").val(Math.max(old_next,cur_next));
        }
        $("#all-stake").html(data.allStakes);
        }
    });
    }
}, 1000));

JS;

$this->registerJs($js);
