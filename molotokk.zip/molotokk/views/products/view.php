<?php
/* @var $this yii\web\View */

use common\models\auktaModels\enumModels\StateProduct;
use common\models\User;
use molotokk\widgets\ModalLotMessages;
use common\widgets\ModalSendMessage;
use evgeniyrru\yii2slick\Slick;
use molotokk\models\AuctionStakes;
use newerton\fancybox\FancyBox;
use yii\bootstrap\Tabs;
use yii\helpers\Html;
use yii\widgets\Pjax;
use common\components\countTimer\CountTimer;
use yii\bootstrap\Nav;
use molotokk\widgets\UploadPhotoWidget;
use molotokk\widgets\Alert;

/* @var $model molotokk\models\Products */
/* @var $properties molotokk\models\ProductProperties[] */
/* @var $photos molotokk\models\ProductPhotos[] */
/* @var $user common\models\User */

if (!empty($model->slug)) {
    $this->registerLinkTag(
        [
            'rel' => 'canonical',
            'href' => 'http://www.aukta.ru'.$model->getUrl(),
        ]
    );
}
$main_photo                    = $model->getMainPhoto();
$this->title                   = $model->name;
$this->params['breadcrumbs']   = $model->category ? $model->category->getCategoryPathUrl()
        : ['Нет категории'];
$this->params['breadcrumbs'][] = [
    'label' => $this->title,
];
$items_action                  = $model->getItemsAction();
$user                          = $model->user;
$profile                       = $user->profile;
$items                         = [];
$mini_items                    = [];
//$main_photo                    = $model->getMainPhoto();
$photos                        = $model->productPhotos;
$this->registerMetaTag([
    'property' => 'og:image',
    'content' => $main_photo->getUrlPhoto(),
]);

$this->registerMetaTag([
    'property' => 'og:description',
    'content' => $model->description,
]);
$this->registerMetaTag([
    'property' => 'og:title',
    'content' => $this->title,
]);
if (!empty($photos)) {
    foreach ($photos as $photo) {
        $items[]      = Html::a(
                Html::img('',
                    [
                    'data-lazy' => $photo->getUrlPhoto(550, 420),
                    'style' => 'margin:auto',
                ]), $photo->getUrlPhoto(),
                ['rel' => 'fancybox', 'class' => 'fancybox-target']
        );
        $mini_items[] = '<img  data-lazy="'.$photo->getUrlPhoto(null, 96).'"  height="96" />';
    }
} else {
    $items[] = Html::img('@static/img/nophoto/nophoto.png');
}
$properties = $model->productProperties;
if (!empty($properties)) {
    foreach ($properties as $n => $property) {
        if (empty($property->__toString())) {
            unset($properties[$n]);
        }
    }
}
?>

<div class="row">
    <div class="col-md-6 lot-img">
        <?=
        Slick::widget(
            [
                'containerOptions' => ['class' => 'slider slider-for'],
                'items' => $items,
                'itemOptions' => [
                    'class' => 'product-image',
                ],
                'id' => 'slick_products-for',
                'clientOptions' => [
                    'lazyLoad' => 'ondemand',
                    'arrows' => false,
                    // 'adaptiveHeight' => true,                    
                    'slidesToShow' => 1,
                    'slidesToScroll' => 1,
                    'fade' => true,
                    'asNavFor' => '.slider-nav',
                ],
            ]
        );
        ?>

        <?php if (!empty($photos)): ?>
            <?=
            Slick::widget(
                [
                    'containerOptions' => ['class' => 'slider slider-nav'],
                    'items' => $mini_items,
                    'itemOptions' => ['class' => 'product-image-preview'],
                    'id' => 'slick_products-nav',
                    'clientOptions' => [
                        'lazyLoad' => 'progressive',
                        // 'adaptiveHeight' => true,
//                        'slidesToShow' => 4,
                        'slidesToScroll' => 1,
                        'asNavFor' => '.slider-for',
                        'dots' => false,
                        'centerMode' => true,
                        'focusOnSelect' => true,
                        'arrows' => true,
//                        'prevArrow' => '<button type="button" class="product-arrow slick-prev">Previous</button>',
//                        'nextArrow' => '<button type="button" class="product-arrow slick-prev">Previous</button>',
                        'variableWidth' => true,
                    ],
                ]
            );
            ?>
            <?=
            FancyBox::widget(
                [
                    'target' => 'a.fancybox-target',
                    'helpers' => true,
                    'mouse' => true,
                    'config' => [
                        'maxWidth' => '100%',
                        'maxHeight' => '100%',
                        'arrows' => true,
                        'prevEffect' => 'fade',
                        'nextEffect' => 'fade',
                        'closeBtn' => true,
                        'openOpacity' => true,
                        'helpers' => [
                            'title' => ['type' => 'float'],
                        //  'thumbs' => ['width' => 68, 'height' => 50],
                        ],
                    ],
                ]
            );
            ?>

        <?php endif; ?>
    </div>
    <div class="col-md-6">
        <?= Alert::widget() ?>
        <div class="row">
            <div class="col-md-12 lot-name">
                <?= $model->name ?>
            </div>
        </div>
        <div class="row lot-info">
            <div class="col-md-5">
                <i class="glyphicon glyphicon-calendar"></i>
                <?php
                if (empty($model->time_start) || $model->time_start > time()):
                    ?>
                    Торг не начат
                    <?php
                elseif (($model->time_end? : 0) < time()):
                    ?>
                    Торг завершен
                <?php else: ?>
                    <?=
                    CountTimer::widget([
                        'id' => 'cdt-'.$model->id,
                        'pluginOptions' => [
                            'autostart' => true,
                            'countdown' => true,
                            'startAt' => ($model->time_end - time()) * 1000,
                            'stopAt' => 0,
                        ],
                        'pluginEvents' => [
                            'runnerFinish' => 'function(){'
                            .'$.ajax({'
                            .'url:"/products/end-auction/'.$model->id.'/",'
                            .'success: function(){location.reload()},'
                            .'})}',
                        ],
                    ]);
                    ?>
                <?php endif; ?>

            </div>
            <?php
            if ($model->is_auction) {
                ?>
                <div class="col-md-2">
                    <i class="glyphicon glyphicon-piggy-bank"></i>

                    <?= count($model->auctionStakes) ?> ставок,
                    <?php
                    $maxStake = $model->getMaxStake();
                    if ($maxStake):
                        $maxStakeUser = User::findOne($maxStake->user_id);
                        ?>
                        <span class="lot-max-stake-user">
                            лидер <?= $maxStakeUser->username ?>
                        </span>

                    <?php endif; ?>
                </div>
                <?php
            }
            ?>
            <div
                class="col-md-3 lot-favorite js_action-favorit <?=
                (!empty($model->isMyFavorite()) ? 'red' : '')
                ?>"
                data-id="<?= $model->id ?>">
                <i class="glyphicon glyphicon-flag"></i><span>
                    <?=
                    empty($model->isMyFavorite()) ? 'В избранное' : 'В избранном'
                    ?></span>
            </div>
            <div class="col-md-2">
                <i class="glyphicon glyphicon-eye-open"></i>
                <?= $model->count_views ?>
            </div>
        </div>
        <div class="row lot-price-actions">
            <div class="col-md-5 price js_current-stake">
                <?= number_format($model->price, 0, '.', ' ').'  '.Yii::$app->params['currency']
                ?>
                <?php if (!$model->is_auction) : ?>
                                                                                                                                                                                                                                                                                                                                                        <!--                    <p class="user-price" data-toggle="modal" data-target="#price_offer_<?= $model->id ?>">
                                                                                                                                                                                                                                                                                                                                                                                Предложить свою цену
                                                                                                                                                                                                                                                                                                                                                                            </p>-->
                <?php else : ?>
                    <p class="actual-price">
                        Актуальная цена
                    </p>
                <?php endif ?>
            </div>
            <div class="col-md-7">
                <?php
                if ($model->user_id == Yii::$app->user->id):
                    ?>
                    <?=
                    $this->render(
                        '_self',
                        [
                        'product' => $model,
                        ]
                    )
                    ?>
                <?php elseif ($model->state_id == StateProduct::STATE_ON_SOLD): ?>
                    <?=
                    $this->render(
                        '_sold',
                        [
                        'product' => $model,
                        ]
                    )
                    ?>
                <?php elseif ($model->state_id == StateProduct::STATE_ON_HIDE): ?>
                    <?=
                    $this->render(
                        '_hide',
                        [
                        'product' => $model,
                        ]
                    )
                    ?>
                <?php elseif ($model->state_id == StateProduct::STATE_ON_AUCTION): ?>
                    <?php
                    Pjax::begin(
                        [
                            'id' => 'auction_form_pjax',
                            //'formSelector' => 'auction_form',
                            'enablePushState' => false,
                            'timeout' => 0,
                            'clientOptions' => [
                                'container' => '#auction_form',
                            ],
                        ]
                    );
                    ?>
                    <?=
                    $this->render(
                        '_form_auction',
                        [
                        'product' => $model,
                        'stake' => new AuctionStakes(),
                        'popup' => false,
                        ]
                    );
                    ?>
                    <?php Pjax::end(); ?>
                <?php elseif ($model->state_id == StateProduct::STATE_ON_SALE): ?>
                    <?=
                    $this->render(
                        '_form_buy',
                        [
                        'product' => $model,
                        ]
                    )
                    ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="row lot-about">
            <div class="col-md-6">
                <div>
                    Количество: <?= $model->quality ?>
                </div>
                <div>
                    Местоположение: <?= $model->getFullRegion() ?>
                </div>
                <div>
                    Доставку оплачивает: <?=
                    $model->is_deliverypay ? 'Продавец' : 'Покупатель'
                    ?>
                </div>
            </div>
            <div class="col-md-6">
                <?php if (!empty($items_action)): ?>
                    <?=
                    Nav::widget([
                        'items' => [
                            [
                                'label' => Yii::t('products', 'Действия'),
                                'items' => $items_action,
                            ],
                        ]
                    ])
                    ?>
                <?php endif; ?>
            </div>
        </div>
        <div class="row lot-seller-about">
            <div class="col-md-12">
                <div class="lot-seller">
                    <span class="">Продавец:</span>
                    <a href="/profile/view/<?= $user->id ?>/" class="seller">
                        <?= $user->username ?>(<?= $profile->rating ?>)
                    </a>
                </div>

                <div class="lot-seller-communication">
                    <a href="/profile/products-list/<?= $model->user_id ?>">
                        <i class="glyphicon glyphicon-list" aria-hidden="true"></i>
                        Все лоты продавца
                    </a>
                </div>

                <?php if ($model->user_id != Yii::$app->user->id): ?>
                    <div class="lot-seller-communication">
                        <a href="#" data-toggle="modal" data-target="#send_<?= $model->id ?>">
                            <i class="glyphicon glyphicon-envelope" aria-hidden="true"></i>
                            Задать вопрос
                        </a>
                    </div>
                <?php endif; ?>
                <div class="lot-seller-communication">
                    <a href="/profile/view/<?= $model->user_id ?>/">
                        <i class="glyphicon glyphicon-user" aria-hidden="true"></i>
                        Посмотреть отзывы
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-12 lot-description-block">
        <div class="lot-number">
            № лота <?= $model->id ?>
        </div>

        <?php
        echo Tabs::widget(
            [
                'id' => 'tabs-products',
                'itemOptions' => [
                    'class' => 'panel panel-body',
                ],
                'items' => [
                    [
                        'label' => 'Описание',
                        'content' => $this->render(
                            '_tags',
                            [
                            'tags' => $model->tags,
                            ]
                        ).'<p>'.(!empty($properties) ? $this->render(
                                '_property',
                                [
                                'properties' => $properties,
                                ]
                            ) : '').'<p>'.(!empty(nl2br($model->description)) ? nl2br($model->description)
                                : 'Описание товара отсутствует'.'</p>'),
                    ],
                    [
                        'label' => 'Фотографии',
                        'content' => UploadPhotoWidget::widget([
                            'product' => $model,
                        ]),
                        'visible' => ($model->user_id == Yii::$app->user->id),
                    ],
                    [
                        'label' => 'Ставки',
                        'encode' => false,
                        'content' => $this->render(
                            '_stakes',
                            [
                            'model' => $model,
                            ]
                        ),
                        'visible' => $model->is_auction,
                    ],
                    [
                        'label' => 'Доставка и оплата',
                        'content' => $this->render(
                            '_delivery_payment',
                            [
                            'model' => $model,
                            'profile' => $profile,
                            ]
                        ),
                    ],
                    [
                        'label' => 'Отзывы о продавце',
                        'content' => $this->render(
                            '_buyer-ratings',
                            [
                            'profile' => $profile,
                            ]
                        ),
                    ],
                ],
            ]
        )
        ?>
    </div>
</div>
<?=
ModalSendMessage::widget(
    [
        'profile' => $profile,
        'product_id' => $model->id,
    ]
);
?>
<?php if (!Yii::$app->user->isGuest): ?>
    <?=
    ModalLotMessages::widget(
        [

            'product' => $model,
            'type' => 'price_offer'
        ]
    )
    ?>
<?php endif; ?>

<?php
$js = <<< JS
        $('.js_action-favorit').click(function(){
            var favorite = $(this),
            product_id = favorite.data('id');
            $.ajax({
                  url:"/profile/favorite/" + product_id +"/",
                  success: function(data){
                        if(data == 0){
                            favorite.removeClass('red');
                            favorite.children("span").text(" В избранное");
                        } else {
                            favorite.addClass('red');
                            favorite.children("span").text(" В избранном");
                        }
                  }
            });
    return false;
        });
JS;

$this->registerJs($js);
