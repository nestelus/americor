<?php

//use yii;
use yii\bootstrap\Html;
use yii\widgets\Breadcrumbs;
use molotokk\assets\AppAsset;
use molotokk\widgets\Alert;

/* @var $this \yii\web\View */
/* @var $content string */

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
    <head>
        <meta charset="<?= Yii::$app->charset ?>">
        <!--<meta name="viewport" content="width=device-width, initial-scale=1">-->
        <?= Html::csrfMetaTags() ?>
        <title><?= Html::encode($this->title) ?></title>
        <?php $this->head() ?>


    </head>
    <body>
        <?php $this->beginBody() ?>
        <!-- Google Tag Manager -->
        <noscript>
        <iframe src="//www.googletagmanager.com/ns.html?id=GTM-PV6SNN"
                height="0" width="0" style="display:none;visibility:hidden">
        </iframe>
        </noscript>
        <script>
            (function (w, d, s, l, i) {
                w[l] = w[l] || [];
                w[l].push({'gtm.start':
                            new Date().getTime(), event: 'gtm.js'});
                var f = d.getElementsByTagName(s)[0],
                        j = d.createElement(s), dl = l != 'dataLayer' ? '&l=' + l : '';
                j.async = true;
                j.src =
                        '//www.googletagmanager.com/gtm.js?id=' + i + dl;
                f.parentNode.insertBefore(j, f);
            })(window, document, 'script', 'dataLayer', 'GTM-PV6SNN');
        </script>
        <!-- End Google Tag Manager -->
        <div id="wrapper">
            <?= $this->render('topmenu'); ?>
            <div class="container content">
                <div class="row">
                    <div class="col-md-12">
                        <?=
                        Breadcrumbs::widget(['links' => isset($this->params['breadcrumbs'])
                                    ? $this->params['breadcrumbs'] : []])
                        ?>
                    </div>
                </div>
                <?php
                if (!empty($this->blocks['content_header'])) {
                    ?>
                    <div class="row">
                        <div class="col-md-12">
                            <?= $this->blocks['content_header'] ?>
                        </div>
                    </div>
                    <?php
                    unset($this->blocks['content_header']);
                }
                ?>
                <div class="row">
                    <?php if (!empty($this->blocks)): ?>
                        <div class="col-md-3">
                            <div class="panel-group">
                                <?php
                                foreach ($this->blocks as $block) {
                                    echo $block;
                                }
                                ?>
                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="<?= empty($this->blocks) ? 'col-md-12' : 'col-md-9' ?>">
                        <?= Alert::widget() ?>
                        <?= $content ?>
                    </div>
                </div>
            </div>
        </div>
        <footer class="footer">
            <div class="container">
                <div class="row clearfix" style="font-size:12px;padding-top: 10px;">
                    <div class="pull-left footer-logo">
                        <a href="/">
                            <?=
                            Html::img('@static/img/aukta-logo-small.png',
                                ['alt' => 'logo-small']);
                            ?>
                        </a>
                    </div>
                    <div class="pull-right footer-links">
                        <?=
                        Html::a('Соглашение', '/site/oferta/')
                        ?>
                        <?=
                        Html::a('О торговой площадке', '#')
                        ?>
                        <?= Html::a('Помощь', '/help/') ?>
                    </div>
                </div>
                <div class="col-md-12 text-center" style="font-size:11px;padding-top: 25px;">
                    Используя aukta, Вы принимаете <?=
                    Html::a('Cоглашение', '/site/oferta/')
                    ?>
                </div>
            </div>
        </footer>
        <?php $this->endBody() ?>
    </body>
</html>
<?php $this->endPage() ?>
