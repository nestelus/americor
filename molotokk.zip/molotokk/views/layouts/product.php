<?php

use yii\bootstrap\Html;
use yii\widgets\Breadcrumbs;
use molotokk\assets\AppAsset;
use molotokk\widgets\Alert;

/* @var $this \yii\web\View */
/* @var $content string */

AppAsset::register($this);
?>
<?php $this->beginPage() ?>
<!DOCTYPE html>
<html lang="<?= Yii::$app->language ?>">
  <head>
    <meta charset="<?= Yii::$app->charset ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?= Html::csrfMetaTags() ?>
    <title><?= Html::encode($this->title) ?></title>
    <?php $this->head() ?>
    <!-- Google Analytics -->
    <script>
          (function (i, s, o, g, r, a, m) {
            i['GoogleAnalyticsObject'] = r;
            i[r] = i[r] || function () {
              (i[r].q = i[r].q || []).push(arguments)
            }, i[r].l = 1 * new Date();
            a = s.createElement(o),
                    m = s.getElementsByTagName(o)[0];
            a.async = 1;
            a.src = g;
            m.parentNode.insertBefore(a, m)
          })(window, document, 'script', '//www.google-analytics.com/analytics.js', 'ga');

          ga('create', 'UA-72543460-1', 'auto');
          ga('send', 'pageview');

    </script>
  </head>
  <body>
    <?php $this->beginBody() ?>
    <div class="wrap">

      <?= $this->render('topmenu'); ?>


      <div class="container" id="content">
        <div class="row">

          <?=
          Breadcrumbs::widget([
              'links' => isset($this->params['breadcrumbs']) ? $this->params['breadcrumbs'] : [],
          ])
          ?>
          <?= Alert::widget() ?>
          <div class="col-md-12">
            <?= $content ?>
          </div>
        </div>
      </div>
    </div>

    <footer class="footer">
      <div class="container">
        <p class="pull-left">&copy; AUKTA <?= date('Y') ?></p>
        <p class="pull-right"><?= Yii::powered() ?></p>
      </div>
    </footer>




    <?php $this->endBody() ?>
    <!--скрипт для корректного margin основной части сайта -->
    <script type="text/javascript">
          function resizeHeader() {
            $("div#content").css("margin-top", $("div#navbar-fixed-top").height() - 100 + "px");
          }
          $(document).ready(resizeHeader);
          $(window).resize(resizeHeader);
    </script>
    <!-- end of script -->
    <!--скрипт для привязки к топу шапки сайта -->
    <script type="text/javascript">
          $(function () {
            $('#navbar-fixed-top').scrollToFixed();
          });
    </script>
    <!-- end of script -->
  </body>

</html>
<?php $this->endPage() ?>
