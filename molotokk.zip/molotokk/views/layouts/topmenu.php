<?php

/**
 * @var yii\web\View $this
 *
 */
//use Yii;
use yii\bootstrap\Html;
use yii\bootstrap\Nav;
use yii\bootstrap\NavBar;
use yii\bootstrap\Dropdown;
use yii\bootstrap\ActiveForm;
use yii\helpers\ArrayHelper;
use common\models\auktaModels\Categories;

$menuItemsLeft  = [
    [
        'label' => 'Лоты от 1 рубля',
        'url' => '/products/one-rouble/'
    ],
    [
        'label' => 'Топы aukta',
        'url' => '#',
        'items' => [
            [
                'label' => 'Топ продавцов',
                'url' => '/site/top-seller/'
            ],
            [
                'label' => 'Самые удачные аукционы',
                'url' => '/site/top-auctions/'
            ],
            [
                'label' => 'Самые дорогие покупки',
                'url' => '/site/top-buys/'
            ],
        ],
    ]
];
$menuItemsRight = [
    ['label' => 'Продать', 'url' => ['/admin-product/create/']],
    [
        'label' => Yii::t('nc_users', 'Моя aukta'),
        'url' => '/profile/cabinet/',
        'options' => [
            'class' => 'js_myAukta_button dropdown'
        ],
        'items' => [
            [
                'label' => 'Мои покупки',
                'url' => '/profile/buys/'
            ],
            [
                'label' => 'Мои продажи',
                'url' => '/profile/sales/'
            ],
            [
                'label' => 'Мои настройки',
                'url' => '/user/settings'
            ],
            [
                'label' => 'Отзывы',
                'url' => '/profile/view/'.Yii::$app->user->id,
            ],
            [
                'label' => 'Лоты в продаже',
                'url' => '/profile/product-list/'.Yii::$app->user->id,
            ],
            [
                'label' => 'Обо мне',
                'url' => '/profile/about/'.Yii::$app->user->id,
            ],
//            [
//                'label' => 'Сообщения',
//                'url' => '/profile/cabinet/?tab=cabinet_messages&tab_content=active_bids'
//            ],
        ],
    ],
    ['label' => 'Задать вопрос', 'url' => ['/site/contact']],
//    ['label' => 'Обратная связь', 'url' => ['/site/contact/']],
];
if (!Yii::$app->user->isGuest) {
    $menuItemsRight[] = [
        'label' => Yii::$app->user->identity->username.'!',
        'url' => '/profile/buys/',
    ];
    $menuItemsRight[] = [
        'label' => '<span class="glyphicon glyphicon-bell"></span>'
        .'<span class = "js_count-messages" lot ="0" direction ="0" from ="0"></span>',
        'url' => '/messages/messages/',
    ];

    $menuItemsRight[] = [
        'label' => Yii::t('nc_users', 'Выйти'),
        'url' => ['/site/logout/'],
        'linkOptions' => ['data-method' => 'post'],];
} else {
    $menuItemsRight[] = ['label' => Yii::t('nc_users', 'Регистрация'), 'url' => ['/user/registration/register/']];
    $menuItemsRight[] = ['label' => Yii::t('nc_users', 'Войти'), 'url' => ['/user/security/login/'],];
}
$items = Categories::getMenuItems();
?>
<div id="mobile-menu" class="visible-xs-block">
    <ul class="list-group" style="border-radius:0;">
        <?php
        foreach ($items as $id => $item) {
            echo Html::tag('li',
                Html::a($item['name'], $item['url'], ['style' => 'color:black;']),
                ['class' => 'list-group-item']);
        }
        foreach ($menuItemsLeft as $value) {
            $dropdown = !empty($value['items']);
            $aOptions = $dropdown ? ['class' => 'dropdown-toggle', 'data-toggle' => 'dropdown']
                    : [];
            echo Html::beginTag('li',
                ['class' => 'list-group-item mobile-menu-item-black '.($dropdown
                        ? 'dropup' : '')]);
            echo Html::a($value['label'], $value['url'], $aOptions);
            if ($dropdown) {
                echo Html::beginTag('ul', ['class' => 'dropdown-menu']);
                foreach ($value['items'] as $val) {
                    echo Html::tag('li', Html::a($val['label'], $val['url']));
                }
                echo Html::endTag('ul');
            }
            echo Html::endTag('li');
        }
        foreach ($menuItemsRight as $value) {
            $dropdown = !empty($value['items']);
            $aOptions = $dropdown ? ['class' => 'dropdown-toggle', 'data-toggle' => 'dropdown']
                    : [];
            echo Html::beginTag('li',
                ['class' => 'list-group-item mobile-menu-item-black '.($dropdown
                        ? 'dropup' : '')]);
            echo Html::a($value['label'], $value['url'], $aOptions);
            if ($dropdown) {
                echo Html::beginTag('ul',
                    ['class' => 'dropdown-menu', 'style' => 'position:absolute;']);
                foreach ($value['items'] as $val) {
                    echo Html::tag('li', Html::a($val['label'], $val['url']));
                }
                echo Html::endTag('ul');
            }
            echo Html::endTag('li');
        }
        ?>
    </ul>
</div>

<div class="aukta-header">
    <?php
    NavBar::begin(['brandLabel' => FALSE,
        'options' => [
            'class' => 'navbar navbar-default',
        ],
    ]);
    echo Nav::widget([
        'options' => ['class' => 'navbar-nav navbar-left'],
        'items' => $menuItemsLeft,
        'dropDownCaret' => '',
    ]);
    echo Nav::widget([
        'options' => ['class' => 'navbar-nav navbar-right'],
        'items' => $menuItemsRight,
        'dropDownCaret' => '',
        'encodeLabels' => false,
    ]);
    NavBar::end();
    ?>
    <div class="container search-block">
        <div class="row">
            <div class="visible-xs-block mobile-menu-button col-xs-1 text-center">
                <?=
                Html::img('@static/img/mobile-menu-button.png',
                    [
                    'alt' => 'Открыть меню',
                    'width' => 40,
                    'height' => 40,
                    'id' => 'mobile-menu-button'
                ]);
                ?>
            </div>
            <div class="col-md-2 col-xs-3 col-sm-3">
                <a href="/">
                    <?=
                    Html::img('@static/img/aukta-logo.png', ['alt' => 'logo']);
                    ?>
                </a>
            </div>
            <div class="col-md-10 col-xs-7 col-sm-9">
                <?php
                ActiveForm::begin([
                    'action' => '/sphinx/search/',
                    'method' => 'get',
                    'options' => [
                        'class' => 'sphinx-search',
                        'renderInnerContainer' => false,
                    ],
                ]);
                ?>
                <div class="input-group search-group">
                    <div class="input-group-btn">
                        <select class="selectpicker" id="searchCategory" name="category_id">
                            <?php
                            $categorySearchItems = Categories::getSearchItems();
                            echo Html::tag('option', 'Все разделы',
                                ['value' => '']);
                            foreach ($categorySearchItems as $id => $value) {
                                if (!is_array($value)) {
                                    $selected = $id == Yii::$app->request->get('category_id')
                                            ? ['selected' => "selected"] : [];
                                    echo Html::tag('option', $value,
                                        ArrayHelper::merge(['value' => $id],
                                            $selected));
                                } else {
                                    echo Html::tag('option', '',
                                        ['data-divider' => 'true']);
                                    foreach ($value as $key => $val) {
                                        $selected = $key == Yii::$app->request->get('category_id')
                                                ? ['selected' => "selected"] : [];
                                        echo Html::tag('option', $val,
                                            ArrayHelper::merge(['value' => $key],
                                                $selected));
                                    }
                                }
                            }
                            ?>
                        </select>
                    </div><!-- /btn-group -->
                    <?=
                    Html::textInput('searchText',
                        isset(Yii::$app->request->get()['searchText']) ? Yii::$app->request->get()['searchText']
                                : null,
                        [
                        'class' => 'form-control',
                        'placeholder' => 'Поиск...',
                        'aria-label' => '...',
                    ]);
                    ?>
                    <!--input name="searchText" type="text"  class="form-control" aria-label="..."-->
                    <div class="input-group-btn search-btn">
                        <?=
                        Html::submitButton('Найти',
                            ['class' => 'btn btn-default'])
                        ?>
                    </div><!-- /btn-group -->
                </div><!-- /input-group -->
                <?php ActiveForm::end() ?>
            </div>
        </div>
        <div class="row category-menu">
            <div class="col-md-12 clearfix">
                <?php
                $itemsDropDown = [];
                foreach ($items as $id => $item) {
                    if ($id < 6) {
                        ?>
                        <div class="category-menu-item">
                            <a href="<?= $item['url'] ?>">
                                <?= $item['name'] ?>
                            </a>
                        </div>
                        <?php
                    }
                    $itemsDropDown[] = ['label' => $item['name'], 'url' => $item['url'],
                        'options' => ['class' => 'dropdown-category-menu-item']];
                }
                ?>
                <div class="pull-left dropdown category-menu-item">
                    <div class="dropdown-toggle category-menu-dropdown-button" data-toggle="dropdown"
                         aria-haspopup="true">
                        Другое в коллекционировании
                    </div>
                    <?php
                    echo Dropdown::widget([
                        'items' => $itemsDropDown,
                        'options' => ['class' => 'dropdown-menu-right scrollable-dropdown']
                    ]);
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
if (!Yii::$app->user->isGuest):
    $js = <<<JS
 
   countMessages();
   setInterval(function(){
     console.log('check');
       checkMessages();
           }, 10000);
  
   
JS;
    $this->registerJs($js, $this::POS_READY);
endif;
?>
