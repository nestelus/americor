<?php

/**
 * Description of LoginWidget:
 *
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */

namespace molotokk\widgets;

use Yii;
use common\models\LoginForm;

class LoginWidget extends \yii\base\Widget {

      public $validate = true;

      public function init() {
            parent::init();
      }

      public function run() {
            $model  = new LoginForm();
            $action = ['/site/login/'];


            if ($this->validate && $model->load(\Yii::$app->request->post()) && $model->login())
            {
                  return Yii::$app->response->redirect('/');
            }
            return $this->render('login', [
                        'model'  => $model,
                        'action' => $action,
            ]);
      }

}
