<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace molotokk\widgets;

use yii\bootstrap\Widget;

/**
 * Description of UploadPhotoWidget
 *
 * @author Vladimir
 */
class UploadPhotoWidget extends Widget
{
    public $product;
    public $modal  = true;
    public $galery = true;

    public function run()
    {
        $output = '';
        if ($this->galery) {
            $output .= $this->render('photo-galery',
                [
                'model' => $this->product,
            ]);
        }
        if ($this->modal) {
            $output .= $this->render('photo-uploader',
                [
                'model' => $this->product,
            ]);
        }
        return $output;
    }
}
