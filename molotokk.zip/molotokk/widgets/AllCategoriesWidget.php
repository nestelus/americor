<?php

namespace molotokk\widgets;

use yii\base\Widget;
use common\models\auktaModels\Categories;
use yii\bootstrap\Nav;

/**
 * Description of AllCategoriesWidget
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class AllCategoriesWidget extends Widget
{
      public $parent = null;
      public $mode   = 'all-categories';
      protected $items;

      public function init()
      {

            $categories = Categories::findAll(['parent_id' => $this->parent]);
            foreach ($categories as $category)
            {
                  $this->items[] = $this->_getSubCategory($category);
            }
      }

      private function _getSubCategory($category_parent)
      {

            $item['label'] = $category_parent->name;
            $category      = Categories::findAll(['parent_id' => $category_parent->id]);
            if (count($category) > 0)
            {
                 
                  foreach ($category as $subcategory)
                  {
                        $item['items'][] = $this->_getSubCategory($subcategory);
                  }
            }

            $item['url'] = '/products/categories/'.$category_parent->id.'/';


            // $items[] = $item;

            return $item;
      }

      public function run()
      {
            return $this->render($this->mode, [
                    'items' => $this->items
            ]);
      }

      public function getItems()
      {
            return $this->items;
      }
}