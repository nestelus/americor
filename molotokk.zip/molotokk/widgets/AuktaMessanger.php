<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace molotokk\widgets;

use yii\base\Widget;

/**
 * Description of AuktaMessanger
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class AuktaMessanger extends Widget {

      public $product;
      public $direction; // '
      public $user;
      public $buttonName = "Отправить";
      protected $html;
      protected $uniq_id;

      public function init() {
            parent::init();
            $this->uniq_id = $this->createId();
      }

      protected function createId() {
            $length   = 5;
            $chars    = 'abdefhiknrstyzABDEFGHKNQRSTYZ23456789';
            $numChars = strlen($chars);
            $string   = '';
            for ($i = 0; $i < $length; $i++)
            {
                  $string .= substr($chars, rand(1, $numChars) - 1, 1);
            }
            return 'messag_' . $string;
      }

      public function run() {

            return $this->render('aukta-messenger', [
                        'uniq_id'   => $this->uniq_id,
                        'products'  => $this->getProducts(),
                        'direction' => $this->direction,
            ]);
      }

      public static function getUserList($products, $direction, $searchMessageUser) {
            return $this->render('_message_user-list', [
                        'products'          => $products,
                        'direction'         => $direction,
                        'searchMessageUser' => $searchMessageUser,
            ]);
      }

      protected function getProducts() {
            if (!$this->product)
            {
                  $lots = \Yii::$app->mymessages->getMyDialogs($this->direction);
            }
            else
            {
                  $lots[$this->product->id] = [$this->user];
            }
            return $lots;
      }

}
