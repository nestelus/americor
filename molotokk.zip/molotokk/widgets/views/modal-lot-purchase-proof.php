<?php
/* @var $this yii\web\View */
/* @var $profile common\models\User */
/* @var $product molotokk\models\Products */

use yii\bootstrap\Modal;
use yii\helpers\Html;
use yii\web\JsExpression;
use yii\widgets\Pjax;

Modal::begin(
    [
        'options' => [
            'id' => 'modal_buy-form',
            'class' => 'modal-lot-purchase-proof-block',
        ],
        'clientEvents' => [
            'show.bs.modal' => new JsExpression(
                'function(){'
                .'if($("#buy-form").find(".has-error").length){return false;} ;}'
            ),
            'shown.bs.modal' => new JsExpression(
                'function(){'
                .'total_amount = parseInt($("#sales-quality").val())*'.max($product->price_stop ?
                            : 0, $product->price? : 0).' ;'
                .'$("#js_total-amount").text(total_amount) ;'
                .'$("#js_total-quality").text(parseInt($("#sales-quality").val()));}'
            ),
        ],
    ]
);
?>
<div class="row">
    <div class="col-md-12 text-center">
        <p class="lot-phrase">
            Вы собираетесь купить лот <span>"<?= $product->name ?>"</span>
            <?php if ($product->is_multilot) : ?>
                в количестве <span id="js_total-quality">1</span> шт.
            <?php endif; ?>
            стоимостью
            <span id="js_total-amount"><?=
                number_format(
                    ($product->is_auction ? $product->price_stop : $product->price),
                    0, '.', ' '
                ).'</span> '.Yii::$app->params['currency']
                ?>.
        </p>
        <div>

            <?php
            Pjax::begin(
                [
                    'options' => [
                        'id' => 'pj_del_adresses',
                    ],
                    'formSelector' => '#pj_delivery-adresses-form',
                    'enablePushState' => false,
                    'timeout' => 0,
                ]
            )
            ?>
            <?=
            $this->render(
                '_delivery_address',
                [
                'profile' => $profile,
                ]
            )
            ?>
            <?php Pjax::end() ?>
        </div>
        <p>
            Можете оставить комментарий для продавца
        </p>
        <?=
        Html::textarea('description', null,
            [
            'cols' => 0,
            'rows' => 0,
            'class' => 'form-control',
            'form' => 'buy-form',
        ])
        ?>

        <p class="btn-purchase-proof-block">
            <?=
            Html::submitButton(
                Yii::t('products', 'Купить'),
                [
                'class' => 'btn btn-success btn-bg-orange-red',
                'id' => 'btn-buy',
                'form' => 'buy-form',
                'onClick' => "ga('send', 'event', 'Покупка', 'Клик подтверждения')",
                ]
            );
            ?>
        </p>
        <p class="notification">
            Нажимая "Купить" Вы соглашаетесь с
            <?=
            Html::a(
                'правилами пользования', ['#'],
                [
                'data-toggle' => 'modal',
                'data-target' => '#offerta',
                ]
            )
            ?>
            и приобретаете лот на условиях из его описания.
        </p>
    </div>
</div>
<?php
Modal::end();
Modal::begin(
    [
        'size' => 'modal-lg',
        'options' => [
            'id' => 'offerta',
        ],
        'header' => '<h2>Правила пользования сервисом "АУКТА"</h2>',
    ]
);
echo $this->render('oferta');
Modal::end();
