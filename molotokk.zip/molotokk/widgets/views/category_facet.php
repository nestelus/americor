<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/* @var $items array() */
use yii\helpers\Html;

?>
<ul class="list-group category_facet_ul">
    <?php if (!empty($header)) : ?>
    <li  class="list-group-item category_facet_header">
        <?= $header ?>
    </li>
    <?php endif; ?>
    <?php
    foreach ($items as $item) {
        echo Html::beginTag('li', ['class' => 'list-group-item']);
        if (!empty($item['url'])) {
            echo Html::a($item['label'], $item['url']);
        } else {
            echo $item['label'];
        }
        if (isset($item['count'])) {
            echo Html::beginTag('span', ['class' => 'badge']);
            echo $item['count'];
            echo Html::endTag('span');
        }
        echo Html::endTag('li');
    }
    ?>
</ul>