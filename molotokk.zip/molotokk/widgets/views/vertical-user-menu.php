<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use yii\bootstrap\Collapse;
use yii\bootstrap\Nav;

foreach ($set as $section)
{
      $item = [];
      $item['label'] =  $items[$section]['label'];
      $item['content'] = Nav::widget([
              'encodeLabels' => false,
              'items' => $items[$section]['items'],              
          ]);
             
      if($section == $current || $current == 'all' )  {      
           $item['contentOptions'] = ['class' => 'in'];
      }
      $items_collapse[] = $item;
     
}
echo Collapse::widget([
    'items' => $items_collapse,
    'encodeLabels' => false,
]);
