<?php

/**
 * @var yii\web\View                   $this
 *
 */
use molotokk\models\Products;
use yii\helpers\Html;
?>



<div class="input-group">

    <?=
    Html::textInput('searchMessageUser', $searchMessageUser ? : null,
        [
        'id' => 'searchMessageUser',
        'class' => 'form-control',
        'placeholder' => Yii::t('nc_users', 'Поиск...'),
    ]);
    ?>



</div>

<?php
foreach ($products as $lot_id => $users):

    $lot   = Products::findOne($lot_id);
    $photo = $lot->getProductPhotos()->one();
    ?>
    <div>
        <div class="product-name"><?= $lot->name ?></div>

        <div class="product-img">
            <?=
            Html::a(Html::img($photo ? $photo->getUrlPhoto(150, 150) : '',
                    [
                    'width' => 150,
                    'hieght' => 150,
                ]), $lot->getUrl());
            ?>
        </div>
    </div>

    <ul class="list_users message-user-list">

        <?php foreach ($users as $usr): ?>
            <li class="contact" data-user="<?= $usr->id ?>"  data-product="<?= $lot_id ?>" data-direction="<?= $direction ?>">
                <a href="#">
                    <span class="user-title"><?= $usr->username ?>
                        <span class="cnt"></span>
                    </span>
                </a>
            </li>
        <?php endforeach; ?>
    </ul>
<?php endforeach; ?>
