<?php

/**
 * @var yii\web\View                   $this
 * @var string $uniq_id
 */
use yii\widgets\ActiveForm;
use common\models\auktaModels\Messages;
use molotokk\components\MyMessages;
use molotokk\assets\MessageAsset;

//use yii\jui\AutoComplete;
?>

<div id="<?= $uniq_id ?>" class="main-message-container">
  <div class="message-north">
    <div class="list_product" >
      <!-- User List -->
      <?=
      $this->render('_message_user-list', [
          'products'          => $products,
          'direction'         => $direction,
          'searchMessageUser' => '',
      ])
      ?>
    </div>

    <!-- End UserList -->
    <!-- Box Messages -->
    <div class="message-container message-thread">
    </div>
    <!-- End Box Messages -->
  </div>
  <div class="message-south">
    <?php
    $message = new Messages();
    $form    = ActiveForm::begin([
                'action'  => '#',
                'options' => [
                    'class' => 'message-form hidden',
                ],
                'method'  => 'POST',
            ])
    ?>
    <?=
    $form->field($message, 'message')->textarea([
        'placeholder' => 'Введите сообщение',
    ]);
    ?>

    <input type="hidden" name="message_id_user" value="">
    <input type="hidden" name="message_id_product" value="">
    <input type="hidden" name="message_direction" value="<?= $direction ?>">
    <button type="submit">Отправить</button>
    <?php if (\Yii::$app->mymessages->enableEmail || $direction == 0) : ?>
          <span class="send_mail">
            <input class="checkbox" id="send_mail" type="checkbox" name="send_mail" value="1">
            <label for="send_mail">Отправить также на email</label>
          </span>
    <?php endif; ?>
    <?php ActiveForm::end() ?>
  </div>


</div>

<?php
MessageAsset::register($this);
$var_name = 'mess_' . $uniq_id;
$base     = "var baseUrlPrivateMessage ='" . \Yii::$app->mymessages->nameController . "';";
$this->registerJs($base, $this::POS_BEGIN);
$script   = 'var ' . $var_name . ' = new visiPrivateMessages("#' . $uniq_id . '");';
if ($direction === MyMessages::DIRECTION_FROM_SYSTEM)
{
      $script .= "$var_name.getSystemMessages();";
}
else
{
      $script .= "$var_name.getAllMessages();";
}

$script .='$(".contact").click();';
$script .='$("#searchMessageUser").change();';
$this->registerJs($script, $this::POS_READY);
?>
