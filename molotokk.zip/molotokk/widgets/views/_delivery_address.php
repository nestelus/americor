<?php

use yii\helpers\Html;
use yii\bootstrap\Collapse;
use molotokk\models\DeliveryAddresses;
use yii\helpers\ArrayHelper;
?>


<?php
//if (!empty($profile->deliveryAdresses)) :
$items[] = [
    'label' => 'Адрес доставки для данного лота',
    'content' => Html::dropDownList(
        'delivery_address', null,
        ArrayHelper::map($profile->deliveryAdresses, 'id', 'name'),
        [
        'class' => 'form-control',
        'form' => 'buy-form',
        'prompt' => 'Укажите адрес доставки из списка, или добавьте новый'
    ]),
    'contentOptions' => ['class' => empty($profile->deliveryAdresses) ? '' : 'in'],
];
//endif;
$items[] = [
    'label' => 'Добавить новый адрес доставки',
    'content' => $this->render('_delivery-adresses_form',
        [
        'model' => new DeliveryAddresses(),
    ]),
    'contentOptions' => ['class' => empty($profile->deliveryAdresses) ? 'in' : ''],
];
?>


<div class="form-group">
    <?=
    Collapse::widget([
        'items' => $items,
        'encodeLabels' => false,
    ]);
    ?>

</div>
