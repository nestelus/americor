<?php

use evgeniyrru\yii2slick\Slick;
?>
<?=
Slick::widget([

    // HTML tag for container. Div is default.
    'itemContainer' => 'div',
    // HTML attributes for widget container
    'containerOptions' => ['class' => 'carousel', 'id' => $id,],
    // Items for carousel. Empty array not allowed, exception will be throw, if empty
    'items' => $items,
    // HTML attribute for every carousel item
    'itemOptions' => ['class' => 'cat-image'],
    // settings for js plugin
    // @see http://kenwheeler.github.io/slick/#settings
    'clientOptions' => [
        'lazyLoad' => 'ondemand',
        'autoplay' => true,
        'adaptiveHeight' => true,
        'variableWidth' => true,
//                    'responsive' => [
//                        [
//                            'breakpoint' => 1200,
//                            'settings' => [
//                                'slidesToShow' => 6,
//                                'slidesToScroll' => 3,
//                            ],
//                        ],
//                        [
//                            'breakpoint' => 920,
//                            'settings' => [
//                                'slidesToShow' => 5,
//                                'slidesToScroll' => 2,
//                            ],
//                        ],
//                        [
//                            'breakpoint' => 768,
//                            'settings' => [
//                                'slidesToShow' => 4,
//                                'slidesToScroll' => 1,
//                            ],
//                        ],
//                    ],
        'arrows' => false,
        'dots' => true,
        'speed' => 300,
        'autoplay' => true,
        'infinite' => true,
        'respondTo' => 'slider',
        'centerMode' => true,
    ],
]);
?>
