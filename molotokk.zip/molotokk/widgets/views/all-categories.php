<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


use yii\bootstrap\Nav;

?>
<div class="panel panel-success">
  <div class="panel-heading">
    <span>

      <?= Yii::t('products', 'Категории') ?>

    </span>
    <a href="/products/categories/">Смотреть все ></a>

  </div>
  <div id="collapseCategory" class="panel-collapse collapse in">

    <?=
    Nav::widget([
        'items' => $items,
    ])
    ?>
  </div>
</div>

