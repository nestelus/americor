<?php

use yii\helpers\Url;
use yii\widgets\ActiveForm;
use yii\bootstrap\Modal;
use kartik\widgets\FileInput;

/* @var $this yii\web\View */
/* @var $model molotokk\models\Products */
/* @var $properties molotokk\models\ProductProperties[] */
/* @var $photos molotokk\models\ProductPhotos[] */
/* @var $deliveries molotokk\models\DeliveryTypes[] */
/* @var $payments molotokk\models\PaymentTypes[] */

$photos    = $model->getProductPhotos()->all();
?>
<?php
Modal::begin(
    [
        'size' => 'modal-lg',
        'options' => [
            'id' => 'modal-upload',
        ],
        'header' => '<h2>'.Yii::t('products', 'Add photo').'</h2>',
        'footer' => 'Вы можете загузить за один раз не более 10 файлов с расширениями .png, .jpg, или .jpeg. </br>'
        .'Размер каждого файла не должен превышать 2М',
    ]
);
$formPhoto = ActiveForm::begin(
        [
            'options' => [
                'id' => 'form-photo-uploads',
                'data-pjax' => 1,
                'enctype' => 'multipart/form-data', // important
            ],
        ]
);

// your fileinput widget for single file upload
echo $formPhoto->field($model, 'uploadImages[]')->widget(
    FileInput::className(),
    [
    'language' => 'ru',
    'options' => [
        'multiple' => true,
    ],
    'pluginOptions' => [
        'language' => 'ru',
        'previewFileType' => 'image',
        'allowedFileExtensions' => ['jpg', 'png', 'jpeg'],
        'AllowedFileTypes' => 'image',
        'allowedPreviewTypes' => 'image',
        'maxFileCount' => 10,
        'uploadAsync' => true,
        'uploadUrl' => Url::to(['/admin-product/upload-photos/'."$model->id/"]),
        'maxImageWidth' => 1200,
        'maxImageHeight' => 900,
        'resizeImage' => true,
        'resizePreference' => 'width',
        'validateInitialCount' => true,
        'overwriteInitial' => true,
        'showPreview' => true,
        'showClose' => false,
        'initialPreviewConfig' => [
            'frameAttr' => [
                'height' => '100px',
            ],
        ],
    ],
    'pluginEvents' => [
        'filebatchuploadcomplete' => 'function(event, data, previewId, index) {'

        //       .'$("#form-photo-uploads").submit();'
        .'$("#modal-upload").modal("hide");'
        .'$(this).fileinput("clear");'
        .'$.ajax({'
        .'url: "/admin-product/render-photos/'.$model->id.'",'
        .'  success: function (data) {'
        .'  $("#upload-photo").html(data);'
        .'}'
        .'});'
        .'}',
    ],
    ]
)->label(false);
?>
<?php ActiveForm::end(); ?>
<?php
Modal::end();


