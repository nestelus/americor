<?php
/* @var $this yii\web\View */
/* @var $model common\models\auktaModels\Products */
/* @var $category common\models\auktaModels\Categories */
/* @var $parent common\models\auktaModels\Categories */
/* @var $grand -parent common\models\auktaModels\Categories */

use yii\helpers\Html;
use kartik\widgets\DepDrop;
use yii\helpers\ArrayHelper;
use molotokk\models\Categories;
use yii\helpers\Url;
use yii\bootstrap\ActiveForm;
use yii\widgets\Pjax;

$categorySelected = !empty($model->category_id);
?>
<?php
Pjax::begin([
    //  'formSelector' => '#js_change_category-form',
    //  'linkSelector' => '#js_categories_user_change',
    'enablePushState' => false,
    'enableReplaceState' => false,
    'id' => 'pj_category_change',
    'timeout' => 0,
]);
?>
<?php if ($categorySelected) : ?>
    <div  class="row form-horizontal">
        <label  class="col-md-3 col-lg-2 text-right">
            <?= Yii::t('products', 'Категория') ?>
        </label>
        <div class="col-md-8 col-lg-9">
            <span id="js_categories_path" >
                <?= $model->category->getCategoryPath(); ?>
            </span>          
            <a id ="js_categories_user_change" class="link_like <?=
            $change ? 'hidden' : ''
            ?>"  href="/admin-product/category-expand/<?= $model->id ?>">
                изменить
            </a>


        </div>

    </div>
<?php endif; ?>
<?php if ($change): ?>

    <?php
    $form = ActiveForm::begin(
            [
                'id' => 'js_change_category-form',
            ]
    );
    echo Html::hiddenInput(
        'product_id', $model->id, [
        'id' => 'js_product_id',
        ]
    );
    ?>

    <div id="admin-product-category-change-block" class="row ">
        <div class="col-md-12">
            <div class="row">
                <label class="col-md-3 col-lg-2 text-right">
                    <?=
                    Yii::t('products', 'Выберите категорию')
                    ?>
                </label>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <?=
                    $form->field($parent, 'parent_id')->dropDownList(
                        ArrayHelper::map(Categories::findAll(['parent_id' => null]),
                            'id', 'name'),
                        [
                        'id' => 'cat-id',
                        'size' => 6,
                        'class' => 'form-control',
                        ]
                    )->label(false);
                    ?>
                </div>
                <div class="col-md-4">
                    <?=
                    $form->field($parent, 'id')->widget(
                        DepDrop::classname(),
                        [
                        'options' => [
                            'id' => 'subcat-id',
                            'size' => 6,
                        ],
                        'data' => [$parent->id => $parent->name],
                        'pluginOptions' => [
                            'language' => 'ru',
                            'depends' => ['cat-id'],
                            'initialize' => true,
                            'placeholder' => 'Выберите...',
                            'url' => Url::to(['/admin-product/subcat/', 'id' => 0]),
                        ],
                        ]
                    )->label(false);
                    ?>
                </div>
                <div class="col-md-4">
                    <?=
                    $form->field($category, 'id')->widget(
                        DepDrop::classname(),
                        [
                        'options' => [
                            'size' => 6,
                        ],
                        'data' => [$category->id => $category->name],
                        'pluginOptions' => [
                            'language' => 'ru',
                            'depends' => ['cat-id', 'subcat-id'],
                            'initialize' => true,
                            'placeholder' => 'Выберите...',
                            'url' => Url::to(['/admin-product/subcat/', 'id' => 1]),
                        ],
                        ]
                    )->label(false);
                    ?>
                </div>
            </div>


            <div class="row">
                <div class="col-md-3">
                    <?=
                    Html::button(
                        'Выбрать',
                        [
                        'class' => 'btn btn-bg-orange-red btn-submit-lot',
                        'id' => 'js_change_category',
                        'disabled' => $categorySelected ? '' : 'disable',
                        ]
                    );
                    ?>
                    <?php if ($categorySelected) : ?>
                        <span id="js_categories_user_cancel" class="link_like"> отмена </span>
                    <?php endif; ?>
                </div>

            </div>
        </div>
    </div>
    <?php ActiveForm::end(); ?>

<?php endif; ?>
<?php Pjax::end() ?>
