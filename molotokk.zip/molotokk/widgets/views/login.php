<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/**
 * @var yii\web\View                   $this
 * @var dektrium\user\models\LoginForm $model
 */
?>


<div class="panel panel-default">
  <div class="panel-heading">
    <h3 class="panel-title">Вход в систему</h3>
  </div>
  <div class="panel-body">
    <?php
    $form = ActiveForm::begin([
                'id'          => 'login-widget-form',
                'action'      => $action,
                'fieldConfig' => [
                    'template' => "{input}\n{error}"
                ],
            ])
    ?>

    <?= $form->field($model, 'username')->textInput(['placeholder' => 'Login']) ?>

    <?= $form->field($model, 'password')->passwordInput(['placeholder' => 'Password']) ?>

    <?= $form->field($model, 'rememberMe')->checkbox() ?>

    <?= Html::submitButton(Yii::t('user', 'Sign in'), ['class' => 'btn btn-primary btn-block']) ?>

    <?php ActiveForm::end(); ?>
  </div>
</div>
<?php //if ($module->enableConfirmation):  ?>
<p class="text-center">
  <?= Html::a(Yii::t('user', 'Forgot password?'), ['/site/request-password-reset/']) ?>
</p>
<?php // endif  ?>
<?php //if ($module->enableRegistration): ?>
<p class="text-center">
  <?= Html::a(Yii::t('user', 'Don\'t have an account? Sign up!'), ['/site/signup/']) ?>
</p>
<?php // endif  ?>
<?=
yii\authclient\widgets\AuthChoice::widget([
    'baseAuthUrl' => ['site/auth'],
    'popupMode'   => TRUE,
])
?>

