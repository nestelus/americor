<?php
/* @var $this yii\web\View */
/* @var $profile common\models\User */
/* @var $product molotokk\models\Products */

use yii\bootstrap\Modal;
use yii\helpers\Html;
use yii\widgets\ActiveForm;

Modal::begin(
    [
        'options' => [
            'id' => 'price_offer_'.$product->id,
            'class' => 'modal-lot-offer-price-block',
        ],
        'header' => '',
    ]
);
?>
    <div class="row">
        <div class="col-md-12 text-center modal-lot-offer-price">
            <?php
            $form = ActiveForm::begin(
                [
                    'id' => 'form-offer-price-' . $product->id,
                    'action' => '#',
                ]
            );
            ?>
            <p class="text">
                Лот
            </p>
            <p class="lot-name">
                <?= $product->name ?>
            </p>
            <p class="text">
                Текущая цена
            </p>
            <p class="price">
                <?= number_format($product->price, 0, '.', ' ') . '  ' . Yii::$app->params['currency'] ?>
            </p>
            <p class="text">
                Укажите свою цену, отличную от установленной продавцом,
                за единицу и желаемое количество товара
            </p>
            <p class="offer-price">
                <?= Html::input(
                    'text',
                    'offer-price',
                    '',
                    ['class' => 'form-control', 'placeholder' => round($product->price)]
                ) ?>
                <?= Html::input('text', 'offer-quantity', '', ['class' => 'form-control', 'placeholder' => 1]) ?>
            </p>
            <p class="btn-offer-price-block">
                <?= Html::submitButton('Отправить предложение', ['class' => 'btn btn-success btn-bg-orange-red']); ?>
            </p>
            <?php ActiveForm::end(); ?>
        </div>
    </div>
<?php
Modal::end();