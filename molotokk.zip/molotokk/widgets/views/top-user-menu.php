<?php

/** @var $items array Description */

use yii\bootstrap\Nav;
foreach ($set as $section) {
      $items_nav[] = $items[$section];
}

?>

<?=
Nav::widget([
    'options' => [
        'class' => 'nav nav-tabs  nav-justified',
    ],
    'encodeLabels' => false,
    'items' => $items_nav,
]);
?>
