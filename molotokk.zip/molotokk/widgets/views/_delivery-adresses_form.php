<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;
use common\widgets\RegionFormWidget;
use yii\widgets\MaskedInput;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model molotokk\models\DeliveryAdresses */
/* @var $form yii\widgets\ActiveForm */
?>
<style>
    div.required label:after {
        content: " *";
        color: red;
    }
</style>
<?php
$form = ActiveForm::begin([
        'action' => Url::to('/products/delivery-adress-add/'),
        'id' => 'pj_delivery-adresses-form',
        'enableAjaxValidation' => true,
    ]);
?>
<?=
    $form->field($model, 'name')->textInput(['maxlength' => true])
    ->hint('Название адреса необходимо, чтобы различать их при выборе и в списке Ваших '
        .Html::a('адресов доставки',
            Url::to('/user/settings/delivery-adresses/'), ['target' => '_blank']))
?>

<?= $form->field($model, 'fio')->textInput() ?>

<?=
RegionFormWidget::widget([
    'model' => $model,
    'form' => $form,
]);
?>
<?= $form->field($model, 'address')->textarea() ?>

<?=
$form->field($model, 'zip')->widget(MaskedInput::className(),
    [
    'mask' => '999999',
])
?>

<?=
$form->field($model, 'phone')->widget(MaskedInput::className(),
    [
    'mask' => '+9(999) 999-99-99',
])
?>
    <?= $form->field($model, 'is_default')->checkbox(); ?>
<div class="form-group">
<?= Html::submitButton('Добавить', ['class' => 'btn btn-success']) ?>
</div>

<?php ActiveForm::end(); ?>



