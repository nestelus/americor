<?php

use yii\helpers\Html;
use yii\jui\Sortable;
use yii\helpers\Url;
use yii\widgets\Pjax;

/* @var $this yii\web\View */
/* @var $model molotokk\models\Products */
/* @var $properties molotokk\models\ProductProperties[] */
/* @var $photos molotokk\models\ProductPhotos[] */
/* @var $deliveries molotokk\models\DeliveryTypes[] */
/* @var $payments molotokk\models\PaymentTypes[] */

$photos = $model->getProductPhotos()->all();
?>
<?php
Pjax::begin(
    [
        'formSelector' => '#form-photo-uploads',
        'enablePushState' => false,
        'scrollTo' => true,
        'enableReplaceState' => false,
        'id' => 'upload-photo',
        'timeout' => 0,
    ]
);
?>

<?php if ($model->getErrors('productPhotos')):
    ?>
    <div class="col-md-12 alert alert-danger">
        <?= $model->getFirstError('productPhotos') ?>
    </div>
<?php endif; ?>
<?php if ($model->user_id == Yii::$app->user->id) : ?>


    <?=
    Html::a(
        'Добавить изображение', '#',
        [
        'data-toggle' => 'modal',
        'data-target' => '#modal-upload',
        'class' => 'btn btn-add-photo',
        ]
    )
    ?>
    <?php if (!empty($photos)): ?>
        <?=
        Html::a(
            'Удалить все фото',
            Url::to(['/admin-product/delete-all-photos', 'id' => $model->id]),
            ['class' => 'padding-left-25']
        )
        ?>
    <?php endif; ?>
<?php endif; ?>

<?php if (!empty($photos)): ?>
    <?php
    $items = [];
    foreach ($photos as $photo) {
        $tag       = Html::beginTag('div',
                ['class' => 'admin-product-image-block']);
        $tag .= Html::img(
                $photo->getUrlPhoto(120),
                [
                'id' => 'photo-'.$photo->id,
                'sort' => $photo->order,
                'class' => 'admin-product-image',
                ]
        );
        $mainPhoto = $photo->order == 1;
        $tag .= Html::a(
                Html::tag('span', '', ['class' => 'glyphicon glyphicon-remove']),
                "/admin-product/delete-photo/$photo->id/",
                [
                'class' => 'admin-product-image-btn-close'.($mainPhoto ? ' hidden'
                        : ''),
                'title' => 'Удалить изображение',
                ]
        );
        $tag .= Html::beginTag('span',
                ['class' => 'admin-product-image-main-check-block'.($mainPhoto ? ' admin-product-image-main-check-block-checked'
                        : '')]);
        $tag .= Html::beginTag('label', ['class' => 'radio-inline']);
        $checked   = $mainPhoto ? ['checked' => 'checked'] : [];
        $tag .= Html::input('radio', 'photo-main', $photo->id, $checked);
        $tag .= 'Сделать главной';
        $tag .= Html::endTag('label');
        $tag .= Html::endTag('span');
        $tag .= Html::endTag('div');
        $items[]   = $tag;
    }
    ?>
    <?=
    Sortable::widget(
        [
            'items' => $items,
            'options' => [
                'id' => "photos-car-$model->id",
                'tag' => 'div',
            ],
            'itemOptions' => [
                'tag' => 'div',
                'class' => 'pull-left admin-product-image-container',
            ],
            'clientOptions' => [
                'cursor' => 'move',
                'axis' => "x",
            ],
        ]
    );
    ?>

<?php endif; ?>

<?php
$js = <<< JS
         $("input[name='photo-main']").on('change', function(){
          $.ajax({
                    url: '/admin-product/main-photo/' + $("input[name='photo-main']:checked").val(),
                    success:  function () {

            var imageBlock = $("input[name='photo-main']:checked").parents('.admin-product-image-block');
            $('.admin-product-image-btn-close').removeClass('hidden');
            $('.admin-product-image-main-check-block').removeClass('admin-product-image-main-check-block-checked');

                $('.admin-product-image-btn-close', imageBlock).addClass('hidden');
                $('.admin-product-image-main-check-block', imageBlock).addClass('admin-product-image-main-check-block-checked');

        }
    });
});


JS;

$this->registerJs($js);
?>
<?php Pjax::end(); ?>
