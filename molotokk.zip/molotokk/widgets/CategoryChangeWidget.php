<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace molotokk\widgets;

use yii\base\Widget;
use common\models\auktaModels\Categories;

/**
 * Description of CategoryChangeWidget
 *
 * @author Vladimir
 */
class CategoryChangeWidget extends Widget
{
    public $model;
    public $change = false;
    private $_parent;
    private $_category;

    public function init()
    {

        if ($this->model->category_id) {
            $this->_category = Categories::findOne($this->model->category_id);
            $this->_parent   = $this->_category->parent;
        } else {
            $this->_category = new Categories();
            $this->_parent   = new Categories();
            $this->change    = true;
        }
    }

    public function run()
    {

        return $this->render('category-change',
                [
                'model' => $this->model,
                'category' => $this->_category,
                'parent' => $this->_parent,
                'change' => $this->change,
        ]);
    }
}
