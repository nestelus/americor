<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace molotokk\widgets;

use yii\base\Widget;
use yii\helpers\Html;

/**
 * Description of SliderWidget
 *
 * @author Vladimir
 */
class SliderWidget extends Widget
{
    public $slider;
    public $id;
    private $_slide_items;

    public function init()
    {
        foreach ($this->slider as $slide) {
            $photo = $slide->getMainPhoto();
            if ($photo) {
                $this->_slide_items[] = Html::a(Html::img($photo->getUrlPhoto(null,
                                100),
                            [
                            'class' => 'product-image-preview',
                        ]), $slide->getUrl());
            }
        }
    }

    public function run()
    {
        return $this->render('slider-slick',
                [
                'items' => $this->_slide_items,
                'id' => $this->id,
        ]);
    }
}
