<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace molotokk\widgets;

use Yii;
use yii\bootstrap\Widget;
use common\models\Profile;

class ModalLotMessages extends Widget
{
    public $product;
    public $sales;
    public $type = 'price_offer';

    //public $form = null;

    public function run()
    {
        $view = '';
        switch ($this->type) {
            case 'price_offer':
                $view = 'modal-lot-price-offer';
                break;
            case 'purchase_proof':
                $view = 'modal-lot-purchase-proof';
                break;
        }
        $modal = $this->render(
            $view,
            [
            'profile' => Profile::findOne(Yii::$app->user->id),
            'sales' => $this->sales,
            'product' => $this->product,
            //  'form' => $this->form,
            ]
        );
        return $modal;
    }
}
