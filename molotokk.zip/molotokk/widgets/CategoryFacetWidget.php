<?php
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace molotokk\widgets;

use yii\bootstrap\Widget;
use common\models\auktaModels\Categories;
use molotokk\models\sphinx\Products;
use yii\sphinx\ActiveDataProvider;
use yii\helpers\Html;

/**
 * Description of FacetWidget
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class CategoryFacetWidget extends Widget
{
    public $category;
    public $query;
    public $dataAsIs = false;
    protected $header;
    private $_type;
    private $_items;

    public function getItems($facet)
    {


        foreach ($facet as $facet_category) {
            $category = Categories::findOne($facet_category['category_id']);
            if ($facet_category['category_id'] == $this->category->id) {
                $this->_items[] = [
                    'label' => $category->name,
                    'count' => $facet_category['count(*)'],
                    []
                ];
            } else {

                $this->_items[] = [
                    'label' => $category->name,
                    'url' => $category->getUrl(),
                    'count' => $facet_category['count(*)'],
                    []
                ];
            }

//        var_dump($facet);
//        die();
        }
    }

    public function init()
    {
        parent::init();
        if (!$this->dataAsIs) {
            $this->_type  = $this->category->type;
            $query        = Products::find();
            $query->where = $this->query->where;
            if ($this->category->type == Categories::CATEGORY_END_TYPE) {
                $query->andWhere(['parent_id' => $this->category->parent_id]);
                $this->header = $this->category->parent->name.Html::a(
                        '<span class = "glyphicon glyphicon-share-alt pull-right"></span>',
                        $this->category->parent->getUrl()
                );
            }
            if ($this->category->type == Categories::CATEGORY_PARENT_TYPE) {
                $query->andWhere(['category_id' => $this->category->categoryWithChildren()]);
                $this->header = 'Подкатегории';
            }
            $query->facets(
                [
                    'category_id',
                ]
            );
            $provider = new ActiveDataProvider(
                [
                'query' => $query,
                ]
            );
            $facet    = $provider->getFacets();
            $this->getItems(isset($facet['category_id']) ? $facet['category_id']
                        : []);
        } else {
            /** @var Categories $category */
            foreach ($this->category as $category) {
                $this->_items[] = [
                    'label' => $category->name,
                    'url' => $category->getUrl(),
                ];
            }
        }
    }

    public function run()
    {
        if (!empty($this->_items)) {
            return $this->render('category_facet',
                    [
                    'header' => $this->header,
                    'items' => $this->_items,
            ]);
        }
    }
}
