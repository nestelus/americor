<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace molotokk\widgets;

use yii\bootstrap\Widget;
use common\models\User;
use common\components\platron\PlatronApi;
use Yii;

/**
 * Description of UserMenuWidget
 *
 * @author Vl Bolotovsky <nestelus@yandex.ru>
 */
class UserMenuWidget extends Widget {

    public $mode = 'top';
    public $set = ['buys', 'sales', 'profile'];
    public $current = null;
    private $_items;
    private $_user;

    const ITEMS_BUYS = 'buys';
    const ITEMS_SALES = 'sales';
    const ITEMS_PROFILE = 'profile';
    const ITEMS_MESSAGES = 'message';
    const ITEMS_PAYMENTS = 'payment';

    public function init() {
        $this->_user = User::findOne(Yii::$app->user->id);
        if ($this->_user)
        {
            $this->_user->updateAttributes(['last_at' => time()]);
        }
        $this->_items[self::ITEMS_BUYS] = [
            'label' => Yii::t('nc_users', 'Покупки'),
            'items' => [
                [
                    'label'       => Yii::t('nc_users', 'Избранные'),
                    'url'         => '/profile/my-favorite/',
                    'linkOptions' => [
                        'class' => 'pjax-user_menu',
                    ],
                ],
                [
                    'label'       => Yii::t('nc_users', 'Активные ставки'),
                    'url'         => '/profile/my-active-bids/',
                    'linkOptions' => [
                        'class' => 'pjax-user_menu',
                    ],
                // 'visible' => Yii::$app->user->can('viewOwnProducts'),
                ],
                [
                    'label'       => Yii::t('nc_users', 'Купленные товары'),
                    'url'         => '/profile/my-buys/',
                    'linkOptions' => [
                        'class' => 'pjax-user_menu',
                    ],
                //'visible' => Yii::$app->user->can('viewOwnProducts'),
                ],
                [
                    'label'       => Yii::t('nc_users', 'Не купленные товары'),
                    'url'         => '/profile/my-nobuys/',
                    'linkOptions' => [
                        'class' => 'pjax-user_menu',
                    ],
                //'visible' => Yii::$app->user->can('viewOwnProducts'),
                ],
            ],
        ];
        $this->_items[self::ITEMS_SALES] = [
            'label' => Yii::t('nc_users', 'Продажи'),
            'items' => [
                [
                    'label'       => Yii::t('nc_users', 'Разместить лот'),
                    'url'         => '/admin-product/create/',
                    'linkOptions' => [
                    // 'class' => 'pjax-user_menu',
                    ],
                //  'visible' => Yii::$app->user->can('createProduct'),
                ],
                '<li class ="divider"></li>',
                [
                    'label'       => Yii::t('nc_users', 'Черновики'),
                    'url'         => '/profile/my-drafts/',
                    'linkOptions' => [
                        'class' => 'pjax-user_menu',
                    ],
                //  'visible' => Yii::$app->user->can('viewOwnProducts'),
                ],
                [
                    'label'       => Yii::t('nc_users', 'Активные аукционы'),
                    'url'         => '/profile/my-active-auctions/',
                    'linkOptions' => [
                        'class' => 'pjax-user_menu',
                    ],
                //  'visible' => Yii::$app->user->can('viewOwnProducts'),
                ],
                [
                    'label'       => Yii::t('nc_users', 'В продаже'),
                    'url'         => '/profile/my-active-sales/',
                    'linkOptions' => [
                        'class' => 'pjax-user_menu',
                    ],
                //  'visible' => Yii::$app->user->can('viewOwnProducts'),
                ],
                [
                    'label'       => Yii::t('nc_users', 'Проданные'),
                    'url'         => '/profile/my-sales/',
                    'linkOptions' => [
                        'class' => 'pjax-user_menu',
                    ],
                //  'visible' => Yii::$app->user->can('viewOwnProducts'),
                ],
                [
                    'label'       => Yii::t('nc_users', 'Не проданные'),
                    'url'         => '/profile/my-nosales/',
                    'linkOptions' => [
                        'class' => 'pjax-user_menu',
                    ],
                //  'visible' => Yii::$app->user->can('viewOwnProducts'),
                ],
            ],
        ];
        $this->_items[self::ITEMS_PROFILE] = [
            'label' => Yii::t('nc_users', 'Мой профиль'),
            'items' => [
                [
                    'label'       => Yii::t('nc_users', 'Сменить пароль'),
                    'url'         => '/user/settings/account/',
                    'linkOptions' => [
                        'class' => 'pjax-user_menu',
                    ],
                ],
                [
                    'label'       => Yii::t('nc_users', 'Мой профиль'),
                    'url'         => '/user/settings/profile/',
                    'linkOptions' => [
                        'class' => 'pjax-user_menu',
                    ],
                ],
                [
                    'label'       => Yii::t('nc_users', 'Соцсети'),
                    'url'         => '/user/settings/networks/',
                    'linkOptions' => [
                        'class' => 'pjax-user_menu',
                    ],
                ],
                [
                    'label'       => Yii::t('sales', 'Адреса доставки'),
                    'url'         => '/user/settings/delivery-adresses/',
                    'linkOptions' => [
                        'class' => 'pjax-user_menu',
                    ],
                // 'visible' => Yii::$app->user->can('viewOwnPayDew'),
                ],
            ],
        ];
        $this->_items[self::ITEMS_MESSAGES] = [
            'label' => Yii::t('nc_users', 'Сообщения ') . ' <span class = "glyphicon glyphicon-bell"></span> <span id="new_messages"></span>',
            'items' => [
                [
                    'label'       => Yii::t('users', 'Диалоги с продавцами'),
                    'url'         => '/messages/my-messages/',
                    'linkOptions' => [
                        'class' => 'pjax-user_menu',
                    ],
                // 'visible' => Yii::$app->user->can('viewOwnPayDew'),
                ],
                [
                    'label'       => Yii::t('users', 'Диалоги с покупателями'),
                    'url'         => '/messages/me-messages/',
                    'linkOptions' => [
                        'class' => 'pjax-user_menu',
                    ],
                // 'visible' => Yii::$app->user->can('viewOwnPayDew'),
                ],
                [
                    'label'       => Yii::t('users', 'Системные сообщения'),
                    'url'         => '/messages/system-messages/',
                    'linkOptions' => [
                        'class' => 'pjax-user_menu',
                    ],
                // 'visible' => Yii::$app->user->can('viewOwnPayDew'),
                ],
            ],
        ];
        if ($this->_user)
        {
            if (null !== Yii::$app->get('platron', FALSE) && Yii::$app->get('platron') instanceof PlatronApi)
            {
                $this->_items[self::ITEMS_PAYMENTS] = [
                    'label'       => '<span class = "glyphicon glyphicon-shopping-cart"></span><span id="new_messages"></span> ' . $this->_user->balance . ' ' . Yii::$app->params['currency'],
                    'url'         => '/user-pays/',
                    'linkOptions' => [
                        'class' => 'pjax-user_menu',
                    ],
                ];
            }
        }
    }

    public function run() {

        if (!Yii::$app->user->isGuest)
        {
            return $this->render($this->mode . '-user-menu', [
                        'items'   => $this->_items,
                        'set'     => $this->set,
                        'current' => $this->current,
            ]);
        }
        return '';
    }

    public function getItems($part = null) {
        if (!is_null($part))
        {
            return $this->_items[$part];
        }
        $items = [];
        foreach ($this->set as $group)
        {
            $item_group = $this->_items[$group];
            $items[] = '<li class ="divider"></li>';
            $items[] = '<li class ="dropdown-header">' . $item_group['label'] . '</li>';
            foreach ($item_group['items'] as $item)
            {
                $items[] = $item;
            }
        }
        return $items;
    }

}
