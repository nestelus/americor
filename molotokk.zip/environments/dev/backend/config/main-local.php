<?php
$config = [
    'components' => [

        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => 'dev-backend',
        ],
    ],
];

if (!YII_ENV_TEST) {
    // configuration adjustments for 'dev' environment
    $config['bootstrap'][]                    = 'debug';
    $config['modules']['debug']['class']      = 'yii\debug\Module';
    $config['modules']['debug']['allowedIPs'] = ['192.168.200.1'];

    $config['bootstrap'][]                  = 'gii';
    $config['modules']['gii']['class']      = 'yii\gii\Module';
    $config['modules']['gii']['allowedIPs'] = ['192.168.200.1'];
}

return $config;
