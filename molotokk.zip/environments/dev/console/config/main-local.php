<?php
return [
    'bootstrap' => ['gii'],
    'modules' => [
        'gii' => 'yii\gii\Module',
    ],
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=localhost;dbname=aukta_dev',
            'username' => 'aukta_dev',
            'password' => 'nLdrbmdBamxsnmW6',
            'charset' => 'utf8',
            'tablePrefix' => 'mlt_',
        ],
        'urlManager' => [
            'baseUrl' => 'aukta.local',
        ]
    ]
];
