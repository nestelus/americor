<?php

return [
    'components'    => [
        'db'           => [
            'class'       => 'yii\db\Connection',
            'dsn'         => 'mysql:host=localhost;dbname=aukta_dev',
            'username'    => 'aukta_dev',
            'password'    => 'nLdrbmdBamxsnmW6',
            'charset'     => 'utf8',
            'tablePrefix' => 'mlt_',
        ],
        'sphinx'       => [
            'class'    => 'yii\sphinx\Connection',
            'dsn'      => 'mysql:host=127.0.0.1;port=9306;',
            'username' => 'aukta_dev',
            'password' => 'nLdrbmdBamxsnmW6',
        ],
        'mailer'       => [
            'class'            => 'yii\swiftmailer\Mailer',
            'viewPath'         => '@common/mail',
            // send all mails to a file by default. You have to set
            // 'useFileTransport' to false and configure a transport
            // for the mailer to send real emails.
            'useFileTransport' => true,
        ],
        'platron'      => [
            'class'          => 'common\components\platron\PlatronApi',
            /** @var string Account ID */
            'accountId'      => '8556',
            /** @var string Secret key */
            'secretKey'      => 'gimohivolycyboha',
            /** @var bool Merchant test mode */
            'testMode'       => true,
            /** @var string Default API request(merchant->platron) method */
            'requestMethod'  => "POST",
            /** @var string Default response(platron->merchant) method */
            'responseMethod' => "AUTOPOST",
            /** @var string Possible values: RUR, USD, EUR */
            'currency'       => 'RUR',
            /** @var string */
            'invoiceClass'   => '',
            /** @var string */
            'resultUrl'      => '/platron/result.php',
            /** @var string */
            'successUrl'     => '/user-pays/success/',
            /** @var string */
            'failureUrl'     => '/user-pays/failed/',
            /** @var string Url of merchant site page, where platron can check for possibility of invoice payment */
            'checkUrl'       => null,
            /** @var string */
            'refundUrl'      => '',
            /** @var string */
            'captureUrl'     => '',
            /** @var string Url of merchant site page, where user waiting for payment system response */
            'stateUrl'       => '/user-pays/state/',
            /** @var string Url of merchant site page, where platron redirect user after cash payment */
            'siteReturnUrl'  => '/',
        ],
        'assetManager' => [
            'linkAssets'      => false,
            'forceCopy'       => false,
            'appendTimestamp' => true,
        ],
    ],
    'controllerMap' => [
        'fixture' => [
            'class' => 'yii\faker\FixtureController',
        ],
    ],
];
