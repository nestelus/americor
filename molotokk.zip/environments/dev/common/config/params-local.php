<?php
return [
    'homeURL' => 'http://aukta.local/',
    'urlPhotosLocal' => 'http://content.aukta.local/test_photos/',
    'pathPhotosLocal' => '/var/www/content/test_photos/',
];
