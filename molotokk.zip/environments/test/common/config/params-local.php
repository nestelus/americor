<?php
return [
    'homeURL' => 'http://test.aukta.ru/',
    'urlPhotosLocal' => 'http://content.aukta.ru/test_photos/',
    'pathPhotosLocal' => '/var/www/content/test_photos/',
];
