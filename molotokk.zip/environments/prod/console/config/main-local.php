<?php
return [
    'components' => [
        'db' => [
            'class' => 'yii\db\Connection',
            'dsn' => 'mysql:host=localhost;dbname=aukta',
            'username' => 'aukta',
            'password' => 'npyda7vrfNrqHzd7',
            'charset' => 'utf8',
            'tablePrefix' => 'mlt_',
        ],
        'urlManager' => [
            'baseUrl' => 'http://aukta.ru',
        ]
    ],
];
