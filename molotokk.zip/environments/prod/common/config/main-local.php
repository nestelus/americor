<?php
return [
    'components' => [
        'db'     => [
            'class'       => 'yii\db\Connection',
            'dsn'         => 'mysql:host=localhost;dbname=aukta',
            'username'    => 'aukta',
            'password'    => 'npyda7vrfNrqHzd7',
            'charset'     => 'utf8',
            'tablePrefix' => 'mlt_',
        ],
        'sphinx' => [
            'class'    => 'yii\sphinx\Connection',
            'dsn'      => 'mysql:host=127.0.0.1;port=9306;',
            'username' => 'aukta',
            'password' => 'npyda7vrfNrqHzd7',
        ],
        'mailer' => [
            'class'            => 'yii\swiftmailer\Mailer',
            'viewPath'         => '@common/mail',
            'useFileTransport' => false,
        ],
    ],
];
