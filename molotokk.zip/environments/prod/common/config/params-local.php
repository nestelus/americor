<?php
return [
    'homeURL' => 'http://aukta.ru/',
    'urlPhotosLocal' => 'http://content.aukta.ru/photos/',
    'pathPhotosLocal' => '/var/www/content/photos/',
];
